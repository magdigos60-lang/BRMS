/**
 * BARANGAY RESIDENT MANAGEMENT SYSTEM
 * Single Monolithic Server Application (Express.js + Supabase JavaScript Client)
 * Designed for Deployment on Render + Supabase Database
 */

require('dotenv').config();
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { createClient } = require('@supabase/supabase-js');
const QRCode = require('qrcode');
const multer = require('multer');
const crypto = require('crypto');

// ==========================================
// ENVIRONMENT & SYSTEM INITIALIZATION
// ==========================================
const PORT = process.env.PORT || 3000;
const SUPABASE_URL = process.env.SUPABASE_URL || 'https://your-supabase-id.supabase.co';
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY || 'your-supabase-anon-key';
// Server-side secret key (Supabase > Project Settings > API > service_role). It bypasses Row Level Security,
// so keep it ONLY in the server's environment variables - never in the code, a repository, or the browser.
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
const JWT_SECRET = process.env.JWT_SECRET || 'barangay-system-super-secure-jwt-secret-key-2026';

if (!SUPABASE_URL || (!SUPABASE_SERVICE_ROLE_KEY && !SUPABASE_ANON_KEY)) {
  console.warn('[WARNING] Supabase credentials missing! Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in environment variables.');
}
if (!SUPABASE_SERVICE_ROLE_KEY) {
  console.warn('[WARNING] SUPABASE_SERVICE_ROLE_KEY is not set. Using the anon key, which Row Level Security will block.');
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY || SUPABASE_ANON_KEY, {
  auth: { persistSession: false, autoRefreshToken: false }
});
const app = express();
// Render (and most hosts) sit behind a proxy; needed so secure cookies and req.ip work correctly over HTTPS.
app.set('trust proxy', 1);
const IS_PROD = process.env.NODE_ENV === 'production' || !!process.env.RENDER;
// Cookie options shared by login/logout. Works inside the Android app (WebView) and in normal browsers.
const COOKIE_OPTS = { httpOnly: true, sameSite: 'lax', secure: IS_PROD };

const upload = multer({ limits: { fileSize: 10 * 1024 * 1024 } }); // 10MB limit

// Photos attached to family members (registration form and the "My Family" page): images only, 2MB each.
// The registration form also shrinks every photo in the browser before it is uploaded.
const photoUpload = multer({
  limits: { fileSize: 2 * 1024 * 1024, files: 16 },
  fileFilter: (req, file, cb) => {
    if (/^image\/(jpeg|png|webp|gif)$/.test(file.mimetype)) return cb(null, true);
    cb(new Error('Photos must be JPG, PNG, WEBP or GIF images.'));
  }
});
// Wraps a multer handler so upload problems show a friendly alert instead of a raw error page.
const safeUpload = (mw) => (req, res, next) => mw(req, res, (err) => {
  if (!err) return next();
  const msg = err.code === 'LIMIT_FILE_SIZE' ? 'Each photo must be 2 MB or smaller.' : (err.message || 'The photo could not be uploaded.');
  return res.status(400).send(`<script>alert(${JSON.stringify(msg)}); window.history.back();</script>`);
});
// Email domain for generated family-member logins (override with FAMILY_EMAIL_DOMAIN in the environment).
const FAMILY_EMAIL_DOMAIN = process.env.FAMILY_EMAIL_DOMAIN || 'family.local';

// Universal Body Parsing Middlewares
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(cookieParser());
app.use('/public', express.static(path.join(__dirname, 'public'), { maxAge: '7d' }));
app.use(cors());

// ==========================================
// MOBILE APP SUPPORT (PWA manifest, service worker, icon, health check)
// These routes are public and are served before the setup guard and login checks.
// ==========================================
app.get('/manifest.webmanifest', (req, res) => {
  res.type('application/manifest+json').json({
    name: 'Barangay Resident Portal',
    short_name: 'Barangay',
    description: 'Barangay Resident Management System',
    start_url: '/login',
    scope: '/',
    display: 'standalone',
    orientation: 'portrait',
    background_color: '#0b2545',
    theme_color: '#205493',
    icons: [
      { src: '/app-icon.svg', sizes: 'any', type: 'image/svg+xml', purpose: 'any maskable' }
    ]
  });
});

app.get('/app-icon.svg', (req, res) => {
  res.type('image/svg+xml').set('Cache-Control', 'public, max-age=86400').send(
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#205493"/><stop offset="1" stop-color="#2ecc71"/></linearGradient></defs><rect width="512" height="512" fill="url(#g)"/><g fill="#fff"><path d="M256 110 120 200v22h272v-22z"/><rect x="146" y="238" width="36" height="120"/><rect x="238" y="238" width="36" height="120"/><rect x="330" y="238" width="36" height="120"/><rect x="116" y="374" width="280" height="30" rx="6"/></g></svg>`
  );
});

// Minimal service worker: lets the app be installed and shows a friendly offline page.
// Pages are always fetched live (never cached) so resident data is never shown stale.
app.get('/sw.js', (req, res) => {
  res.type('application/javascript').set('Cache-Control', 'no-cache').send(`
self.addEventListener('install', function () { self.skipWaiting(); });
self.addEventListener('activate', function (e) { e.waitUntil(self.clients.claim()); });
self.addEventListener('fetch', function (e) {
  if (e.request.mode !== 'navigate') return;
  e.respondWith(fetch(e.request).catch(function () {
    return new Response('<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Offline</title></head><body style="font-family:sans-serif;text-align:center;padding:48px 20px;background:#f4f9f6;color:#0b2545"><h2>No internet connection</h2><p>Please check your connection and try again.</p><button onclick="location.reload()" style="padding:10px 22px;border:0;border-radius:8px;background:#205493;color:#fff;font-size:1rem">Retry</button></body></html>', { headers: { 'Content-Type': 'text/html' } });
  }));
});`);
});

// Lightweight health check (useful for Render and for waking the free-tier server).
app.get('/healthz', (req, res) => res.json({ ok: true }));

// ==========================================
// MIDDLEWARES (Auth & Role Validation)
// ==========================================
const redirectToLogin = (req, res) => {
  // Remember scanner pages so staff land back on them after logging in
  if (req.method === 'GET' && /^\/(scan|scanner)(\?.*)?$/.test(req.originalUrl)) {
    res.cookie('return_to', req.originalUrl, { httpOnly: true, maxAge: 10 * 60 * 1000 });
  }
  return res.redirect('/login');
};

const authenticateToken = async (req, res, next) => {
  const token = req.cookies.token || (req.headers.authorization && req.headers.authorization.split(' ')[1]);
  if (!token) {
    if (req.accepts('html')) return redirectToLogin(req, res);
    return res.status(401).json({ success: false, message: 'Authentication required.' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const { data: user, error } = await supabase.from('users').select('*').eq('id', decoded.userId).single();
    if (error || !user || user.status !== 'Active') {
      res.clearCookie('token');
      if (req.accepts('html')) return redirectToLogin(req, res);
      return res.status(403).json({ success: false, message: 'User account disabled or invalid.' });
    }
    req.user = user;
    next();
  } catch (err) {
    res.clearCookie('token');
    if (req.accepts('html')) return redirectToLogin(req, res);
    return res.status(403).json({ success: false, message: 'Session expired or invalid.' });
  }
};

const requireRole = (allowedRoles) => {
  return (req, res, next) => {
    if (!req.user || !allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ success: false, message: 'Unauthorized access for your user role.' });
    }
    next();
  };
};

// ==========================================
// PUSH NOTIFICATIONS (Firebase Cloud Messaging)
// Phones get the alert even when the app is closed. Needs FIREBASE_SERVICE_ACCOUNT in the environment
// (the service account JSON, or the same JSON encoded as base64) and the device_tokens table.
// ==========================================
let firebaseAdmin = null;
try {
  const raw = (process.env.FIREBASE_SERVICE_ACCOUNT || process.env.FIREBASE_SERVICE_ACCOUNT_BASE64 || '').trim();
  if (raw) {
    const admin = require('firebase-admin');
    const json = raw.startsWith('{') ? raw : Buffer.from(raw, 'base64').toString('utf8');
    const serviceAccount = JSON.parse(json);
    if (serviceAccount.private_key) serviceAccount.private_key = serviceAccount.private_key.replace(/\\n/g, '\n');
    admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
    firebaseAdmin = admin;
    console.log('[PUSH] Firebase Cloud Messaging is ready.');
  } else {
    console.warn('[PUSH] FIREBASE_SERVICE_ACCOUNT is not set. Push notifications are disabled.');
  }
} catch (err) {
  console.error('[PUSH] Firebase could not start:', err.message);
}

// target: an array of user ids, or 'all' for every registered device.
// Never throws: a failed push must not break the request that triggered it.
const sendPush = async (target, { title, body, url = '/' }) => {
  if (!firebaseAdmin) return;
  try {
    let q = supabase.from('device_tokens').select('token');
    if (Array.isArray(target)) {
      if (!target.length) return;
      q = q.in('user_id', target);
    }
    const { data } = await q;
    const tokens = [...new Set((data || []).map(r => r.token))];
    for (let i = 0; i < tokens.length; i += 500) {
      const batch = tokens.slice(i, i + 500);
      const resp = await firebaseAdmin.messaging().sendEachForMulticast({
        tokens: batch,
        notification: { title: String(title).slice(0, 100), body: String(body || '').slice(0, 300) },
        data: { url: String(url) },
        android: {
          priority: 'high',                 // delivered immediately, even in Doze mode
          ttl: 24 * 3600 * 1000,            // stays queued for 24h if the phone is off
          notification: { channelId: 'barangay_alerts', sound: 'default', defaultVibrateTimings: true }
        }
      });
      const dead = [];
      resp.responses.forEach((r, idx) => {
        if (!r.success && r.error && /not-registered|invalid-registration-token|invalid-argument/.test(r.error.code || '')) dead.push(batch[idx]);
      });
      if (dead.length) await supabase.from('device_tokens').delete().in('token', dead);
    }
  } catch (err) {
    console.error('[PUSH] Send error:', err.message);
  }
};

// Login accounts that belong to the given residents (family members have their own account)
const userIdsForResidents = async (residentIds) => {
  const ids = [...new Set((residentIds || []).filter(Boolean))];
  if (!ids.length) return [];
  const { data } = await supabase.from('users').select('id').in('resident_id', ids).eq('status', 'Active');
  return (data || []).map(u => u.id);
};
const notifyResidents = async (residentIds, payload) => sendPush(await userIdsForResidents(residentIds), payload);

const notifyStaff = async (payload) => {
  const { data } = await supabase.from('users').select('id')
    .in('role', ['Super Admin', 'Barangay Admin', 'Barangay Secretary', 'Barangay Staff']).eq('status', 'Active');
  return sendPush((data || []).map(u => u.id), payload);
};

// The app registers its FCM token here after login
app.post('/api/device/register', authenticateToken, async (req, res) => {
  try {
    const token = String((req.body && req.body.token) || '').trim();
    if (!token || token.length > 4096) return res.status(400).json({ success: false });
    // token is unique: if another account used this phone before, it moves to the current user
    const { error } = await supabase.from('device_tokens').upsert(
      { user_id: req.user.id, token, platform: 'android', updated_at: new Date() },
      { onConflict: 'token' }
    );
    if (error) throw error;
    res.cookie('push_token', token, { httpOnly: true, sameSite: 'lax', secure: IS_PROD, maxAge: 365 * 24 * 3600 * 1000 });
    res.json({ success: true });
  } catch (err) {
    console.error('Device register error:', err.message);
    res.status(500).json({ success: false });
  }
});

const logActivity = async (userId, action, details = '', ip = '') => {
  try {
    await supabase.from('user_activity_logs').insert([{ user_id: userId, action, details, ip_address: ip }]);
  } catch (err) {
    console.error('Error writing activity log:', err);
  }
};

// ==========================================
// CONSTANTS & LOGIC CONSTANTS
// ==========================================
const fs = require('fs');
const LOCAL_LOGIN_BG = ['jpg', 'jpeg', 'png', 'webp'].map(e => 'login-bg.' + e).find(f => fs.existsSync(path.join(__dirname, 'public', f)));
const DEFAULT_LOGIN_BG = process.env.LOGIN_BG_URL || (LOCAL_LOGIN_BG ? '/public/' + LOCAL_LOGIN_BG : 'https://scontent.fmnl7-1.fna.fbcdn.net/v/t39.30808-6/825351115_2246821486242027_8708722577315615068_n.jpg?stp=dst-jpg_tt6&cstp=mx1060x992&ctp=s1060x992&_nc_cat=110&_nc_map=urlgen_bucketless&ccb=1-7&_nc_sid=127cfc&_nc_eui2=AeHpk_cBk3_TrQDPpACbx68fjQwB0jaJYXWNDAHSNolhdfR3vwGsh31cD5-A7Nb3qzplS4aAfDftzWcsmyDXAsnf&_nc_ohc=9kiVrKuYCaEQ7kNvwF5Fqvg&_nc_oc=AdoHRQdsyCcxTqk4w0KR7R2Zb0enrC3hW7pK-daM2VkR25d4VzUTYRPuDeVAO-0OqxE&_nc_zt=23&_nc_ht=scontent.fmnl7-1.fna&_nc_gid=YqF5baJjuA9AxDmeY4t-cQ&_nc_ss=7b2a8&oh=00_AQNGaJ1omjdjMSMRvX3nmmA0cmDu2W92J5Tr5Xc7qjcUPA&oe=6ADCD0BC');

// ==========================================
// INLINE CORE HTML/CSS SYSTEM STYLES ENGINE
// Palette Refined with Light Green & Light Blue Themes
// ==========================================
const renderSystemHead = (title) => `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
  <meta name="theme-color" content="#205493">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <link rel="manifest" href="/manifest.webmanifest">
  <link rel="icon" href="/app-icon.svg" type="image/svg+xml">
  <link rel="apple-touch-icon" href="/app-icon.svg">
  <title>${title} - Barangay Resident System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    :root {
      --primary-navy: #0b2545;
      --primary-blue: #205493;
      --light-blue: #d9edf7;
      --accent-green: #2ecc71;
      --light-green: #e1f5fe;
      --soft-mint: #d4edda;
      --pure-white: #ffffff;
      --bg-light: #f4f9f6;
      --text-dark: #1d2d44;
    }
    body {
      background-color: var(--bg-light);
      color: var(--text-dark);
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .bg-primary-blue { background-color: var(--primary-blue) !important; }
    .bg-dark-blue { background-color: var(--primary-navy) !important; }
    .bg-accent-green { background-color: var(--accent-green) !important; }
    .bg-light-green { background-color: var(--light-green) !important; }
    .bg-light-blue { background-color: var(--light-blue) !important; }
    
    .text-primary-blue { color: var(--primary-blue) !important; }
    .text-accent-green { color: var(--accent-green) !important; }
    
    .btn-primary-custom {
      background-color: var(--primary-blue);
      color: white;
      border: none;
    }
    .btn-primary-custom:hover {
      background-color: var(--primary-navy);
      color: white;
    }
    .btn-accent-custom {
      background-color: var(--accent-green);
      color: white;
      border: none;
    }
    .btn-accent-custom:hover {
      background-color: #27ae60;
      color: white;
    }
    .sidebar {
      min-height: 100vh;
      background: linear-gradient(180deg, var(--primary-navy) 0%, var(--primary-blue) 100%);
      color: white;
    }
    .sidebar .nav-link {
      color: rgba(255, 255, 255, 0.85);
      font-weight: 500;
      padding: 10px 18px;
      margin: 2px 10px;
      border-radius: 6px;
    }
    .sidebar .nav-link:hover, .sidebar .nav-link.active {
      background-color: var(--accent-green);
      color: white;
    }
    .sidebar .nav-link.sub-link {
      padding: 8px 14px 8px 30px;
      font-size: 0.92rem;
      margin: 1px 10px;
    }
    .sidebar .menu-group-toggle .menu-chevron { transition: transform .2s; }
    .sidebar .menu-group-toggle.collapsed .menu-chevron { transform: rotate(-90deg); }
    .sidebar .menu-group-toggle:hover { background-color: rgba(255,255,255,0.12); }
    .card-custom {
      background-color: var(--pure-white);
      border-radius: 12px;
      border: 1px solid #d1e7dd;
      box-shadow: 0 4px 10px rgba(32, 84, 147, 0.05);
    }
    .stat-card {
      border-left: 5px solid var(--primary-blue);
      background: linear-gradient(135deg, #ffffff 0%, var(--light-blue) 100%);
    }
    .stat-card.green {
      border-left: 5px solid var(--accent-green);
      background: linear-gradient(135deg, #ffffff 0%, var(--light-green) 100%);
    }

    /* Standardized CR80 ID Card Frame (3.375in x 2.125in) */
    .id-card-frame {
      width: 3.375in;
      height: 2.125in;
      border-radius: 10px;
      border: 2px solid var(--primary-blue);
      background: #ffffff;
      position: relative;
      overflow: hidden;
      font-size: 8pt;
      box-shadow: 0 6px 12px rgba(0,0,0,0.12);
      display: inline-block;
      margin: 6px;
      box-sizing: border-box;
    }
    .id-card-header {
      background: linear-gradient(90deg, var(--primary-navy) 0%, var(--accent-green) 100%);
      color: white;
      padding: 4px 8px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 0.42in;
    }
    .id-header-logo {
      width: 0.32in;
      height: 0.32in;
      object-fit: cover;
      border-radius: 50%;
      /* Tinanggal ang outer lines */
      border: none;
    }
    .id-card-body {
      padding: 6px;
      display: flex;
      gap: 8px;
      height: calc(2.125in - 0.72in);
    }
    .id-photo {
      width: 1.05in;
      height: 1.05in;
      object-fit: cover;
      border: 2px solid var(--primary-blue);
      border-radius: 6px;
      flex-shrink: 0;
    }
    .id-details {
      flex-grow: 1;
      font-size: 7.2pt;
      line-height: 1.2;
      overflow: hidden;
    }
    .id-qr {
      width: 1.05in;
      height: 1.05in;
      object-fit: contain;
      flex-shrink: 0;
    }
    .id-card-footer {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      height: 0.30in;
      padding: 0 8px 3px 8px;
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
      background: #ffffff;
    }
    .print-sheet-8 {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 15px;
      width: 8.5in;
      margin: auto;
    }

    /* ===== GLOBAL LOADING INDICATORS ===== */
    #page-loader {
      position: fixed; inset: 0; z-index: 99999;
      display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 14px;
      background: rgba(244, 249, 246, 0.92);
      backdrop-filter: blur(3px);
      opacity: 1; visibility: visible;
      transition: opacity .3s ease, visibility .3s ease;
      /* failsafe: never stay stuck if JS fails */
      animation: loaderFailsafe 0s linear 10s forwards;
    }
    #page-loader.hidden { opacity: 0; visibility: hidden; pointer-events: none; }
    #page-loader .loader-ring {
      width: 56px; height: 56px; border-radius: 50%;
      border: 5px solid var(--light-blue);
      border-top-color: var(--primary-blue);
      border-right-color: var(--accent-green);
      animation: loaderSpin .8s linear infinite;
    }
    #page-loader .loader-text {
      font-weight: 600; letter-spacing: .5px; color: var(--primary-navy);
    }
    #top-progress {
      position: fixed; top: 0; left: 0; height: 3px; width: 0; z-index: 100000;
      background: linear-gradient(90deg, var(--primary-blue), var(--accent-green));
      box-shadow: 0 0 8px var(--accent-green);
      transition: width .4s ease, opacity .3s ease;
    }
    .btn-loading-spinner {
      display: inline-block; width: 1em; height: 1em; margin-right: 6px; vertical-align: -2px;
      border: 2px solid currentColor; border-right-color: transparent; border-radius: 50%;
      animation: loaderSpin .7s linear infinite;
    }
    @keyframes loaderSpin { to { transform: rotate(360deg); } }
    @keyframes loaderFailsafe { to { opacity: 0; visibility: hidden; pointer-events: none; } }
    @media print { #page-loader, #top-progress { display: none !important; } }

    /* ===== MOBILE / COMPACT LAYOUT ===== */
    .main-pane { height: 100vh; overflow-y: auto; background-color: #f4f9f6; }
    .mobile-topbar {
      position: sticky; top: 0; z-index: 1030; height: 52px; padding: 0 12px;
      display: flex; align-items: center; gap: 10px; color: #fff;
      background: linear-gradient(90deg, var(--primary-navy) 0%, var(--primary-blue) 100%);
      box-shadow: 0 2px 6px rgba(0,0,0,.15);
    }
    .mobile-topbar img { width: 34px; height: 34px; border-radius: 50%; object-fit: cover; }
    .mobile-topbar .t-name { font-weight: 700; font-size: .95rem; line-height: 1.1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1; min-width: 0; }
    .mobile-topbar .t-name small { display: block; font-weight: 400; font-size: .7rem; opacity: .8; }
    .mobile-topbar .btn-menu { background: transparent; border: 0; color: #fff; font-size: 1.6rem; padding: 0 4px; }
    .offcanvas.mobile-menu { background: linear-gradient(180deg, var(--primary-navy) 0%, var(--primary-blue) 100%); color: #fff; width: 280px; }
    .offcanvas.mobile-menu .nav-link { color: rgba(255,255,255,.88); font-weight: 500; padding: 10px 14px; margin: 2px 0; border-radius: 6px; }
    .offcanvas.mobile-menu .nav-link.sub-link { padding: 8px 12px 8px 28px; font-size: .92rem; }
    .offcanvas.mobile-menu .nav-link:hover, .offcanvas.mobile-menu .nav-link.active { background-color: var(--accent-green); color: #fff; }
    .offcanvas.mobile-menu .menu-group-toggle .menu-chevron { transition: transform .2s; }
    .offcanvas.mobile-menu .menu-group-toggle.collapsed .menu-chevron { transform: rotate(-90deg); }
    .bottom-nav {
      position: fixed; left: 0; right: 0; bottom: 0; z-index: 1030; height: 58px;
      display: flex; background: #fff; border-top: 1px solid #d1e7dd; box-shadow: 0 -2px 8px rgba(32,84,147,.1);
      padding-bottom: env(safe-area-inset-bottom);
      box-sizing: content-box;
    }
    .bottom-nav a, .bottom-nav button {
      flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center;
      gap: 1px; color: #5b6b82; text-decoration: none; font-size: .66rem; font-weight: 600;
      background: transparent; border: 0; padding: 4px 2px;
    }
    .bottom-nav i { font-size: 1.3rem; line-height: 1; }
    .bottom-nav .active { color: var(--primary-blue); }
    .bottom-nav .active i { color: var(--accent-green); }

    @media (max-width: 767.98px) {
      html, body { overflow-x: hidden; }
      .main-pane { height: auto; min-height: calc(100vh - 52px); overflow: visible; padding: 10px !important; }
      .main-pane.has-bottom-nav { padding-bottom: 76px !important; }
      .main-pane .card-custom.p-4, .main-pane .card.p-4, .main-pane .p-4 { padding: 12px !important; }
      .main-pane .p-5 { padding: 16px !important; }
      .main-pane h3 { font-size: 1.15rem; }
      .main-pane h4 { font-size: 1.05rem; }
      .main-pane h5 { font-size: 1rem; }
      .main-pane h6 { font-size: .9rem; }
      .main-pane h2 { font-size: 1.5rem; }
      .main-pane .display-1, .main-pane .display-3 { font-size: 2.6rem; }
      .main-pane .mb-4 { margin-bottom: .85rem !important; }
      .main-pane .row { --bs-gutter-x: .6rem; --bs-gutter-y: .6rem; }
      .main-pane .form-label { font-size: .8rem; margin-bottom: 2px; }
      .main-pane .form-control, .main-pane .form-select { font-size: 16px; padding: .4rem .6rem; }
      .main-pane .btn { padding: .4rem .7rem; font-size: .9rem; }
      .main-pane .table { font-size: .8rem; }
      .main-pane .table > :not(caption) > * > * { padding: .35rem .4rem; }
      .main-pane .alert { padding: .6rem .75rem; font-size: .88rem; }
      .main-pane .modal-dialog { margin: .5rem; }
      .id-card-frame { display: block; margin: 4px auto 6px; max-width: 100%; }
    }
    @media (max-width: 359px) {
      .id-card-frame { transform: scale(.9); transform-origin: top center; }
    }
    @media (min-width: 768px) { .mobile-topbar, .bottom-nav { display: none !important; } }
    @media print { .mobile-topbar, .bottom-nav { display: none !important; } }

    @media print {
      .no-print { display: none !important; }
      body { background: white !important; }
      .print-sheet-8 { page-break-after: always; }
    }
  </style>
</head>
<body>
  <div id="top-progress"></div>
  <div id="page-loader">
    <div class="loader-ring"></div>
    <div class="loader-text" id="page-loader-text">Loading...</div>
  </div>
`;

const renderSystemFooter = () => `
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    function showNotification(title, message, isError = false) {
      alert((isError ? 'Error: ' : 'Info: ') + message);
    }

    // ===== Loading indicator logic =====
    (function () {
      var loader = document.getElementById('page-loader');
      var loaderText = document.getElementById('page-loader-text');
      var bar = document.getElementById('top-progress');
      var barTimer = null;

      function startBar() {
        if (!bar) return;
        bar.style.opacity = '1';
        bar.style.width = '15%';
        var w = 15;
        clearInterval(barTimer);
        barTimer = setInterval(function () {
          w += (90 - w) * 0.08;
          bar.style.width = w + '%';
        }, 250);
      }
      function resetBar() {
        if (!bar) return;
        clearInterval(barTimer);
        bar.style.width = '100%';
        setTimeout(function () { bar.style.opacity = '0'; bar.style.width = '0'; }, 300);
      }
      function showLoader(text) {
        if (loaderText) loaderText.textContent = text || 'Loading...';
        if (loader) loader.classList.remove('hidden');
        startBar();
      }
      function hideLoader() {
        if (loader) loader.classList.add('hidden');
        resetBar();
        document.querySelectorAll('button[data-was-loading], input[data-was-loading]').forEach(function (b) {
          b.disabled = false;
          if (b.dataset.origHtml !== undefined) b.innerHTML = b.dataset.origHtml;
          b.removeAttribute('data-was-loading');
        });
      }

      // Hide the first-paint loader once everything (CSS, images, fonts) has loaded
      if (document.readyState === 'complete') hideLoader();
      else window.addEventListener('load', hideLoader);
      // Back/forward cache restore
      window.addEventListener('pageshow', function (e) { if (e.persisted) hideLoader(); });

      // Forms: show spinner on submit (skips if a confirm() or validation blocked it)
      document.addEventListener('submit', function (e) {
        var form = e.target;
        if (e.defaultPrevented || !form || form.hasAttribute('data-no-loader')) return;
        var isUpload = form.enctype === 'multipart/form-data';
        showLoader(isUpload ? 'Uploading, please wait...' : 'Processing, please wait...');
        // Disable submit buttons AFTER submission starts (prevents double-click duplicates)
        setTimeout(function () {
          form.querySelectorAll('button[type="submit"], button:not([type]), input[type="submit"]').forEach(function (b) {
            b.setAttribute('data-was-loading', '1');
            if (b.tagName === 'BUTTON') {
              b.dataset.origHtml = b.innerHTML;
              b.innerHTML = '<span class="btn-loading-spinner"></span>Please wait...';
            }
            b.disabled = true;
          });
        }, 0);
      }, false);

      // Internal links / action links: show loader while next page loads
      document.addEventListener('click', function (e) {
        var a = e.target.closest ? e.target.closest('a[href]') : null;
        if (!a || e.defaultPrevented) return;
        if (e.ctrlKey || e.metaKey || e.shiftKey || e.altKey || e.button !== 0) return;
        if (a.target && a.target !== '_self') return;
        if (a.hasAttribute('download') || a.hasAttribute('data-bs-toggle') || a.hasAttribute('data-no-loader')) return;
        var href = a.getAttribute('href') || '';
        if (!href || href.charAt(0) === '#' || /^(javascript:|mailto:|tel:)/i.test(href)) return;
        try {
          var url = new URL(a.href, window.location.href);
          if (url.origin !== window.location.origin) return;
          if (url.pathname === window.location.pathname && url.search === window.location.search && url.hash) return;
        } catch (err) { return; }
        showLoader('Loading...');
      }, false);

      // Safety net: if navigation is cancelled (e.g. file download), don't leave the overlay stuck
      window.addEventListener('beforeunload', function () { startBar(); });
      window.__showLoader = showLoader;
      window.__hideLoader = hideLoader;
    })();

    // ===== Push notifications inside the Android app (Capacitor) =====
    (function () {
      try {
        var C = window.Capacitor;
        if (!window.__LOGGED_IN || !C || !C.Plugins || !C.Plugins.PushNotifications) return;
        var P = C.Plugins.PushNotifications;

        P.addListener('registration', function (t) {
          fetch('/api/device/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'same-origin',
            body: JSON.stringify({ token: t.value, platform: 'android' })
          }).catch(function () {});
        });
        P.addListener('registrationError', function (e) { console.warn('Push registration error', e); });

        // App is open: the system does not show it, so show a banner
        P.addListener('pushNotificationReceived', function (n) {
          var box = document.createElement('div');
          box.style.cssText = 'position:fixed;top:12px;left:12px;right:12px;z-index:100001;background:#0b2545;color:#fff;padding:12px 14px;border-radius:12px;box-shadow:0 6px 18px rgba(0,0,0,.3);font-size:.95rem';
          var h = document.createElement('strong'); h.textContent = n.title || 'Barangay'; box.appendChild(h);
          var p = document.createElement('div'); p.textContent = n.body || ''; box.appendChild(p);
          var u = n.data && n.data.url;
          box.onclick = function () { if (u && u.charAt(0) === '/') window.location.href = u; else box.remove(); };
          document.body.appendChild(box);
          setTimeout(function () { box.remove(); }, 8000);
        });
        // User tapped the notification (app was closed or in the background)
        P.addListener('pushNotificationActionPerformed', function (a) {
          var u = a && a.notification && a.notification.data && a.notification.data.url;
          if (u && u.charAt(0) === '/') window.location.href = u;
        });

        P.createChannel({ id: 'barangay_alerts', name: 'Barangay Alerts', description: 'Announcements, certificates and aid updates', importance: 5, visibility: 1, vibration: true }).catch(function () {});
        P.checkPermissions().then(function (s) {
          if (s.receive === 'prompt' || s.receive === 'prompt-with-rationale') return P.requestPermissions();
          return s;
        }).then(function (s) { if (s && s.receive === 'granted') P.register(); }).catch(function () {});
      } catch (e) {}
    })();

    // Register the service worker (installable app + offline message)
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', function () {
        navigator.serviceWorker.register('/sw.js').catch(function () {});
      });
    }
  </script>
</body>
</html>
`;

// ---------- Resident categories (College Student / Household Head / Senior Citizen / PWD) ----------
const categoryFlags = (b) => ({
  is_college_student: !!b.cat_college,
  is_household_head: !!b.cat_head,
  is_senior_citizen: !!b.cat_senior,
  is_pwd: !!b.cat_pwd
});

const categoryTags = (r) => [
  r.is_college_student && 'College Student',
  r.is_household_head && 'Household Head',
  r.is_senior_citizen && 'Senior Citizen',
  r.is_pwd && 'PWD'
].filter(Boolean);

const renderCategoryCheckboxes = (r = {}, prefix = 'cat') => `
  <div class="row g-2">
    <div class="col-6"><div class="form-check"><input class="form-check-input" type="checkbox" name="cat_college" id="${prefix}College" ${r.is_college_student ? 'checked' : ''}><label class="form-check-label" for="${prefix}College">College Student</label></div></div>
    <div class="col-6"><div class="form-check"><input class="form-check-input" type="checkbox" name="cat_head" id="${prefix}Head" ${r.is_household_head ? 'checked' : ''}><label class="form-check-label" for="${prefix}Head">Household Head</label></div></div>
    <div class="col-6"><div class="form-check"><input class="form-check-input" type="checkbox" name="cat_senior" id="${prefix}Senior" ${r.is_senior_citizen ? 'checked' : ''}><label class="form-check-label" for="${prefix}Senior">Senior Citizen</label></div></div>
    <div class="col-6"><div class="form-check"><input class="form-check-input" type="checkbox" name="cat_pwd" id="${prefix}Pwd" ${r.is_pwd ? 'checked' : ''}><label class="form-check-label" for="${prefix}Pwd">Person with Disability (PWD)</label></div></div>
  </div>`;

// Layout Wrapper with Responsive Sidebar (Pinalaki ang Logos at tinanggal ang outer lines)
const renderAppLayout = (req, activeModule, contentHtml, settings = {}) => {
  const user = req.user || {};
  const isAdmin = ['Super Admin', 'Barangay Admin', 'Barangay Secretary', 'Barangay Staff'].includes(user.role);

  // Related pages are combined under one collapsible category.
  const adminMenu = [
    { id: 'dashboard', label: 'Dashboard', icon: 'bi-speedometer2', link: '/admin/dashboard' },
    { group: 'Residents', icon: 'bi-people', items: [
      { id: 'residents', label: 'Resident Management', icon: 'bi-people', link: '/admin/residents' },
      { id: 'households', label: 'Households', icon: 'bi-house-door', link: '/admin/households' },
      { id: 'puroks', label: 'Puroks', icon: 'bi-geo-alt', link: '/admin/puroks' },
    ]},
    { group: 'Requests & Services', icon: 'bi-journal-check', items: [
      { id: 'certificates', label: 'Certificate Requests', icon: 'bi-file-earmark-text', link: '/admin/certificates' },
      { id: 'blotters', label: 'Blotter Management', icon: 'bi-shield-exclamation', link: '/admin/blotters' },
      { id: 'assistance', label: 'Assistance Requests', icon: 'bi-hand-thumbs-up', link: '/admin/assistance' },
      { id: 'appointments', label: 'Appointments', icon: 'bi-calendar-check', link: '/admin/appointments' },
    ]},
    { group: 'Aid & Sectors', icon: 'bi-box2-heart', items: [
      { id: 'aid', label: 'Aid Distribution', icon: 'bi-box2-heart', link: '/admin/aid' },
      { id: 'seniors', label: 'Senior Citizens', icon: 'bi-person-heart', link: '/admin/seniors' },
      { id: 'pwds', label: 'PWD Management', icon: 'bi-universal-access', link: '/admin/pwds' },
      { id: 'soloparents', label: 'Solo Parents', icon: 'bi-person-badge', link: '/admin/solo-parents' },
    ]},
    { group: 'ID & Scanning', icon: 'bi-qr-code-scan', items: [
      { id: 'id-gen', label: 'Barangay ID Gen', icon: 'bi-card-heading', link: '/admin/id-generator' },
      { id: 'qr-scanner', label: 'QR Scanner', icon: 'bi-qr-code-scan', link: '/scanner' },
      { id: 'scan-only', label: 'Scan-Only Page', icon: 'bi-upc-scan', link: '/scan' },
    ]},
    { group: 'Community', icon: 'bi-megaphone', items: [
      { id: 'announcements', label: 'Announcements', icon: 'bi-megaphone', link: '/admin/announcements' },
      { id: 'events', label: 'Events', icon: 'bi-calendar-event', link: '/admin/events' },
      { id: 'officials', label: 'Barangay Officials', icon: 'bi-person-lines-fill', link: '/admin/officials' },
    ]},
    { group: 'Administration', icon: 'bi-gear', items: [
      { id: 'users', label: 'User Accounts', icon: 'bi-person-gear', link: '/admin/users' },
      { id: 'reports', label: 'Reports', icon: 'bi-bar-chart-line', link: '/admin/reports' },
      { id: 'activity-logs', label: 'Activity Logs', icon: 'bi-clock-history', link: '/admin/activity-logs' },
      { id: 'settings', label: 'System Settings', icon: 'bi-sliders', link: '/admin/settings' },
      { id: 'account', label: 'My Account', icon: 'bi-person-lock', link: '/account' },
    ]},
  ];

  const residentMenu = [
    { id: 'res-dashboard', label: 'Dashboard', icon: 'bi-speedometer2', link: '/resident/dashboard' },
    { group: 'My Account', icon: 'bi-person-circle', items: [
      { id: 'res-profile', label: 'My Profile & Photo', icon: 'bi-person-circle', link: '/resident/profile' },
      ...(user.family_head_user_id ? [] : [{ id: 'res-family', label: 'My Family', icon: 'bi-people', link: '/resident/family' }]),
      { id: 'res-digital-id', label: 'My Digital ID', icon: 'bi-card-checklist', link: '/resident/digital-id' },
      { id: 'res-account', label: 'Account & Password', icon: 'bi-key', link: '/account' },
    ]},
    { group: 'Requests & Services', icon: 'bi-journal-check', items: [
      { id: 'res-certificates', label: 'Request Certificate', icon: 'bi-file-earmark-plus', link: '/resident/certificates' },
      { id: 'res-appointments', label: 'Book Appointment', icon: 'bi-calendar-plus', link: '/resident/appointments' },
      { id: 'res-complaints', label: 'Submit Complaint', icon: 'bi-exclamation-triangle', link: '/resident/complaints' },
      { id: 'res-assistance', label: 'Request Assistance', icon: 'bi-heart-pulse', link: '/resident/assistance' },
      { id: 'res-feedback', label: 'Submit Feedback', icon: 'bi-chat-left-text', link: '/resident/feedback' },
    ]},
    { id: 'res-aid', label: 'My Aid & Relief', icon: 'bi-box2-heart', link: '/resident/aid' },
    { group: 'Community', icon: 'bi-bell', items: [
      { id: 'res-announcements', label: 'Announcements', icon: 'bi-bell', link: '/resident/announcements' },
      { id: 'res-contacts', label: 'Emergency Contacts', icon: 'bi-telephone', link: '/resident/emergency-contacts' },
    ]},
  ];

  const menuItems = isAdmin ? adminMenu : residentMenu;

  const renderMenuLink = (item, sub) => `
    <li class="nav-item">
      <a href="${item.link}" class="nav-link ${sub ? 'sub-link' : ''} ${activeModule === item.id ? 'active' : ''}">
        <i class="bi ${item.icon} me-2"></i> ${item.label}
      </a>
    </li>`;

  const renderMenuFor = (pfx) => menuItems.map((entry, i) => {
    if (!entry.group) return renderMenuLink(entry, false);
    const open = entry.items.some(it => it.id === activeModule);
    return `
    <li class="nav-item">
      <a class="nav-link menu-group-toggle d-flex align-items-center ${open ? '' : 'collapsed'}" data-bs-toggle="collapse" href="#${pfx}menuGroup${i}" role="button" aria-expanded="${open}" aria-controls="${pfx}menuGroup${i}">
        <i class="bi ${entry.icon} me-2"></i> <span class="flex-grow-1">${entry.group}</span>
        <i class="bi bi-chevron-down menu-chevron small"></i>
      </a>
      <div class="collapse ${open ? 'show' : ''}" id="${pfx}menuGroup${i}">
        <ul class="nav flex-column">${entry.items.map(it => renderMenuLink(it, true)).join('')}</ul>
      </div>
    </li>`;
  }).join('');
  const renderMenu = renderMenuFor('d');
  const renderMobileMenu = renderMenuFor('m');

  const bottomItems = [
    { id: 'res-dashboard', label: 'Home', icon: 'bi-house-door', link: '/resident/dashboard' },
    { id: 'res-digital-id', label: 'My ID', icon: 'bi-qr-code', link: '/resident/digital-id' },
    { id: 'res-certificates', label: 'Request', icon: 'bi-file-earmark-plus', link: '/resident/certificates' },
    { id: 'res-aid', label: 'Aid', icon: 'bi-box2-heart', link: '/resident/aid' },
  ];
  const bottomNav = isAdmin ? '' : `
    <nav class="bottom-nav no-print">
      ${bottomItems.map(b => `<a href="${b.link}" class="${activeModule === b.id ? 'active' : ''}"><i class="bi ${b.icon}"></i>${b.label}</a>`).join('')}
      <button type="button" data-bs-toggle="offcanvas" data-bs-target="#mobileMenu"><i class="bi bi-list"></i>More</button>
    </nav>`;

  return `
    ${renderSystemHead(settings.barangay_name || 'Barangay Portal')}
    <div class="container-fluid p-0">
      <div class="row g-0">
        <!-- Sidebar Navigation -->
        <div class="mobile-topbar no-print">
          ${settings.barangay_logo ? `<img src="${settings.barangay_logo}" alt="">` : '<i class="bi bi-building fs-4"></i>'}
          <div class="t-name">${settings.barangay_name || 'BARANGAY PORTAL'}<small>${user.full_name || user.role || 'User'}</small></div>
          <button type="button" class="btn-menu" data-bs-toggle="offcanvas" data-bs-target="#mobileMenu" aria-label="Menu"><i class="bi bi-list"></i></button>
        </div>
        <div class="offcanvas offcanvas-start mobile-menu no-print" tabindex="-1" id="mobileMenu">
          <div class="offcanvas-header">
            <h6 class="offcanvas-title fw-bold">${settings.barangay_name || 'BARANGAY PORTAL'}</h6>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Close"></button>
          </div>
          <div class="offcanvas-body pt-0">
            <ul class="nav nav-pills flex-column">${renderMobileMenu}</ul>
            <hr class="text-white-50">
            <a class="nav-link text-white" href="/account"><i class="bi bi-key me-2"></i>Account &amp; Password</a>
            <a class="nav-link text-white" href="/logout"><i class="bi bi-box-arrow-right me-2"></i>Sign out</a>
          </div>
        </div>
        <div class="col-md-3 col-lg-2 sidebar d-none d-md-flex flex-column p-3 no-print">
          <div class="d-flex align-items-center mb-4 px-2">
            ${settings.barangay_logo ? `<img src="${settings.barangay_logo}" class="me-2 rounded-circle shadow-sm" style="width: 70px; height: 70px; object-fit: cover; border: none;">` : '<i class="bi bi-building fs-1 me-2 text-accent-green"></i>'}
            <div>
              <h6 class="m-0 fw-bold">${settings.barangay_name || 'BARANGAY PORTAL'}</h6>
              <small class="text-white-50">${user.full_name || user.role || 'User'}</small>
            </div>
          </div>
          <hr class="text-white-50 mt-0">
          <ul class="nav nav-pills flex-column mb-auto overflow-y-auto" style="max-height: calc(100vh - 180px);">
            ${renderMenu}
          </ul>
          <hr class="text-white-50">
          <div class="dropdown">
            <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle px-2" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
              <i class="bi bi-person-circle fs-4 me-2"></i>
              <strong>${user.full_name || user.username}</strong>
            </a>
            <ul class="dropdown-menu dropdown-menu-dark text-small shadow">
              <li><a class="dropdown-item" href="/account"><i class="bi bi-key me-2"></i> Account &amp; Password</a></li>
              <li><a class="dropdown-item" href="/logout"><i class="bi bi-box-arrow-right me-2"></i> Sign out</a></li>
            </ul>
          </div>
        </div>

        <!-- Main Content Area -->
        <div class="col-md-9 col-lg-10 p-4 main-pane ${isAdmin ? '' : 'has-bottom-nav'}">
          <div class="d-none d-md-flex justify-content-between align-items-center mb-4 pb-2 border-bottom no-print">
            <h4 class="fw-bold text-primary-blue m-0">${settings.system_name || 'Barangay Resident Management System'}</h4>
            <span class="badge bg-accent-green px-3 py-2 text-white"><i class="bi bi-check-circle me-1"></i> System Online</span>
          </div>
          ${contentHtml}
        </div>
      </div>
    </div>
    ${bottomNav}
    <script>window.__LOGGED_IN = true;</script>
    ${renderSystemFooter()}
  `;
};

// ==========================================
// SYSTEM SETUP & INITIAL ADMISSION GUARD
// ==========================================
app.use(async (req, res, next) => {
  if (req.path.startsWith('/api/') || req.path.startsWith('/public/')) return next();
  if (['/manifest.webmanifest', '/app-icon.svg', '/sw.js', '/healthz'].includes(req.path)) return next();
  try {
    const { data: settings } = await supabase.from('system_settings').select('*').single();
    if ((!settings || !settings.setup_completed) && req.path !== '/setup') {
      return res.redirect('/setup');
    }
  } catch (e) {
    console.error('Setup Check Error:', e);
  }
  next();
});

// Helper: Fetch Global Barangay Settings
const getSettings = async () => {
  const { data } = await supabase.from('system_settings').select('*').single();
  return data || {};
};

// ==========================================
// ROUTE 1: SYSTEM SETUP
// ==========================================
app.get('/setup', async (req, res) => {
  const settings = await getSettings();
  if (settings && settings.setup_completed) return res.redirect('/login');

  res.send(`
    ${renderSystemHead('Initial Setup')}
    <div class="container d-flex justify-content-center align-items-center min-vh-100" style="background: linear-gradient(135deg, #e1f5fe 0%, #d9edf7 100%);">
      <div class="card card-custom p-4 shadow-lg" style="max-width: 550px; width: 100%;">
        <div class="text-center mb-4">
          <i class="bi bi-gear-fill text-primary-blue fs-1"></i>
          <h3 class="fw-bold text-primary-blue mt-2">Initial System Setup</h3>
          <p class="text-muted">Configure your Barangay details and create the Super Administrator account.</p>
        </div>
        <form action="/api/setup" method="POST">
          <h6 class="fw-bold text-accent-green border-bottom pb-2 mb-3">1. Barangay Details</h6>
          <div class="mb-3">
            <label class="form-label">Barangay Name</label>
            <input type="text" name="barangay_name" class="form-control" required placeholder="e.g. Barangay Central">
          </div>
          <div class="row">
            <div class="col-md-6 mb-3">
              <label class="form-label">Municipality / City</label>
              <input type="text" name="municipality" class="form-control" required placeholder="Angeles City">
            </div>
            <div class="col-md-6 mb-3">
              <label class="form-label">Province</label>
              <input type="text" name="province" class="form-control" required placeholder="Pampanga">
            </div>
          </div>
          <h6 class="fw-bold text-accent-green border-bottom pb-2 mb-3 mt-4">2. Super Admin Credentials</h6>
          <div class="mb-3">
            <label class="form-label">Full Name</label>
            <input type="text" name="full_name" class="form-control" required placeholder="Hon. Admin Name">
          </div>
          <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" name="username" class="form-control" required placeholder="admin">
          </div>
          <div class="mb-3">
            <label class="form-label">Email Address</label>
            <input type="email" name="email" class="form-control" required placeholder="admin@barangay.gov.ph">
          </div>
          <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" required minlength="6">
          </div>
          <button type="submit" class="btn btn-primary-custom w-100 py-2 mt-3 fw-bold">Complete System Setup</button>
        </form>
      </div>
    </div>
    ${renderSystemFooter()}
  `);
});

app.post('/api/setup', async (req, res) => {
  const { barangay_name, municipality, province, full_name, username, email, password } = req.body;
  try {
    const { data: existingSettings } = await supabase.from('system_settings').select('*').single();
    if (existingSettings && existingSettings.setup_completed) {
      return res.status(400).send('Setup has already been completed.');
    }

    const salt = await bcrypt.genSalt(10);
    const password_hash = await bcrypt.hash(password, salt);

    const { data: user, error: userError } = await supabase.from('users').insert([{
      username, email, password_hash, full_name, role: 'Super Admin', status: 'Active'
    }]).select().single();

    if (userError) throw userError;

    if (existingSettings) {
      await supabase.from('system_settings').update({
        barangay_name, municipality, province, setup_completed: true, updated_at: new Date()
      }).eq('id', existingSettings.id);
    } else {
      await supabase.from('system_settings').insert([{
        barangay_name, municipality, province, setup_completed: true
      }]);
    }

    await supabase.from('puroks').insert([
      { name: 'Purok 1', description: 'Zone 1' },
      { name: 'Purok 2', description: 'Zone 2' },
      { name: 'Purok 3', description: 'Zone 3' }
    ]);

    res.send(`
      ${renderSystemHead('Setup Complete')}
      <div class="container text-center pt-5">
        <div class="card p-5 shadow-lg d-inline-block bg-light-green">
          <i class="bi bi-check-circle-fill text-accent-green display-1"></i>
          <h2 class="mt-3 text-primary-blue fw-bold">System Successfully Setup!</h2>
          <p class="text-muted">Administrator account has been initialized.</p>
          <a href="/login" class="btn btn-primary-custom px-4 py-2 mt-3 fw-bold">Go to Login Page</a>
        </div>
      </div>
      ${renderSystemFooter()}
    `);
  } catch (err) {
    console.error('Setup Post Error:', err);
    res.status(500).send('Error completing setup: ' + err.message);
  }
});

// ==========================================
// ROUTE 2: REDESIGNED LOGIN PAGE (GRADIENT GREEN (TOP) & BLUE (BOTTOM) + HORIZONTAL SPLIT RECTANGLE CARD)
// ==========================================
app.get('/login', async (req, res) => {
  const settings = await getSettings();
  const bgImg = DEFAULT_LOGIN_BG;
  
  const { data: officials } = await supabase.from('barangay_officials').select('*');
  const { data: publicAnnouncements } = await supabase.from('announcements').select('*').order('created_at', { ascending: false }).limit(6);

  res.send(`
    ${renderSystemHead('Login')}
    <style>
      html {
        scroll-behavior: smooth;
      }
      body {
        background-color: #0b2545;
        overflow-x: hidden;
      }
      .login-section {
        min-height: 100vh;
        /* Green sa taas, Blue sa baba, hindi masyadong madilim */
        background: linear-gradient(180deg, rgba(46, 204, 113, 0.75), rgba(32, 84, 147, 0.75)), url('${bgImg}');
        background-color: #205493;
        background-size: cover;
        background-position: center;
        background-attachment: fixed;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 40px 20px;
        position: relative;
      }
      /* Horizontal rectangle login fields with split in the middle, blue and green background colors */
      .horizontal-login-card {
        background: linear-gradient(135deg, #d9edf7 0%, #e1f5fe 100%);
        border: 2px solid rgba(46, 204, 113, 0.5);
        border-radius: 20px;
        box-shadow: 0 20px 40px rgba(32, 84, 147, 0.25);
        max-width: 900px;
        width: 100%;
        overflow: hidden;
        transition: transform 0.3s ease;
      }
      .horizontal-login-card:hover {
        transform: translateY(-4px);
      }
      .brand-logo-img {
        width: 140px;
        height: 140px;
        object-fit: cover;
        border-radius: 50%;
        border: none;
        box-shadow: 0 6px 15px rgba(32, 84, 147, 0.25);
      }
      .form-control-horizontal {
        height: 48px;
        border-radius: 8px;
        font-size: 1rem;
      }
      .input-group-horizontal {
        border-radius: 8px;
        overflow: hidden;
      }
      .input-group-text {
        background-color: #205493 !important;
        color: white !important;
        border: 1px solid #ced4da;
        width: 48px;
        justify-content: center;
      }
      .btn-glow {
        background-color: #205493;
        border: none;
        border-radius: 10px;
        padding: 12px;
        font-size: 1rem;
        letter-spacing: 0.5px;
        box-shadow: 0 4px 15px rgba(32, 84, 147, 0.4);
        transition: all 0.25s ease;
      }
      .btn-glow:hover {
        background-color: #0b2545;
        box-shadow: 0 6px 20px rgba(11, 37, 69, 0.6);
      }
      .scroll-down-hint {
        position: absolute;
        bottom: 25px;
        color: #ffffff;
        text-align: center;
        animation: bounce 2s infinite;
        text-decoration: none;
        font-weight: 700;
        background: rgba(11, 37, 69, 0.8);
        padding: 8px 18px;
        border-radius: 30px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.2);
      }
      @keyframes bounce {
        0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
        40% { transform: translateY(-8px); }
        60% { transform: translateY(-4px); }
      }
      .officials-section {
        padding: 90px 20px;
        background: linear-gradient(180deg, #d9edf7 0%, #e1f5fe 100%);
      }
      .official-card {
        border-radius: 16px;
        border: 1px solid #a3e4d7;
        background: white;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
      }
      .official-card:hover {
        transform: translateY(-6px);
        box-shadow: 0 12px 24px rgba(32, 84, 147, 0.15);
      }
      .official-photo {
        width: 130px;
        height: 130px;
        object-fit: cover;
        border-radius: 50%;
        border: none;
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      }
      .btn-create-account {
        background-color: #2ecc71;
        border: none;
        border-radius: 10px;
        padding: 12px;
        font-size: 1rem;
        letter-spacing: 0.5px;
        color: #ffffff;
        box-shadow: 0 4px 15px rgba(46, 204, 113, 0.4);
        transition: all 0.25s ease;
      }
      .btn-create-account:hover {
        background-color: #27ae60;
        color: #ffffff;
        box-shadow: 0 6px 20px rgba(39, 174, 96, 0.55);
      }
      .about-section {
        padding: 90px 20px;
        background: #ffffff;
      }
      .about-card {
        border-radius: 16px;
        border: 1px solid #a3e4d7;
        background: linear-gradient(135deg, #f4fbff 0%, #e1f5fe 100%);
        height: 100%;
      }
      .about-icon {
        width: 56px;
        height: 56px;
        border-radius: 50%;
        background: linear-gradient(135deg, #205493 0%, #2ecc71 100%);
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        margin: 0 auto 12px;
      }
      .announcements-section {
        padding: 90px 20px;
        background: linear-gradient(180deg, #e1f5fe 0%, #d9edf7 100%);
      }
      .announcement-card {
        border-radius: 14px;
        background: #ffffff;
        box-shadow: 0 6px 18px rgba(32, 84, 147, 0.1);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
      }
      @media (max-width: 767.98px) {
        .login-section { padding: 16px 12px 70px; background-attachment: scroll; }
        .horizontal-login-card { border-radius: 14px; }
        .horizontal-login-card .p-5 { padding: 18px !important; }
        .brand-logo-img { width: 84px; height: 84px; }
        .horizontal-login-card h3 { font-size: 1.15rem; }
        .horizontal-login-card h4 { font-size: 1.1rem; margin-bottom: .8rem !important; }
        .form-control-horizontal { height: 42px; font-size: 16px; }
        .about-section, .announcements-section, .officials-section { padding: 36px 14px; }
        .official-photo { width: 96px; height: 96px; }
        .scroll-down-hint { bottom: 10px; padding: 5px 12px; font-size: .75rem; }
      }
      .announcement-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 12px 24px rgba(32, 84, 147, 0.18);
      }
    </style>

    <!-- SECTION 1: LOGIN CARD CONTAINER (Horizontal Split Rectangle with Blue/Green BG) -->
    <div class="login-section">
      <div class="horizontal-login-card">
        <div class="row g-0">
          <!-- Left Side: Logo and Information -->
          <div class="col-md-5 p-5 d-flex flex-column justify-content-center align-items-center text-center text-white" style="background: linear-gradient(135deg, #205493 0%, #2ecc71 100%);">
            ${settings.barangay_logo ? `<img src="${settings.barangay_logo}" class="brand-logo-img mb-3">` : '<i class="bi bi-building-fill text-white display-3 mb-2"></i>'}
            <h3 class="fw-bold m-0 text-white">${settings.barangay_name || 'BARANGAY PORTAL'}</h3>
            <p class="small mt-2 mb-3 opacity-75">Resident & Administration System. Fast, secure, and accessible community governance.</p>
            <span class="badge bg-white text-dark px-3 py-2 rounded-pill shadow-sm"><i class="bi bi-shield-check me-1 text-success"></i> Official Portal</span>
          </div>

          <!-- Right Side: Username, Password, Are you a resident without an account?, Register as Resident -->
          <div class="col-md-7 p-5 d-flex flex-column justify-content-center bg-white">
            <h4 class="fw-bold text-primary-blue mb-4"><i class="bi bi-box-arrow-in-right me-2"></i>Sign In</h4>

            <form action="/api/login" method="POST">
              <div class="mb-3">
                <label class="form-label fw-semibold text-secondary small">USERNAME OR EMAIL</label>
                <div class="input-group input-group-horizontal">
                  <span class="input-group-text"><i class="bi bi-person-fill fs-5"></i></span>
                  <input type="text" name="identifier" class="form-control form-control-horizontal border-start-0" required placeholder="Enter username or email">
                </div>
              </div>
              <div class="mb-4">
                <label class="form-label fw-semibold text-secondary small">PASSWORD</label>
                <div class="input-group input-group-horizontal">
                  <span class="input-group-text"><i class="bi bi-lock-fill fs-5"></i></span>
                  <input type="password" name="password" class="form-control form-control-horizontal border-start-0" required placeholder="Enter your password">
                </div>
              </div>
              <button type="submit" class="btn btn-primary btn-glow w-100 fw-bold text-white"><i class="bi bi-box-arrow-in-right me-2"></i>Sign In to Account</button>
            </form>

            <div class="text-center mt-4 border-top pt-3">
              <p class="small text-muted mb-2">New here? Residents need an account to use the portal.</p>
              <a href="/register" class="btn btn-create-account w-100 fw-bold"><i class="bi bi-person-plus-fill me-2"></i>Create Account</a>
              <div class="mt-2 small"><a href="/terms" target="_blank" class="text-muted text-decoration-none"><i class="bi bi-file-earmark-text me-1"></i>Terms and Conditions</a></div>
            </div>
          </div>
        </div>
      </div>

      <a href="#about-section" class="scroll-down-hint mt-4">
        <span class="d-block small">Scroll down for Barangay Info, Announcements & Officials</span>
        <i class="bi bi-chevron-down fs-5"></i>
      </a>
    </div>

    <!-- SECTION 2: ABOUT THE BARANGAY -->
    <div id="about-section" class="about-section">
      <div class="container">
        <div class="text-center mb-5">
          <h2 class="fw-bold" style="color: #0b2545;"><i class="bi bi-info-circle-fill me-2 text-accent-green"></i>About ${escHtml(settings.barangay_name || 'Our Barangay')}</h2>
          <p class="text-muted">Get to know your barangay and how to reach us.</p>
          <div class="mx-auto bg-accent-green" style="height: 4px; width: 80px; border-radius: 2px;"></div>
        </div>
        <div class="row g-4 justify-content-center">
          <div class="col-md-6 col-lg-3">
            <div class="card about-card p-4 text-center shadow-sm">
              <div class="about-icon"><i class="bi bi-building"></i></div>
              <h6 class="fw-bold text-primary-blue">Barangay</h6>
              <p class="mb-0 text-dark">${escHtml(settings.barangay_name || 'Not yet provided')}</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-3">
            <div class="card about-card p-4 text-center shadow-sm">
              <div class="about-icon"><i class="bi bi-geo-alt-fill"></i></div>
              <h6 class="fw-bold text-primary-blue">Location</h6>
              <p class="mb-0 text-dark">${escHtml([settings.municipality, settings.province].filter(Boolean).join(', ') || 'Not yet provided')}</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-3">
            <div class="card about-card p-4 text-center shadow-sm">
              <div class="about-icon"><i class="bi bi-person-badge-fill"></i></div>
              <h6 class="fw-bold text-primary-blue">Barangay Captain</h6>
              <p class="mb-0 text-dark">${escHtml(settings.barangay_captain || 'Not yet provided')}</p>
            </div>
          </div>
          <div class="col-md-6 col-lg-3">
            <div class="card about-card p-4 text-center shadow-sm">
              <div class="about-icon"><i class="bi bi-telephone-fill"></i></div>
              <h6 class="fw-bold text-primary-blue">Emergency Hotline</h6>
              <p class="mb-0 text-dark">${escHtml(settings.contact_number || 'Not yet provided')}</p>
            </div>
          </div>
        </div>
        <div class="text-center mt-5">
          <p class="text-muted mb-3">Through this portal, residents can request certificates, book appointments, file complaints, apply for assistance, and view their Digital Barangay ID.</p>
          <a href="/register" class="btn btn-create-account px-4 fw-bold"><i class="bi bi-person-plus-fill me-2"></i>Create Account</a>
        </div>
      </div>
    </div>

    <!-- SECTION 3: PUBLIC ANNOUNCEMENTS -->
    <div id="announcements-section" class="announcements-section">
      <div class="container">
        <div class="text-center mb-5">
          <h2 class="fw-bold" style="color: #0b2545;"><i class="bi bi-megaphone-fill me-2 text-accent-green"></i>Barangay Announcements</h2>
          <p class="text-muted">The latest news and advisories from your barangay.</p>
          <div class="mx-auto bg-accent-green" style="height: 4px; width: 80px; border-radius: 2px;"></div>
        </div>
        <div class="row g-4 justify-content-center">
          ${(publicAnnouncements || []).map(a => `
            <div class="col-md-6 col-lg-4">
              <div class="card announcement-card p-4 h-100 border-start border-4 ${a.priority === 'Emergency' ? 'border-danger' : 'border-primary'}">
                <div class="d-flex justify-content-between align-items-center mb-2">
                  <small class="text-secondary"><i class="bi bi-calendar3 me-1"></i>${a.created_at ? new Date(a.created_at).toLocaleDateString('en-PH', { year: 'numeric', month: 'long', day: 'numeric' }) : ''}</small>
                  <span class="badge ${a.priority === 'Emergency' ? 'bg-danger' : 'bg-primary'} text-white">${escHtml(a.priority || 'Normal')}</span>
                </div>
                <h5 class="fw-bold text-primary-blue">${escHtml(a.title)}</h5>
                <p class="text-muted small mb-0" style="white-space: pre-line;">${escHtml(a.content)}</p>
              </div>
            </div>
          `).join('') || `
            <div class="col-12 text-center text-muted py-4">
              <i class="bi bi-megaphone fs-1 text-secondary"></i>
              <p class="mt-2">No announcements at this time. Please check back soon.</p>
            </div>
          `}
        </div>
      </div>
    </div>

    <!-- SECTION 4: SCROLLABLE BARANGAY OFFICIALS SHOWCASE WITH PICTURES -->
    <div id="officials-section" class="officials-section">
      <div class="container">
        <div class="text-center mb-5">
          <h2 class="fw-bold" style="color: #0b2545;"><i class="bi bi-person-lines-fill me-2 text-accent-green"></i>Barangay Officials & Council</h2>
          <p class="text-muted">Dedicated leaders serving our community with transparency, diligence, and care.</p>
          <div class="mx-auto bg-accent-green" style="height: 4px; width: 80px; border-radius: 2px;"></div>
        </div>

        <div class="row g-4 justify-content-center">
          ${(officials || []).map(o => `
            <div class="col-md-4 col-lg-3">
              <div class="card official-card p-4 text-center h-100 shadow-sm">
                <img src="${o.photo_url || 'https://via.placeholder.com/130'}" class="official-photo mx-auto mb-3" alt="${o.name}">
                <h5 class="fw-bold text-dark mb-1">${o.name}</h5>
                <span class="badge bg-primary-blue px-3 py-2 rounded-pill mt-1 mb-2 text-white">${o.position}</span>
                ${o.signature_url ? `<img src="${o.signature_url}" class="d-block mx-auto mt-2" style="height: 32px; object-fit: contain;" alt="Signature">` : ''}
              </div>
            </div>
          `).join('') || `
            <div class="col-12 text-center text-muted py-5">
              <i class="bi bi-people fs-1 text-secondary"></i>
              <p class="mt-2">No official records available at this time. Admin can add officials in the dashboard.</p>
            </div>
          `}
        </div>
      </div>
    </div>
    ${renderSystemFooter()}
  `);
});

app.post('/api/login', async (req, res) => {
  const { identifier, password } = req.body;
  try {
    const { data: user, error } = await supabase.from('users').select('*').or(`username.eq.${identifier},email.eq.${identifier}`).single();
    if (error || !user) {
      return res.status(400).send('<script>alert("Invalid identifier or password."); window.location="/login";</script>');
    }

    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      return res.status(400).send('<script>alert("Invalid identifier or password."); window.location="/login";</script>');
    }

    if (user.status !== 'Active') {
      return res.status(403).send('<script>alert("Your account is pending approval or disabled."); window.location="/login";</script>');
    }

    const token = jwt.sign({ userId: user.id, role: user.role }, JWT_SECRET, { expiresIn: '12h' });
    res.cookie('token', token, { ...COOKIE_OPTS, maxAge: 12 * 3600 * 1000 });

    await supabase.from('login_history').insert([{ user_id: user.id, status: 'Success' }]);
    await logActivity(user.id, 'User Login', 'User authenticated successfully.');

    if (['Super Admin', 'Barangay Admin', 'Barangay Secretary', 'Barangay Staff'].includes(user.role)) {
      const returnTo = req.cookies.return_to;
      res.clearCookie('return_to');
      if (returnTo && /^\/(scan|scanner)(\?.*)?$/.test(returnTo)) return res.redirect(returnTo);
      return res.redirect('/admin/dashboard');
    } else {
      return res.redirect(user.must_change_password ? '/account?msg=must_change' : '/resident/dashboard');
    }
  } catch (err) {
    console.error('Login Error:', err);
    res.status(500).send('Server error during authentication.');
  }
});

app.get('/register', async (req, res) => {
  const { data: puroks } = await supabase.from('puroks').select('*');
  const settings = await getSettings();

  res.send(`
    ${renderSystemHead('Resident Registration')}
    <div class="container py-5">
      <div class="row justify-content-center">
        <div class="col-md-8">
          <div class="card card-custom p-4 shadow">
            <div class="text-center mb-4">
              <h3 class="fw-bold text-primary-blue"><i class="bi bi-person-badge me-2"></i>Resident Public Registration</h3>
              <p class="text-muted">Complete the official form. Registrations undergo approval by Barangay Officials.</p>
            </div>
            <form action="/api/register" method="POST" enctype="multipart/form-data">
              <h6 class="fw-bold text-accent-green border-bottom pb-2 mb-3">Personal Information</h6>
              <div class="row">
                <div class="col-md-4 mb-3">
                  <label class="form-label">First Name *</label>
                  <input type="text" name="first_name" class="form-control" required placeholder="First Name">
                </div>
                <div class="col-md-4 mb-3">
                  <label class="form-label">Middle Name</label>
                  <input type="text" name="middle_name" class="form-control" placeholder="Middle Name">
                </div>
                <div class="col-md-4 mb-3">
                  <label class="form-label">Last Name *</label>
                  <input type="text" name="last_name" class="form-control" required placeholder="Last Name">
                </div>
              </div>
              <div class="row">
                <div class="col-md-3 mb-3">
                  <label class="form-label">Suffix</label>
                  <input type="text" name="suffix" class="form-control" placeholder="e.g. Jr., III">
                </div>
                <div class="col-md-3 mb-3">
                  <label class="form-label">Date of Birth *</label>
                  <input type="date" name="date_of_birth" class="form-control" required>
                </div>
                <div class="col-md-3 mb-3">
                  <label class="form-label">Gender *</label>
                  <select name="gender" class="form-select" required>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                </div>
                <div class="col-md-3 mb-3">
                  <label class="form-label">Civil Status *</label>
                  <select name="civil_status" class="form-select" required>
                    <option value="Single">Single</option>
                    <option value="Married">Married</option>
                    <option value="Widowed">Widowed</option>
                    <option value="Separated">Separated</option>
                  </select>
                </div>
              </div>

              <h6 class="fw-bold text-accent-green border-bottom pb-2 mb-3 mt-3">Address & Contact</h6>
              <div class="row">
                <div class="col-md-6 mb-3">
                  <label class="form-label">Purok *</label>
                  <select name="purok_id" class="form-select" required>
                    ${(puroks || []).map(p => `<option value="${p.id}">${p.name}</option>`).join('')}
                  </select>
                </div>
                <div class="col-md-6 mb-3">
                  <label class="form-label">Complete House Address *</label>
                  <input type="text" name="address" class="form-control" required placeholder="House No., Street Name">
                </div>
              </div>
              <div class="row">
                <div class="col-md-6 mb-3">
                  <label class="form-label">Contact Number *</label>
                  <input type="text" name="contact_number" class="form-control" required placeholder="09XXXXXXXXX">
                </div>
                <div class="col-md-6 mb-3">
                  <label class="form-label">Occupation</label>
                  <input type="text" name="occupation" class="form-control" placeholder="Occupation">
                </div>
              </div>

              <div class="alert alert-info small py-2 mt-2">
                <i class="bi bi-info-circle me-1"></i> <strong>Only the head of the family registers.</strong> Add your spouse, children, parents and other household members below. Each of them will be recorded as a resident and will receive their own Barangay ID once approved.
              </div>

              <h6 class="fw-bold text-accent-green border-bottom pb-2 mb-3 mt-3">Your Category (Head of Family)</h6>
              <p class="small text-muted mb-2">Tick all that apply to you. These help the barangay decide who qualifies for aid programs.</p>
              <div class="mb-3">
                <div class="row g-2">
                  <div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox" name="cat_college" id="regCatCollege"><label class="form-check-label" for="regCatCollege">College Student</label></div></div>
                  <div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox" name="cat_senior" id="regCatSenior"><label class="form-check-label" for="regCatSenior">Senior Citizen</label></div></div>
                  <div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox" name="cat_pwd" id="regCatPwd"><label class="form-check-label" for="regCatPwd">Person with Disability (PWD)</label></div></div>
                </div>
              </div>

              <h6 class="fw-bold text-accent-green border-bottom pb-2 mb-3 mt-3">Household</h6>
              <div class="mb-3">
                <label class="form-label">Household Name *</label>
                <input type="text" name="household_name" id="hhName" class="form-control" required maxlength="100" placeholder="e.g. Dela Cruz Family">
                <small class="text-muted">Choose a name for your household, such as the family surname. You will be recorded as the Head of Household.</small>
              </div>

              <h6 class="fw-bold text-accent-green border-bottom pb-2 mb-2 mt-4">Family Members</h6>
              <p class="small text-muted mb-2">Add your spouse, children (especially college students or PWD), your mother or father (if senior citizens), and any other household members. Everyone listed becomes a resident with an ID. You can leave this empty if you live alone.</p>
              <div id="memberList"></div>
              <button type="button" id="addMemberBtn" class="btn btn-outline-primary btn-sm mb-3"><i class="bi bi-person-plus me-1"></i> Add Family Member</button>

              <script>
                (function () {
                  var list = document.getElementById('memberList');
                  var addBtn = document.getElementById('addMemberBtn');
                  var MAX = 15, counter = 0;

                  function esc(t) { return String(t); }
                  function opts(arr) {
                    return arr.map(function (o) { return '<option value="' + o + '">' + o + '</option>'; }).join('');
                  }
                  function chk(i, key, id, label) {
                    return '<div class="col-md-4"><div class="form-check"><input class="form-check-input" type="checkbox" name="members[' + i + '][' + key + ']" id="m' + i + id + '"><label class="form-check-label small" for="m' + i + id + '">' + label + '</label></div></div>';
                  }
                  function renumber() {
                    var rows = list.querySelectorAll('.member-row');
                    rows.forEach(function (r, idx) { r.querySelector('.member-title').textContent = 'Family Member #' + (idx + 1); });
                    addBtn.disabled = rows.length >= MAX;
                  }
                  function addMember() {
                    if (list.querySelectorAll('.member-row').length >= MAX) return;
                    var i = counter++;
                    var div = document.createElement('div');
                    div.className = 'card p-3 mb-3 member-row border-primary';
                    div.innerHTML =
                      '<div class="d-flex justify-content-between align-items-center mb-2">' +
                        '<strong class="member-title text-primary-blue"></strong>' +
                        '<button type="button" class="btn btn-sm btn-outline-danger remove-member"><i class="bi bi-trash"></i> Remove</button>' +
                      '</div>' +
                      '<div class="row g-2">' +
                        '<div class="col-md-3"><label class="form-label small mb-0">Relationship *</label><select name="members[' + i + '][relationship]" class="form-select form-select-sm" required>' + opts(['Spouse', 'Child', 'Mother', 'Father', 'Sibling', 'Grandparent', 'Other Relative']) + '</select></div>' +
                        '<div class="col-md-3"><label class="form-label small mb-0">First Name *</label><input type="text" name="members[' + i + '][first_name]" class="form-control form-control-sm" required></div>' +
                        '<div class="col-md-3"><label class="form-label small mb-0">Middle Name</label><input type="text" name="members[' + i + '][middle_name]" class="form-control form-control-sm"></div>' +
                        '<div class="col-md-3"><label class="form-label small mb-0">Last Name *</label><input type="text" name="members[' + i + '][last_name]" class="form-control form-control-sm" required></div>' +
                        '<div class="col-md-2"><label class="form-label small mb-0">Suffix</label><input type="text" name="members[' + i + '][suffix]" class="form-control form-control-sm"></div>' +
                        '<div class="col-md-3"><label class="form-label small mb-0">Date of Birth *</label><input type="date" name="members[' + i + '][date_of_birth]" class="form-control form-control-sm" required></div>' +
                        '<div class="col-md-2"><label class="form-label small mb-0">Gender *</label><select name="members[' + i + '][gender]" class="form-select form-select-sm">' + opts(['Male', 'Female']) + '</select></div>' +
                        '<div class="col-md-2"><label class="form-label small mb-0">Civil Status *</label><select name="members[' + i + '][civil_status]" class="form-select form-select-sm">' + opts(['Single', 'Married', 'Widowed', 'Separated']) + '</select></div>' +
                        '<div class="col-md-3"><label class="form-label small mb-0">Contact Number</label><input type="text" name="members[' + i + '][contact_number]" class="form-control form-control-sm" placeholder="Optional"></div>' +
                        '<div class="col-md-6"><label class="form-label small mb-0">Photo <span class="text-muted">(optional, shown on their ID)</span></label><div class="d-flex align-items-center gap-2"><input type="file" name="member_photo_' + i + '" accept="image/*" class="form-control form-control-sm member-photo"><img class="member-preview rounded-circle d-none" alt="" style="width:40px;height:40px;object-fit:cover;"></div></div>' +
                        '<input type="hidden" name="members[' + i + '][photo_key]" value="' + i + '">' +
                        '<div class="col-md-6 d-flex align-items-end"><div class="form-check"><input class="form-check-input" type="checkbox" name="members[' + i + '][create_account]" id="m' + i + 'Acct" checked><label class="form-check-label small" for="m' + i + 'Acct">Create a login account for this member (email and temporary password are generated)</label></div></div>' +
                        '<div class="col-12 mt-2"><span class="small fw-bold">Category:</span></div>' +
                        chk(i, 'cat_college', 'College', 'College Student') +
                        chk(i, 'cat_senior', 'Senior', 'Senior Citizen') +
                        chk(i, 'cat_pwd', 'Pwd', 'PWD') +
                      '</div>';
                    div.querySelector('.remove-member').addEventListener('click', function () {
                      div.remove();
                      renumber();
                    });
                    list.appendChild(div);
                    renumber();
                    var first = div.querySelector('input[type="text"]');
                    if (first) first.focus();
                  }
                  addBtn.addEventListener('click', addMember);

                  // Shrink each chosen photo (max 600px, JPEG) before upload and show a small preview
                  list.addEventListener('change', function (ev) {
                    var inp = ev.target;
                    if (!inp.classList || !inp.classList.contains('member-photo') || !inp.files || !inp.files[0]) return;
                    var f = inp.files[0];
                    if (f.type.indexOf('image/') !== 0) { alert('Please choose an image file (JPG or PNG).'); inp.value = ''; return; }
                    var url = URL.createObjectURL(f), img = new Image();
                    img.onload = function () {
                      var sc = Math.min(1, 600 / Math.max(img.width, img.height));
                      var cv = document.createElement('canvas');
                      cv.width = Math.max(1, Math.round(img.width * sc));
                      cv.height = Math.max(1, Math.round(img.height * sc));
                      var ctx = cv.getContext('2d');
                      ctx.fillStyle = '#ffffff';
                      ctx.fillRect(0, 0, cv.width, cv.height);
                      ctx.drawImage(img, 0, 0, cv.width, cv.height);
                      var pv = inp.parentNode.querySelector('.member-preview');
                      if (pv) { pv.src = cv.toDataURL('image/jpeg', 0.6); pv.classList.remove('d-none'); }
                      cv.toBlob(function (blob) {
                        URL.revokeObjectURL(url);
                        if (!blob) return;
                        try {
                          var dt = new DataTransfer();
                          dt.items.add(new File([blob], 'photo.jpg', { type: 'image/jpeg' }));
                          inp.files = dt.files;
                        } catch (e) { /* keep the original file */ }
                      }, 'image/jpeg', 0.85);
                    };
                    img.onerror = function () { URL.revokeObjectURL(url); };
                    img.src = url;
                  });
                })();
              </script>

              <h6 class="fw-bold text-accent-green border-bottom pb-2 mb-3 mt-3">Account Credentials</h6>
              <div class="row">
                <div class="col-md-6 mb-3">
                  <label class="form-label">Email Address (Username) *</label>
                  <input type="email" name="email" class="form-control" required placeholder="name@email.com">
                </div>
                <div class="col-md-6 mb-3">
                  <label class="form-label">Account Password *</label>
                  <input type="password" name="password" class="form-control" required minlength="6">
                </div>
              </div>

              <div class="form-check mt-3">
                <input class="form-check-input" type="checkbox" name="agree_terms" id="agreeTerms" required>
                <label class="form-check-label small" for="agreeTerms">I have read and agree to the <a href="/terms" target="_blank">Terms and Conditions</a> and consent to the processing of my personal information for barangay services. *</label>
              </div>
              <button type="submit" class="btn btn-accent-custom w-100 py-2 mt-3 fw-bold">Submit Registration Request</button>
              <div class="text-center mt-3">
                <a href="/login" class="text-decoration-none text-primary-blue">Back to Login</a>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    ${renderSystemFooter()}
  `);
});

app.post('/api/register', safeUpload(photoUpload.any()), async (req, res) => {
  try {
    const first_name = (req.body.first_name || '').trim();
    const middle_name = (req.body.middle_name || '').trim();
    const last_name = (req.body.last_name || '').trim();
    const suffix = (req.body.suffix || '').trim();
    const date_of_birth = req.body.date_of_birth;
    const gender = req.body.gender || 'Male';
    const civil_status = req.body.civil_status || 'Single';
    const purok_id = req.body.purok_id || null;
    const address = (req.body.address || '').trim();
    const contact_number = (req.body.contact_number || '').trim();
    const occupation = (req.body.occupation || '').trim();
    const email = (req.body.email || '').trim().toLowerCase();
    const password = req.body.password;
    const household_name = (req.body.household_name || '').replace(/\s+/g, ' ').trim();

    if (!req.body.agree_terms) {
      return res.status(400).send('<script>alert("You must agree to the Terms and Conditions to register."); window.history.back();</script>');
    }

    if (!household_name) {
      return res.status(400).send('<script>alert("Please enter your household name."); window.history.back();</script>');
    }

    if (!first_name || !last_name || !date_of_birth || !address || !email || !password) {
      return res.status(400).send('<script>alert("Please fill in all required fields."); window.history.back();</script>');
    }

    // ----- Family members entered by the head (members[0][first_name], ...) -----
    // Each member's photo arrives as the file field "member_photo_<photo_key>"
    const filesByField = {};
    (req.files || []).forEach(f => { filesByField[f.fieldname] = f; });
    const memberPhoto = (m) => {
      const key = String((m && m.photo_key) || '');
      const f = /^\d{1,3}$/.test(key) ? filesByField['member_photo_' + key] : null;
      return f ? `data:${f.mimetype};base64,${f.buffer.toString('base64')}` : null;
    };
    const rawMembers = req.body.members
      ? Object.values(req.body.members).filter(m => m && typeof m === 'object')
      : [];
    const members = rawMembers.slice(0, 15).map(m => ({
      relationship: String((m && m.relationship) || '').trim(),
      first_name: String((m && m.first_name) || '').trim(),
      middle_name: String((m && m.middle_name) || '').trim(),
      last_name: String((m && m.last_name) || '').trim(),
      suffix: String((m && m.suffix) || '').trim(),
      date_of_birth: String((m && m.date_of_birth) || '').trim(),
      gender: (m && m.gender === 'Female') ? 'Female' : 'Male',
      civil_status: ['Single', 'Married', 'Widowed', 'Separated'].includes(m && m.civil_status) ? m.civil_status : 'Single',
      contact_number: String((m && m.contact_number) || '').trim(),
      cat_college: !!(m && m.cat_college),
      cat_senior: !!(m && m.cat_senior),
      cat_pwd: !!(m && m.cat_pwd),
      create_account: !!(m && m.create_account),
      photo_url: memberPhoto(m)
    }));
    for (const m of members) {
      if (!m.first_name || !m.last_name || !m.date_of_birth) {
        return res.status(400).send('<script>alert("Please complete the name and date of birth of every family member, or remove the empty member."); window.history.back();</script>');
      }
    }

    const { data: existingUser } = await supabase.from('users').select('*').eq('email', email).maybeSingle();
    if (existingUser) {
      return res.status(400).send('<script>alert("Email is already registered."); window.location="/register";</script>');
    }

    // ----- Household: the head always registers a NEW household -----
    const likeName = household_name.replace(/[\\%_]/g, m => '\\' + m);
    const { data: foundHh } = await supabase.from('households').select('id').ilike('household_name', likeName).limit(1).maybeSingle();
    if (foundHh) {
      return res.status(400).send('<script>alert("A household with that name already exists. Please use a different household name (for example, add a first name or purok)."); window.history.back();</script>');
    }
    const household_number = `HH-${Date.now().toString().slice(-6)}`;
    const { data: newHh, error: hhErr } = await supabase.from('households').insert([{
      household_number, household_name, head_resident_name: `${first_name} ${last_name}`, purok_id, address
    }]).select().single();
    if (hhErr) throw hhErr;
    const household_id = newHh.id;
    const createdHouseholdId = newHh.id;

    const year = new Date().getFullYear();
    const countRes = await supabase.from('residents').select('id', { count: 'exact' });
    const baseCount = countRes.count || 0;
    const makeNumber = (n) => `BRGY-${year}-${String(baseCount + n).padStart(6, '0')}`;
    const resident_number = makeNumber(1);

    const ageOf = (d) => new Date().getFullYear() - new Date(d).getFullYear();

    const { data: resident, error: resErr } = await supabase.from('residents').insert([{
      resident_number,
      first_name,
      middle_name,
      last_name,
      suffix,
      date_of_birth,
      gender,
      civil_status,
      purok_id,
      address,
      contact_number,
      occupation,
      email,
      resident_status: 'Pending',
      is_college_student: !!req.body.cat_college,
      is_pwd: !!req.body.cat_pwd,
      is_household_head: true,
      relationship: 'Head',
      is_senior_citizen: ageOf(date_of_birth) >= 60 || !!req.body.cat_senior,
      household_id
    }]).select().single();

    if (resErr) {
      await supabase.from('households').delete().eq('id', createdHouseholdId);
      throw resErr;
    }

    // ----- Family members: each becomes a resident (Pending) with the same household, purok and address -----
    let memberNumbers = [];
    let insertedMembers = [];
    if (members.length) {
      const memberRows = members.map((m, idx) => {
        const num = makeNumber(idx + 2);
        memberNumbers.push(num);
        return {
          resident_number: num,
          first_name: m.first_name,
          middle_name: m.middle_name,
          last_name: m.last_name,
          suffix: m.suffix,
          date_of_birth: m.date_of_birth,
          gender: m.gender,
          civil_status: m.civil_status,
          purok_id,
          address,
          contact_number: m.contact_number || contact_number,
          resident_status: 'Pending',
          is_college_student: m.cat_college,
          is_pwd: m.cat_pwd,
          is_household_head: false,
          relationship: m.relationship || 'Other Relative',
          photo_url: m.photo_url,
          is_senior_citizen: ageOf(m.date_of_birth) >= 60 || m.cat_senior,
          household_id
        };
      });
      const { data: memIns, error: memErr } = await supabase.from('residents').insert(memberRows)
        .select('id, resident_number, first_name, last_name');
      if (memErr) {
        await supabase.from('residents').delete().eq('id', resident.id);
        await supabase.from('households').delete().eq('id', createdHouseholdId);
        throw memErr;
      }
      insertedMembers = memIns || [];
    }

    const salt = await bcrypt.genSalt(10);
    const password_hash = await bcrypt.hash(password, salt);

    const { data: headUser, error: headUserErr } = await supabase.from('users').insert([{
      username: email,
      email,
      password_hash,
      full_name: `${first_name} ${last_name}`,
      role: 'Resident',
      status: 'Pending',
      resident_id: resident.id
    }]).select('id').single();
    if (headUserErr) {
      await supabase.from('residents').delete().eq('household_id', household_id);
      await supabase.from('households').delete().eq('id', createdHouseholdId);
      throw headUserErr;
    }

    // ----- Login accounts for the members the head ticked: email + temporary password are generated -----
    const familyCreds = [];
    const credFailures = [];
    for (let idx = 0; idx < members.length; idx++) {
      if (!members[idx].create_account) continue;
      const row = insertedMembers.find(x => x.resident_number === memberNumbers[idx]);
      const label = `${members[idx].first_name} ${members[idx].last_name}`;
      if (!row) { credFailures.push(label); continue; }
      try {
        const creds = await createFamilyAccount({ resident: row, headUserId: headUser.id, status: 'Pending' });
        familyCreds.push({ name: label, relationship: members[idx].relationship, email: creds.email, password: creds.password });
      } catch (e) {
        console.error('Family account error:', e);
        credFailures.push(label);
      }
    }

    const credsHtml = familyCreds.length ? `
      <div class="text-start mt-4">
        <h5 class="fw-bold text-primary-blue"><i class="bi bi-key-fill me-2"></i>Family Member Login Accounts</h5>
        <div class="alert alert-warning small py-2">
          <strong>Save these now.</strong> The passwords are temporary and are shown only on this page. Each member will be asked to change the password at first login. The accounts work once the Barangay approves your registration. After you can log in, open <em>My Family</em> to create more accounts or get a new temporary password.
        </div>
        <div class="table-responsive">
          <table class="table table-sm table-bordered align-middle bg-white">
            <thead class="table-light"><tr><th>Member</th><th>Login Email</th><th>Temporary Password</th></tr></thead>
            <tbody>${familyCreds.map(c => `<tr><td>${escHtml(c.name)}<div class="small text-muted">${escHtml(c.relationship)}</div></td><td class="font-monospace user-select-all">${escHtml(c.email)}</td><td class="font-monospace fw-bold user-select-all">${escHtml(c.password)}</td></tr>`).join('')}</tbody>
          </table>
        </div>
        <button type="button" class="btn btn-outline-secondary btn-sm no-print" onclick="window.print()"><i class="bi bi-printer me-1"></i> Print this list</button>
      </div>` : '';
    const credFailHtml = credFailures.length
      ? `<div class="alert alert-danger small text-start mt-3">A login account could not be created for: ${credFailures.map(n => escHtml(n)).join(', ')}. You can create it from <em>My Family</em> after your registration is approved.</div>`
      : '';

    res.set('Cache-Control', 'no-store');
    res.send(`
      ${renderSystemHead('Registration Pending')}
      <div class="container text-center pt-5">
        <div class="card p-5 shadow-lg d-inline-block bg-light-green" style="max-width: 760px; width: 100%;">
          <i class="bi bi-clock-history text-warning display-1"></i>
          <h3 class="mt-3 text-primary-blue fw-bold">Registration Received</h3>
          <p class="text-muted">Your resident registration reference is <strong>${resident_number}</strong>.${members.length ? ` <strong>${members.length}</strong> family member${members.length > 1 ? 's were' : ' was'} also registered under your household.` : ''} Please wait for official approval from Barangay Admin before logging in. Once approved, you can view and show the Barangay ID of every member of your household from <em>My Digital ID</em>.</p>
          ${credsHtml}
          ${credFailHtml}
          <a href="/login" class="btn btn-primary-custom mt-3">Return to Login</a>
        </div>
      </div>
      ${renderSystemFooter()}
    `);
  } catch (err) {
    console.error('Registration Error:', err);
    res.status(500).send('Error registering account: ' + err.message);
  }
});

app.get('/logout', async (req, res) => {
  // Stop sending this phone the previous user's notifications
  const pushToken = req.cookies && req.cookies.push_token;
  if (pushToken) {
    try { await supabase.from('device_tokens').delete().eq('token', pushToken); } catch (e) {}
    res.clearCookie('push_token');
  }
  res.clearCookie('token');
  res.redirect('/login');
});

// ==========================================
// ROUTE 3: ADMIN DASHBOARD
// ==========================================
app.get('/admin/dashboard', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary', 'Barangay Staff']), async (req, res) => {
  const settings = await getSettings();

  const [
    { count: totalResidents },
    { count: activeResidents },
    { count: pendingRegistrations },
    { count: totalHouseholds },
    { count: totalPuroks },
    { count: seniorCitizens },
    { count: pwds },
    { count: soloParents },
    { count: pendingCerts },
    { count: pendingBlotters }
  ] = await Promise.all([
    supabase.from('residents').select('*', { count: 'exact', head: true }),
    supabase.from('residents').select('*', { count: 'exact', head: true }).eq('resident_status', 'Active'),
    supabase.from('residents').select('*', { count: 'exact', head: true }).eq('resident_status', 'Pending'),
    supabase.from('households').select('*', { count: 'exact', head: true }),
    supabase.from('puroks').select('*', { count: 'exact', head: true }),
    supabase.from('residents').select('*', { count: 'exact', head: true }).eq('is_senior_citizen', true),
    supabase.from('residents').select('*', { count: 'exact', head: true }).eq('is_pwd', true),
    supabase.from('residents').select('*', { count: 'exact', head: true }).eq('is_solo_parent', true),
    supabase.from('certificate_requests').select('*', { count: 'exact', head: true }).eq('status', 'SUBMITTED'),
    supabase.from('complaints').select('*', { count: 'exact', head: true }).eq('status', 'SUBMITTED')
  ]);

  const { data: recentLogs } = await supabase.from('user_activity_logs').select('*, users(full_name)').order('created_at', { ascending: false }).limit(5);

  const html = `
    <div class="row g-3 mb-4">
      <div class="col-md-3">
        <div class="card card-custom p-3 stat-card">
          <span class="text-muted small fw-bold">TOTAL RESIDENTS</span>
          <h2 class="fw-bold text-primary-blue m-0">${totalResidents || 0}</h2>
          <small class="text-accent-green fw-bold">${activeResidents || 0} Active / ${pendingRegistrations || 0} Pending</small>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card card-custom p-3 stat-card green">
          <span class="text-muted small fw-bold">HOUSEHOLDS & PUROKS</span>
          <h2 class="fw-bold text-accent-green m-0">${totalHouseholds || 0}</h2>
          <small class="text-muted">${totalPuroks || 0} Total Registered Puroks</small>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card card-custom p-3 stat-card">
          <span class="text-muted small fw-bold">PENDING REQUESTS</span>
          <h2 class="fw-bold text-primary-blue m-0">${pendingCerts || 0}</h2>
          <small class="text-danger fw-bold">Certificate Applications</small>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card card-custom p-3 stat-card green">
          <span class="text-muted small fw-bold">SPECIAL SECTORS</span>
          <h2 class="fw-bold text-accent-green m-0">${(seniorCitizens || 0) + (pwds || 0) + (soloParents || 0)}</h2>
          <small class="text-muted">Seniors: ${seniorCitizens || 0} | PWD: ${pwds || 0} | Solo: ${soloParents || 0}</small>
        </div>
      </div>
    </div>

    <div class="row g-3">
      <div class="col-md-8">
        <div class="card card-custom p-4">
          <h5 class="fw-bold text-primary-blue mb-3"><i class="bi bi-clock-history me-2"></i>Recent System Activities</h5>
          <div class="table-responsive">
            <table class="table table-hover align-middle">
              <thead class="table-light">
                <tr>
                  <th>User</th>
                  <th>Action</th>
                  <th>Details</th>
                  <th>Timestamp</th>
                </tr>
              </thead>
              <tbody>
                ${(recentLogs || []).map(log => `
                  <tr>
                    <td class="fw-semibold">${log.users ? log.users.full_name : 'System'}</td>
                    <td><span class="badge bg-primary-blue text-white">${log.action}</span></td>
                    <td class="small">${log.details || '-'}</td>
                    <td class="small text-muted">${new Date(log.created_at).toLocaleString()}</td>
                  </tr>
                `).join('') || '<tr><td colspan="4" class="text-center text-muted">No activity logs recorded.</td></tr>'}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="card card-custom p-4">
          <h5 class="fw-bold text-primary-blue mb-3"><i class="bi bi-lightning-charge me-2"></i>Quick Actions</h5>
          <div class="d-grid gap-2">
            <a href="/admin/residents?filter=Pending" class="btn btn-outline-primary text-start"><i class="bi bi-person-check me-2"></i> Review Pending Registrations (${pendingRegistrations || 0})</a>
            <a href="/admin/certificates" class="btn btn-outline-success text-start"><i class="bi bi-file-earmark-check me-2"></i> Process Certificates (${pendingCerts || 0})</a>
            <a href="/scanner" class="btn btn-primary-custom text-center py-2 fw-bold text-white"><i class="bi bi-qr-code-scan me-2"></i> Open QR Verification Scanner</a>
            <a href="/scan" class="btn btn-outline-primary text-start"><i class="bi bi-upc-scan me-2"></i> Scan-Only Page (full screen)</a>
          </div>
        </div>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'dashboard', html, settings));
});

// ==========================================
// ROUTE 4: RESIDENT MANAGEMENT (ADMIN)
// ==========================================
app.get('/admin/residents', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary', 'Barangay Staff']), async (req, res) => {
  const settings = await getSettings();
  const search = req.query.search || '';
  const filter = req.query.filter || 'Active';

  let query = supabase.from('residents').select('*, puroks(name)').order('created_at', { ascending: false });

  if (filter !== 'All') {
    query = query.eq('resident_status', filter);
  }

  if (search) {
    query = query.or(`first_name.ilike.%${search}%,last_name.ilike.%${search}%,resident_number.ilike.%${search}%`);
  }

  const { data: residents } = await query;
  const { data: puroks } = await supabase.from('puroks').select('*');

  const html = `
    <div class="card card-custom p-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold text-primary-blue m-0"><i class="bi bi-people me-2"></i>Resident Directory Management</h4>
        <button class="btn btn-accent-custom fw-bold text-white" data-bs-toggle="modal" data-bs-target="#addResidentModal"><i class="bi bi-person-plus me-1"></i> Add New Resident</button>
      </div>

      <form class="row g-2 mb-4" method="GET" action="/admin/residents">
        <div class="col-md-5">
          <input type="text" name="search" class="form-control" placeholder="Search by Name or Resident ID..." value="${search}">
        </div>
        <div class="col-md-3">
          <select name="filter" class="form-select" onchange="this.form.submit()">
            <option value="Active" ${filter === 'Active' ? 'selected' : ''}>Active Residents</option>
            <option value="Pending" ${filter === 'Pending' ? 'selected' : ''}>Pending Registrations</option>
            <option value="Archived" ${filter === 'Archived' ? 'selected' : ''}>Archived Residents</option>
            <option value="All" ${filter === 'All' ? 'selected' : ''}>All Records</option>
          </select>
        </div>
        <div class="col-md-2">
          <button type="submit" class="btn btn-primary-custom w-100 text-white">Search</button>
        </div>
      </form>

      <div class="table-responsive">
        <table class="table table-hover align-middle">
          <thead class="table-light">
            <tr>
              <th>Resident ID</th>
              <th>Full Name</th>
              <th>Purok</th>
              <th>Gender / Age</th>
              <th>Status</th>
              <th class="text-end">Actions</th>
            </tr>
          </thead>
          <tbody>
            ${(residents || []).map(r => {
              const age = new Date().getFullYear() - new Date(r.date_of_birth).getFullYear();
              return `
                <tr>
                  <td class="fw-bold text-primary-blue">${r.resident_number}</td>
                  <td>
                    ${r.photo_url ? `<img src="${r.photo_url}" class="rounded-circle me-2" style="width:30px; height:30px; object-fit:cover;">` : ''}
                    ${r.first_name} ${r.middle_name || ''} ${r.last_name} ${r.suffix || ''}
                  </td>
                  <td>${r.puroks ? r.puroks.name : '-'}</td>
                  <td>${r.gender} (${age} yrs)</td>
                  <td>
                    <span class="badge ${r.resident_status === 'Active' ? 'bg-success' : (r.resident_status === 'Pending' ? 'bg-warning text-dark' : 'bg-secondary')}">
                      ${r.resident_status}
                    </span>
                  </td>
                  <td class="text-end">
                    ${r.resident_status === 'Pending' ? `
                      <a href="/api/admin/resident/approve/${r.id}" class="btn btn-sm btn-success"><i class="bi bi-check-lg"></i> Approve</a>
                      <a href="/api/admin/resident/reject/${r.id}" class="btn btn-sm btn-danger"><i class="bi bi-x-lg"></i> Reject</a>
                    ` : `
                      <a href="/admin/resident/view/${r.id}" class="btn btn-sm btn-outline-primary"><i class="bi bi-eye"></i> View</a>
                      ${['Super Admin', 'Barangay Admin', 'Barangay Secretary'].includes(req.user.role) ? `<a href="/admin/resident/edit/${r.id}" class="btn btn-sm btn-outline-success"><i class="bi bi-pencil"></i> Edit</a>` : ''}
                      ${r.resident_status === 'Active' ? `<a href="/api/admin/resident/archive/${r.id}" class="btn btn-sm btn-outline-secondary" onclick="return confirm('Archive this resident record?')"><i class="bi bi-archive"></i></a>` : ''}
                    `}
                  </td>
                </tr>
              `;
            }).join('') || '<tr><td colspan="6" class="text-center py-4 text-muted">No resident records found. Register or approve your first resident to get started.</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>

    <!-- Modal: Add Resident -->
    <div class="modal fade" id="addResidentModal" tabindex="-1">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <form action="/api/admin/resident/add" method="POST">
            <div class="modal-header bg-primary-blue text-white">
              <h5 class="modal-title fw-bold">Add Resident Record</h5>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <div class="row g-3">
                <div class="col-md-4"><label class="form-label">First Name *</label><input type="text" name="first_name" class="form-control" required></div>
                <div class="col-md-4"><label class="form-label">Middle Name</label><input type="text" name="middle_name" class="form-control"></div>
                <div class="col-md-4"><label class="form-label">Last Name *</label><input type="text" name="last_name" class="form-control" required></div>
                <div class="col-md-4"><label class="form-label">Date of Birth *</label><input type="date" name="date_of_birth" class="form-control" required></div>
                <div class="col-md-4">
                  <label class="form-label">Gender *</label>
                  <select name="gender" class="form-select"><option value="Male">Male</option><option value="Female">Female</option></select>
                </div>
                <div class="col-md-4">
                  <label class="form-label">Civil Status *</label>
                  <select name="civil_status" class="form-select"><option value="Single">Single</option><option value="Married">Married</option><option value="Widowed">Widowed</option></select>
                </div>
                <div class="col-md-6">
                  <label class="form-label">Purok *</label>
                  <select name="purok_id" class="form-select">${(puroks || []).map(p => `<option value="${p.id}">${p.name}</option>`).join('')}</select>
                </div>
                <div class="col-md-6"><label class="form-label">Address *</label><input type="text" name="address" class="form-control" required></div>
                <div class="col-md-6"><label class="form-label">Contact Number</label><input type="text" name="contact_number" class="form-control"></div>
                <div class="col-md-6"><label class="form-label">Email</label><input type="email" name="email" class="form-control"></div>
                <div class="col-12">
                  <label class="form-label fw-bold">Resident Category</label>
                  ${renderCategoryCheckboxes({}, 'addCat')}
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary-custom text-white">Save Resident Record</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'residents', html, settings));
});

// Admin API Actions: Resident
app.post('/api/admin/resident/add', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary']), async (req, res) => {
  const { first_name, middle_name, last_name, date_of_birth, gender, civil_status, purok_id, address, contact_number, email } = req.body;
  try {
    const year = new Date().getFullYear();
    const countRes = await supabase.from('residents').select('id', { count: 'exact' });
    const sequenceNum = String((countRes.count || 0) + 1).padStart(6, '0');
    const resident_number = `BRGY-${year}-${sequenceNum}`;

    const dob = new Date(date_of_birth);
    const age = new Date().getFullYear() - dob.getFullYear();

    await supabase.from('residents').insert([{
      resident_number, first_name, middle_name, last_name, date_of_birth, gender,
      civil_status, purok_id, address, contact_number, email, resident_status: 'Active',
      ...categoryFlags(req.body),
      is_senior_citizen: age >= 60 || !!req.body.cat_senior
    }]);

    await logActivity(req.user.id, 'Add Resident', `Added new resident record: ${first_name} ${last_name}`);
    res.redirect('/admin/residents');
  } catch (err) {
    res.status(500).send('Error adding resident: ' + err.message);
  }
});

// Approving a family head also approves the family members registered with them (they have no login of their own).
app.get('/api/admin/resident/approve/:id', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary']), async (req, res) => {
  try {
    const { data: target } = await supabase.from('residents').select('id, household_id').eq('id', req.params.id).maybeSingle();
    await supabase.from('residents').update({ resident_status: 'Active' }).eq('id', req.params.id);
    await supabase.from('users').update({ status: 'Active' }).eq('resident_id', req.params.id);

    let familyCount = 0;
    if (target && target.household_id) {
      const { data: pendingMembers } = await supabase.from('residents').select('id')
        .eq('household_id', target.household_id).eq('resident_status', 'Pending').neq('id', target.id);
      const ids = (pendingMembers || []).map(m => m.id);
      if (ids.length) {
        // Only auto-approve members without their own login account (those are approved individually)
        // Members with their OWN registration login are approved individually; family accounts created by the head are not
        const { data: withLogin } = await supabase.from('users').select('resident_id, family_head_user_id').in('resident_id', ids);
        const hasLogin = new Set((withLogin || []).filter(u => !u.family_head_user_id).map(u => u.resident_id));
        const toApprove = ids.filter(id => !hasLogin.has(id));
        if (toApprove.length) {
          await supabase.from('residents').update({ resident_status: 'Active' }).in('id', toApprove);
          await supabase.from('users').update({ status: 'Active' }).in('resident_id', toApprove)
            .not('family_head_user_id', 'is', null).eq('status', 'Pending');
          familyCount = toApprove.length;
        }
      }
    }
    await logActivity(req.user.id, 'Approve Resident', `Approved resident ID: ${req.params.id}${familyCount ? ` and ${familyCount} household member(s)` : ''}`);
    res.redirect('/admin/residents?filter=Pending');
  } catch (err) {
    res.status(500).send('Error approving resident.');
  }
});

app.get('/api/admin/resident/reject/:id', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary']), async (req, res) => {
  try {
    const { data: target } = await supabase.from('residents').select('id, household_id').eq('id', req.params.id).maybeSingle();
    await supabase.from('residents').update({ resident_status: 'Archived' }).eq('id', req.params.id);
    await supabase.from('users').update({ status: 'Disabled' }).eq('resident_id', req.params.id);

    // Rejecting a head also archives the pending members that were registered with them
    if (target && target.household_id) {
      const { data: pendingMembers } = await supabase.from('residents').select('id')
        .eq('household_id', target.household_id).eq('resident_status', 'Pending').neq('id', target.id);
      const ids = (pendingMembers || []).map(m => m.id);
      if (ids.length) {
        const { data: withLogin } = await supabase.from('users').select('resident_id, family_head_user_id').in('resident_id', ids);
        const hasLogin = new Set((withLogin || []).filter(u => !u.family_head_user_id).map(u => u.resident_id));
        const toArchive = ids.filter(id => !hasLogin.has(id));
        if (toArchive.length) {
          await supabase.from('residents').update({ resident_status: 'Archived' }).in('id', toArchive);
          await supabase.from('users').update({ status: 'Disabled' }).in('resident_id', toArchive).not('family_head_user_id', 'is', null);
        }
      }
    }
    await logActivity(req.user.id, 'Reject Resident', `Rejected registration for resident ID: ${req.params.id}`);
    res.redirect('/admin/residents?filter=Pending');
  } catch (err) {
    res.status(500).send('Error rejecting resident.');
  }
});

app.get('/api/admin/resident/archive/:id', authenticateToken, requireRole(['Super Admin', 'Barangay Admin']), async (req, res) => {
  try {
    await supabase.from('residents').update({ resident_status: 'Archived' }).eq('id', req.params.id);
    await logActivity(req.user.id, 'Archive Resident', `Archived resident ID: ${req.params.id}`);
    res.redirect('/admin/residents');
  } catch (err) {
    res.status(500).send('Error archiving resident.');
  }
});

// View Resident Record Details
app.get('/admin/resident/view/:id', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary', 'Barangay Staff']), async (req, res) => {
  const settings = await getSettings();
  const { data: resident } = await supabase.from('residents').select('*, puroks(name), households(household_number)').eq('id', req.params.id).single();
  if (!resident) return res.status(404).send('Resident not found');

  const { data: certs } = await supabase.from('certificate_requests').select('*').eq('resident_id', resident.id);

  const html = `
    <div class="row g-4">
      <div class="col-md-4">
        <div class="card card-custom p-4 text-center">
          <img src="${resident.photo_url || 'https://via.placeholder.com/150'}" class="rounded-circle mx-auto mb-3" style="width: 140px; height: 140px; object-fit: cover; border: 3px solid #205493;">
          <h5 class="fw-bold m-0">${resident.first_name} ${resident.last_name}</h5>
          <span class="text-primary-blue fw-bold">${resident.resident_number}</span>
          <p class="text-muted small">${resident.puroks ? resident.puroks.name : 'No Purok'}</p>
          ${['Super Admin', 'Barangay Admin', 'Barangay Secretary'].includes(req.user.role) ? `<a href="/admin/resident/edit/${resident.id}" class="btn btn-sm btn-accent-custom text-white"><i class="bi bi-pencil-square me-1"></i> Edit Information</a>` : ''}

          <form action="/api/admin/resident/upload-photo/${resident.id}" method="POST" enctype="multipart/form-data" class="mt-3">
            <label class="form-label small fw-bold">Update Resident Photo</label>
            <input type="file" name="photo" class="form-control form-control-sm mb-2" accept="image/*" required>
            <button type="submit" class="btn btn-sm btn-primary-custom w-100 text-white">Upload & Save Photo</button>
          </form>
        </div>
      </div>

      <div class="col-md-8">
        <div class="card card-custom p-4">
          <h5 class="fw-bold text-primary-blue mb-3">Official Record Information</h5>
          <div class="row g-3">
            <div class="col-6"><strong>Date of Birth:</strong> ${resident.date_of_birth}</div>
            <div class="col-6"><strong>Gender:</strong> ${resident.gender}</div>
            <div class="col-6"><strong>Civil Status:</strong> ${resident.civil_status}</div>
            <div class="col-6"><strong>Occupation:</strong> ${resident.occupation || 'N/A'}</div>
            <div class="col-6"><strong>Contact:</strong> ${resident.contact_number}</div>
            <div class="col-6"><strong>Email:</strong> ${resident.email || 'N/A'}</div>
            <div class="col-12"><strong>Address:</strong> ${resident.address}</div>
            <div class="col-4"><strong>Solo Parent:</strong> ${resident.is_solo_parent ? 'Yes' : 'No'}</div>
            <div class="col-8"><strong>Household:</strong> ${resident.households ? escHtml(resident.households.household_name || resident.households.household_number) : 'Not linked'}</div>
          </div>

          <hr class="my-4">
          <h6 class="fw-bold text-accent-green mb-2">Resident Category</h6>
          <p class="small text-muted mb-2">Current: ${categoryTags(resident).length ? categoryTags(resident).map(t => `<span class="badge bg-info text-dark me-1">${t}</span>`).join('') : 'None'}</p>
          <form action="/api/admin/resident/${resident.id}/categories" method="POST">
            ${renderCategoryCheckboxes(resident, 'viewCat')}
            <button type="submit" class="btn btn-sm btn-primary-custom text-white mt-3"><i class="bi bi-check2 me-1"></i> Save Categories</button>
          </form>

          <hr class="my-4">
          <h6 class="fw-bold text-accent-green mb-2">Issued Certificates History</h6>
          <ul class="list-group list-group-flush mb-3">
            ${(certs || []).map(c => `<li class="list-group-item d-flex justify-content-between"><span>${c.certificate_type} (${c.request_number})</span> <span class="badge bg-primary-blue text-white">${c.status}</span></li>`).join('') || '<li class="list-group-item text-muted">No certificate history.</li>'}
          </ul>
        </div>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'residents', html, settings));
});

app.post('/api/admin/resident/:id/categories', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary']), async (req, res) => {
  try {
    await supabase.from('residents').update(categoryFlags(req.body)).eq('id', req.params.id);
    await logActivity(req.user.id, 'Update Resident Category', `Updated categories for resident ID: ${req.params.id}`);
  } catch (err) {
    console.error('Update categories error:', err);
  }
  res.redirect(`/admin/resident/view/${req.params.id}`);
});

app.post('/api/admin/resident/upload-photo/:id', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary', 'Barangay Staff']), upload.single('photo'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).send('No photo uploaded.');
    const base64Data = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;

    await supabase.from('residents').update({ photo_url: base64Data }).eq('id', req.params.id);
    await logActivity(req.user.id, 'Update Resident Photo', `Updated photo for resident ID ${req.params.id}`);
    res.redirect(`/admin/resident/view/${req.params.id}`);
  } catch (err) {
    res.status(500).send('Error uploading photo: ' + err.message);
  }
});

// ==========================================
// ROUTE 5: PUROK MANAGEMENT
// ==========================================
app.get('/admin/puroks', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary', 'Barangay Staff']), async (req, res) => {
  const settings = await getSettings();
  const { data: puroks } = await supabase.from('puroks').select('*');
  const { data: residents } = await supabase.from('residents').select('purok_id').eq('resident_status', 'Active');

  const purokCounts = {};
  (residents || []).forEach(r => {
    if (r.purok_id) purokCounts[r.purok_id] = (purokCounts[r.purok_id] || 0) + 1;
  });

  const html = `
    <div class="card card-custom p-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold text-primary-blue m-0"><i class="bi bi-geo-alt me-2"></i>Purok Directory & Demographics</h4>
        <button class="btn btn-accent-custom fw-bold text-white" data-bs-toggle="modal" data-bs-target="#addPurokModal"><i class="bi bi-plus-circle me-1"></i> Add New Purok</button>
      </div>

      <div class="row g-3 mt-2">
        ${(puroks || []).map(p => `
          <div class="col-md-4">
            <div class="card card-custom p-3 border-top border-4 border-primary">
              <h5 class="fw-bold text-primary-blue">${p.name}</h5>
              <p class="text-muted small mb-2">${p.description || 'Barangay Territorial Zone'}</p>
              <div class="d-flex justify-content-between align-items-center bg-light-green p-2 rounded">
                <span class="fw-bold">Active Residents:</span>
                <span class="badge bg-accent-green fs-6 text-white">${purokCounts[p.id] || 0}</span>
              </div>
            </div>
          </div>
        `).join('') || '<div class="col-12 text-center text-muted">No purok records available.</div>'}
      </div>
    </div>

    <!-- Modal Add Purok -->
    <div class="modal fade" id="addPurokModal" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <form action="/api/admin/purok/add" method="POST">
            <div class="modal-header bg-primary-blue text-white">
              <h5 class="modal-title fw-bold">Add Purok Zone</h5>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <div class="mb-3"><label class="form-label">Purok Name *</label><input type="text" name="name" class="form-control" required placeholder="e.g. Purok 4"></div>
              <div class="mb-3"><label class="form-label">Description</label><textarea name="description" class="form-control"></textarea></div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary-custom text-white">Save Purok</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'puroks', html, settings));
});

app.post('/api/admin/purok/add', authenticateToken, requireRole(['Super Admin', 'Barangay Admin']), async (req, res) => {
  const { name, description } = req.body;
  await supabase.from('puroks').insert([{ name, description }]);
  res.redirect('/admin/puroks');
});

// ==========================================
// ROUTE 6: HOUSEHOLD MANAGEMENT
// ==========================================
app.get('/admin/households', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary', 'Barangay Staff']), async (req, res) => {
  const settings = await getSettings();
  const { data: households } = await supabase.from('households').select('*, puroks(name)');
  const { data: puroks } = await supabase.from('puroks').select('*');
  const { data: members } = await supabase.from('residents')
    .select('id, first_name, last_name, resident_number, resident_status, household_id')
    .not('household_id', 'is', null).order('last_name', { ascending: true });

  const byHousehold = {};
  (members || []).forEach(m => { (byHousehold[m.household_id] = byHousehold[m.household_id] || []).push(m); });

  const html = `
    <div class="card card-custom p-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold text-primary-blue m-0"><i class="bi bi-house-door me-2"></i>Household Records</h4>
        <button class="btn btn-accent-custom fw-bold text-white" data-bs-toggle="modal" data-bs-target="#addHouseholdModal"><i class="bi bi-plus-lg me-1"></i> Register Household</button>
      </div>
      <p class="small text-muted">Click a household to see its members. Aid is released once per household.</p>

      <div class="table-responsive">
        <table class="table table-hover align-middle">
          <thead class="table-light">
            <tr>
              <th>Household No</th>
              <th>Household Name</th>
              <th>Head of Household</th>
              <th>Purok Zone</th>
              <th>Address</th>
              <th>Members</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            ${(households || []).map(h => {
              const mem = byHousehold[h.id] || [];
              return `
              <tr style="cursor:pointer" data-bs-toggle="collapse" data-bs-target="#hhMembers${h.id}" aria-expanded="false">
                <td class="fw-bold text-primary-blue">${escHtml(h.household_number)}</td>
                <td class="fw-semibold">${escHtml(h.household_name || '-')}</td>
                <td>${escHtml(h.head_resident_name || '-')}</td>
                <td>${h.puroks ? escHtml(h.puroks.name) : '-'}</td>
                <td>${escHtml(h.address || '-')}</td>
                <td><span class="badge bg-primary"><i class="bi bi-people me-1"></i>${mem.length}</span></td>
                <td><span class="badge bg-success">${escHtml(h.status || 'Active')}</span></td>
              </tr>
              <tr class="collapse" id="hhMembers${h.id}">
                <td colspan="7" class="bg-light">
                  ${mem.length ? `
                    <div class="small fw-bold text-accent-green mb-1">Members of ${escHtml(h.household_name || h.household_number)}</div>
                    <ul class="list-unstyled mb-0 small">
                      ${mem.map(m => `<li class="py-1"><i class="bi bi-person me-1"></i>${escHtml(m.last_name)}, ${escHtml(m.first_name)} <span class="text-muted">(${escHtml(m.resident_number)})</span> <span class="badge ${m.resident_status === 'Active' ? 'bg-success' : 'bg-warning text-dark'}">${escHtml(m.resident_status)}</span></li>`).join('')}
                    </ul>` : '<span class="small text-muted">No residents are linked to this household yet.</span>'}
                </td>
              </tr>`;
            }).join('') || '<tr><td colspan="7" class="text-center py-4 text-muted">No household records registered.</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>

    <!-- Modal Add Household -->
    <div class="modal fade" id="addHouseholdModal" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <form action="/api/admin/household/add" method="POST">
            <div class="modal-header bg-primary-blue text-white">
              <h5 class="modal-title fw-bold">Register New Household</h5>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <div class="mb-3"><label class="form-label">Household Name *</label><input type="text" name="household_name" class="form-control" required maxlength="100" placeholder="e.g. Dela Cruz Family"></div>
              <div class="mb-3"><label class="form-label">Head of Household Name *</label><input type="text" name="head_resident_name" class="form-control" required></div>
              <div class="mb-3">
                <label class="form-label">Purok Zone *</label>
                <select name="purok_id" class="form-select">${(puroks || []).map(p => `<option value="${p.id}">${escHtml(p.name)}</option>`).join('')}</select>
              </div>
              <div class="mb-3"><label class="form-label">Address *</label><input type="text" name="address" class="form-control" required></div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary-custom text-white">Save Household</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'households', html, settings));
});

app.post('/api/admin/household/add', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary']), async (req, res) => {
  const { head_resident_name, purok_id, address } = req.body;
  const household_name = (req.body.household_name || '').replace(/\s+/g, ' ').trim();
  if (!household_name) return res.status(400).send('<script>alert("Household name is required."); window.history.back();</script>');
  const likeName = household_name.replace(/[\\%_]/g, m => '\\' + m);
  const { data: dup } = await supabase.from('households').select('id').ilike('household_name', likeName).limit(1).maybeSingle();
  if (dup) return res.status(400).send('<script>alert("A household with that name already exists."); window.history.back();</script>');
  const household_number = `HH-${Date.now().toString().slice(-6)}`;
  await supabase.from('households').insert([{ household_number, household_name, head_resident_name, purok_id, address }]);
  res.redirect('/admin/households');
});

// ==========================================
// ROUTE 7: CERTIFICATE APPROVAL & ISSUANCE
// ==========================================
app.get('/admin/certificates', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary', 'Barangay Staff']), async (req, res) => {
  const settings = await getSettings();
  const { data: certs } = await supabase.from('certificate_requests').select('*, residents(first_name, last_name, resident_number)').order('created_at', { ascending: false });

  const html = `
    <div class="card card-custom p-4">
      <h4 class="fw-bold text-primary-blue mb-3"><i class="bi bi-file-earmark-text me-2"></i>Certificate Request & Issuance Operations</h4>
      <div class="table-responsive">
        <table class="table table-hover align-middle">
          <thead class="table-light">
            <tr>
              <th>Request No</th>
              <th>Resident</th>
              <th>Certificate Type</th>
              <th>Purpose</th>
              <th>Status</th>
              <th class="text-end">Actions</th>
            </tr>
          </thead>
          <tbody>
            ${(certs || []).map(c => `
              <tr>
                <td class="fw-bold text-primary-blue">${c.request_number}</td>
                <td>${c.residents ? `${c.residents.first_name} ${c.residents.last_name}` : 'Unknown'}</td>
                <td><span class="badge bg-light text-dark border">${c.certificate_type}</span></td>
                <td>${c.purpose}</td>
                <td>
                  <span class="badge ${c.status === 'RELEASED' ? 'bg-success' : (c.status === 'READY_FOR_RELEASE' ? 'bg-accent-green text-white' : 'bg-warning text-dark')}">
                    ${c.status}
                  </span>
                </td>
                <td class="text-end">
                  ${c.status === 'SUBMITTED' ? `
                    <a href="/api/admin/certificate/update/${c.id}?status=READY_FOR_RELEASE" class="btn btn-sm btn-accent-custom text-white"><i class="bi bi-check-circle"></i> Mark Ready</a>
                  ` : ''}
                  ${c.status === 'READY_FOR_RELEASE' ? `
                    <a href="/api/admin/certificate/update/${c.id}?status=RELEASED" class="btn btn-sm btn-primary-custom text-white"><i class="bi bi-box-arrow-up-right"></i> Release Document</a>
                  ` : ''}
                </td>
              </tr>
            `).join('') || '<tr><td colspan="6" class="text-center py-4 text-muted">No certificate requests submitted.</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'certificates', html, settings));
});

app.get('/api/admin/certificate/update/:id', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary', 'Barangay Staff']), async (req, res) => {
  const { status } = req.query;
  await supabase.from('certificate_requests').update({ status, updated_at: new Date() }).eq('id', req.params.id);
  if (status === 'READY_FOR_RELEASE') {
    const { data: cert } = await supabase.from('certificate_requests').select('resident_id, certificate_type').eq('id', req.params.id).maybeSingle();
    if (cert) notifyResidents([cert.resident_id], { title: 'Certificate ready for pickup', body: `Your ${cert.certificate_type} is ready. Bring your Barangay ID to claim it.`, url: '/resident/certificates' });
  }
  res.redirect('/admin/certificates');
});

// ==========================================
// ROUTE 8: BARANGAY ID GENERATOR (National ID format mapped to "Barangay ID", captain name below signature, functional QR, no outer lines)
// ==========================================
app.get('/admin/id-generator', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary', 'Barangay Staff']), async (req, res) => {
  const settings = await getSettings();
  const { data: residents } = await supabase.from('residents').select('*, puroks(name)').eq('resident_status', 'Active');

  const residentCards = await Promise.all((residents || []).slice(0, 8).map(async (r) => {
    const qrDataUrl = await QRCode.toDataURL(r.qr_token || r.id, { margin: 0, width: 250 });
    return { ...r, qrDataUrl };
  }));

  const html = `
    <div class="card card-custom p-4 no-print">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold text-primary-blue m-0"><i class="bi bi-card-heading me-2"></i>Barangay Resident ID Generator</h4>
        <button class="btn btn-accent-custom fw-bold text-white" onclick="window.print()"><i class="bi bi-printer me-1"></i> Print Selected Grid (8 IDs)</button>
      </div>
      <p class="text-muted">Generate standard Barangay ID physical cards modeled after the National ID format with functional QR codes, high-visibility badges, and captain's signature.</p>
    </div>

    <div class="mt-4">
      <div class="print-sheet-8">
        ${residentCards.map(r => `
          <div class="id-card-frame">
            <div class="id-card-header">
              ${settings.barangay_logo ? `<img src="${settings.barangay_logo}" class="id-header-logo">` : '<i class="bi bi-building fs-5"></i>'}
              <div class="text-center flex-grow-1 px-1" style="line-height:1.1;">
                <strong style="font-size: 7.5pt; display: block;" class="text-uppercase">${settings.barangay_name || 'BARANGAY CENTRAL'}</strong>
                <span style="font-size: 5.5pt; letter-spacing:0.5px;">BARANGAY ID</span>
              </div>
              <span class="badge bg-white text-dark px-1" style="font-size: 5pt; font-weight: 800;">VERIFIED</span>
            </div>

            <div class="id-card-body">
              <img src="${r.photo_url || 'https://via.placeholder.com/150'}" class="id-photo">
              <div class="id-details">
                <div class="text-primary-blue fw-bold" style="font-size: 8pt;">${r.resident_number}</div>
                <div class="fw-bold text-uppercase text-dark mt-1" style="font-size: 8.5pt;">${r.first_name} ${r.last_name}</div>
                <div class="text-muted mt-1">DOB: <strong>${r.date_of_birth}</strong></div>
                <div class="text-muted">Sex: <strong>${r.gender}</strong> | Civil: <strong>${r.civil_status || 'Single'}</strong></div>
                <div class="text-muted">Purok: <strong>${r.puroks ? r.puroks.name : '-'}</strong></div>
              </div>
              <img src="${r.qrDataUrl}" class="id-qr">
            </div>

            <div class="id-card-footer">
              <div style="font-size: 4.5pt; max-width:1.8in;" class="text-muted lh-1">
                If found, please return to Barangay Hall. Property of Barangay Administration.
              </div>
              <div class="text-center" style="min-width: 0.9in;">
                ${settings.captain_signature ? `<img src="${settings.captain_signature}" style="height:16px; object-fit:contain; display:block; margin:auto;"><br>` : ''}
                <span style="font-size: 5pt; border-top: 1px solid #333; display: block; font-weight: 600; margin-top: -2px;">${settings.barangay_captain || 'Barangay Captain'}</span>
              </div>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'id-gen', html, settings));
});

// ==========================================
// ROUTE 9: QR SCANNER (page + JSON API defined further below, after STAFF_ROLES)
// ==========================================
app.post('/api/scanner/verify', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary', 'Barangay Staff']), async (req, res) => {
  const { qr_token } = req.body;
  const settings = await getSettings();

  const { data: resident } = await supabase.from('residents').select('*, puroks(name)').eq('qr_token', qr_token).single();

  let resultHtml = '';
  if (resident) {
    const { data: cert } = await supabase.from('certificate_requests').select('*').eq('resident_id', resident.id).eq('status', 'READY_FOR_RELEASE').single();
    const { data: aidRows } = await supabase.from('aid_beneficiaries').select('*, aid_programs(title, aid_type, status, location)').eq('resident_id', resident.id).eq('status', 'Pending');
    const pendingAid = (aidRows || []).filter(a => a.aid_programs && a.aid_programs.status === 'Open');

    resultHtml = `
      <div class="card card-custom p-4 border-success">
        <div class="text-center mb-3">
          <span class="badge bg-success px-3 py-2 fs-6 text-white"><i class="bi bi-patch-check-fill me-1"></i> OFFICIAL RESIDENT VERIFIED</span>
        </div>
        <div class="row align-items-center">
          <div class="col-md-4 text-center">
            <img src="${resident.photo_url || 'https://via.placeholder.com/100'}" class="rounded-circle mb-2" style="width:90px; height:90px; object-fit:cover;">
            <h6 class="fw-bold m-0">${resident.first_name} ${resident.last_name}</h6>
            <small class="text-primary-blue fw-bold">${resident.resident_number}</small>
          </div>
          <div class="col-md-8">
            <p class="m-0"><strong>Address:</strong> ${resident.address}</p>
            <p class="m-0"><strong>Purok:</strong> ${resident.puroks ? resident.puroks.name : '-'}</p>
            <p class="m-0"><strong>Status:</strong> <span class="badge bg-success">${resident.resident_status}</span></p>

            ${cert ? `
              <div class="alert alert-warning mt-3 p-2">
                <small class="fw-bold d-block">CLAIMABLE DOCUMENT READY:</small>
                <span>${cert.certificate_type} (${cert.request_number})</span>
                <a href="/api/admin/certificate/update/${cert.id}?status=RELEASED" class="btn btn-sm btn-primary-custom d-block mt-2 text-white">Mark Document Released</a>
              </div>
            ` : '<p class="text-muted small mt-2">No pending certificates ready for release.</p>'}
          </div>
        </div>

        <hr>
        <h6 class="fw-bold text-accent-green"><i class="bi bi-box2-heart me-1"></i> Aid Available to Claim</h6>
        ${pendingAid.length ? pendingAid.map(a => `
          <form action="/api/scanner/claim" method="POST" class="alert alert-success d-flex justify-content-between align-items-center p-2 mb-2">
            <div>
              <strong>${escHtml(a.aid_programs.title)}</strong>
              <small class="d-block text-muted">${escHtml(a.aid_programs.aid_type)}</small>
            </div>
            <input type="hidden" name="beneficiary_id" value="${a.id}">
            <input type="hidden" name="qr_token" value="${escHtml(qr_token)}">
            <button type="submit" class="btn btn-sm btn-accent-custom text-white fw-bold" onclick="return confirm('Release this aid to the resident?')"><i class="bi bi-check2-circle me-1"></i> Release Aid</button>
          </form>
        `).join('') : '<p class="text-muted small">No unclaimed aid for this resident.</p>'}
        <div class="text-center mt-3">
          <a href="/scanner" class="btn btn-sm btn-outline-secondary">Scan Another Code</a>
        </div>
      </div>
    `;
  } else {
    resultHtml = `
      <div class="alert alert-danger text-center">
        <i class="bi bi-x-circle fs-3 d-block mb-2"></i>
        <strong>Verification Failed!</strong><br>
        No corresponding official resident or token record found in database.
      </div>
      <div class="text-center"><a href="/scanner" class="btn btn-sm btn-secondary">Try Again</a></div>
    `;
  }

  res.send(renderAppLayout(req, 'qr-scanner', resultHtml, settings));
});

// ==========================================
// ROUTE 10: SENIOR CITIZENS, PWD & SOLO PARENTS
// ==========================================
app.get('/admin/seniors', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary', 'Barangay Staff']), async (req, res) => {
  const settings = await getSettings();
  const { data: seniors } = await supabase.from('residents').select('*, puroks(name)').eq('is_senior_citizen', true).eq('resident_status', 'Active');

  const html = `
    <div class="card card-custom p-4">
      <h4 class="fw-bold text-primary-blue mb-3"><i class="bi bi-person-heart me-2"></i>Senior Citizens Sector Directory</h4>
      <div class="table-responsive">
        <table class="table table-hover align-middle">
          <thead class="table-light">
            <tr>
              <th>Resident ID</th>
              <th>Full Name</th>
              <th>Age</th>
              <th>Purok Zone</th>
              <th>Contact Number</th>
            </tr>
          </thead>
          <tbody>
            ${(seniors || []).map(s => {
              const age = new Date().getFullYear() - new Date(s.date_of_birth).getFullYear();
              return `
                <tr>
                  <td class="fw-bold text-primary-blue">${s.resident_number}</td>
                  <td class="fw-semibold">${s.first_name} ${s.last_name}</td>
                  <td><span class="badge bg-accent-green text-white">${age} yrs old</span></td>
                  <td>${s.puroks ? s.puroks.name : '-'}</td>
                  <td>${s.contact_number || '-'}</td>
                </tr>
              `;
            }).join('') || '<tr><td colspan="5" class="text-center py-4 text-muted">No senior citizens registered.</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'seniors', html, settings));
});

app.get('/admin/pwds', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary', 'Barangay Staff']), async (req, res) => {
  const settings = await getSettings();
  const { data: pwds } = await supabase.from('residents').select('*, puroks(name)').eq('is_pwd', true).eq('resident_status', 'Active');

  const html = `
    <div class="card card-custom p-4">
      <h4 class="fw-bold text-primary-blue mb-3"><i class="bi bi-universal-access me-2"></i>Persons with Disability (PWD) Directory</h4>
      <div class="table-responsive">
        <table class="table table-hover align-middle">
          <thead class="table-light">
            <tr>
              <th>Resident ID</th>
              <th>Full Name</th>
              <th>Disability Details</th>
              <th>Purok Zone</th>
            </tr>
          </thead>
          <tbody>
            ${(pwds || []).map(p => `
              <tr>
                <td class="fw-bold text-primary-blue">${p.resident_number}</td>
                <td class="fw-semibold">${p.first_name} ${p.last_name}</td>
                <td>${p.disability_details || 'Unspecified'}</td>
                <td>${p.puroks ? p.puroks.name : '-'}</td>
              </tr>
            `).join('') || '<tr><td colspan="4" class="text-center py-4 text-muted">No PWD records registered.</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'pwds', html, settings));
});

app.get('/admin/solo-parents', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary', 'Barangay Staff']), async (req, res) => {
  const settings = await getSettings();
  const { data: parents } = await supabase.from('residents').select('*, puroks(name)').eq('is_solo_parent', true).eq('resident_status', 'Active');

  const html = `
    <div class="card card-custom p-4">
      <h4 class="fw-bold text-primary-blue mb-3"><i class="bi bi-person-badge me-2"></i>Solo Parents Directory</h4>
      <div class="table-responsive">
        <table class="table table-hover align-middle">
          <thead class="table-light">
            <tr>
              <th>Resident ID</th>
              <th>Full Name</th>
              <th>Details</th>
              <th>Purok Zone</th>
            </tr>
          </thead>
          <tbody>
            ${(parents || []).map(p => `
              <tr>
                <td class="fw-bold text-primary-blue">${p.resident_number}</td>
                <td class="fw-semibold">${p.first_name} ${p.last_name}</td>
                <td>${p.solo_parent_details || 'N/A'}</td>
                <td>${p.puroks ? p.puroks.name : '-'}</td>
              </tr>
            `).join('') || '<tr><td colspan="4" class="text-center py-4 text-muted">No solo parent records registered.</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'soloparents', html, settings));
});

// ==========================================
// ROUTE 11: BLOTTER & COMPLAINTS (With Print Capability)
// ==========================================
app.get('/admin/blotters', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary', 'Barangay Staff']), async (req, res) => {
  const settings = await getSettings();
  const { data: blotters } = await supabase.from('complaints').select('*').order('created_at', { ascending: false });

  const html = `
    <div class="card card-custom p-4">
      <div class="d-flex justify-content-between align-items-center mb-3 no-print">
        <h4 class="fw-bold text-primary-blue m-0"><i class="bi bi-shield-exclamation me-2"></i>Barangay Blotter & Incident Records</h4>
        <div>
          <button class="btn btn-outline-primary me-2" onclick="window.print()"><i class="bi bi-printer me-1"></i> Print Complaint Files</button>
          <button class="btn btn-accent-custom fw-bold text-white" data-bs-toggle="modal" data-bs-target="#addBlotterModal"><i class="bi bi-plus-lg me-1"></i> File Incident Blotter</button>
        </div>
      </div>

      <div class="table-responsive">
        <table class="table table-hover align-middle">
          <thead class="table-light">
            <tr>
              <th>Case No</th>
              <th>Complainant</th>
              <th>Respondent</th>
              <th>Incident Date</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            ${(blotters || []).map(b => `
              <tr>
                <td class="fw-bold text-primary-blue">${b.case_number}</td>
                <td>${b.complainant_name}</td>
                <td>${b.respondent_name}</td>
                <td>${b.incident_date}</td>
                <td><span class="badge bg-warning text-dark">${b.status}</span></td>
              </tr>
            `).join('') || '<tr><td colspan="5" class="text-center py-4 text-muted">No blotter cases recorded.</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>

    <!-- Modal Add Blotter -->
    <div class="modal fade" id="addBlotterModal" tabindex="-1">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <form action="/api/admin/blotter/add" method="POST">
            <div class="modal-header bg-primary-blue text-white">
              <h5 class="modal-title fw-bold">File Incident / Blotter Report</h5>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <div class="row g-3">
                <div class="col-md-6"><label class="form-label">Complainant Name *</label><input type="text" name="complainant_name" class="form-control" required></div>
                <div class="col-md-6"><label class="form-label">Respondent Name *</label><input type="text" name="respondent_name" class="form-control" required></div>
                <div class="col-md-6"><label class="form-label">Incident Date *</label><input type="date" name="incident_date" class="form-control" required></div>
                <div class="col-md-6"><label class="form-label">Location *</label><input type="text" name="location" class="form-control" required></div>
                <div class="col-12"><label class="form-label">Description of Incident *</label><textarea name="description" class="form-control" rows="3" required></textarea></div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary-custom text-white">File Incident Report</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'blotters', html, settings));
});

app.post('/api/admin/blotter/add', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary']), async (req, res) => {
  const { complainant_name, respondent_name, incident_date, location, description } = req.body;
  const case_number = `BLOT-${Date.now().toString().slice(-6)}`;
  await supabase.from('complaints').insert([{ case_number, complainant_name, respondent_name, incident_date, location, description, status: 'INVESTIGATION' }]);
  res.redirect('/admin/blotters');
});

// ==========================================
// ROUTE 12: ASSISTANCE REQUESTS
// ==========================================
app.get('/admin/assistance', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary', 'Barangay Staff']), async (req, res) => {
  const settings = await getSettings();
  const { data: requests } = await supabase.from('assistance_requests').select('*, residents(first_name, last_name)').order('created_at', { ascending: false });

  const html = `
    <div class="card card-custom p-4">
      <h4 class="fw-bold text-primary-blue mb-3"><i class="bi bi-hand-thumbs-up me-2"></i>Barangay Assistance Applications</h4>
      <div class="table-responsive">
        <table class="table table-hover align-middle">
          <thead class="table-light">
            <tr>
              <th>Request No</th>
              <th>Resident</th>
              <th>Type</th>
              <th>Details</th>
              <th>Status</th>
              <th class="text-end">Action</th>
            </tr>
          </thead>
          <tbody>
            ${(requests || []).map(r => `
              <tr>
                <td class="fw-bold text-primary-blue">${r.request_number}</td>
                <td>${r.residents ? `${r.residents.first_name} ${r.residents.last_name}` : 'Unknown'}</td>
                <td><span class="badge bg-info text-dark">${r.assistance_type}</span></td>
                <td>${r.details}</td>
                <td><span class="badge bg-warning text-dark">${r.status}</span></td>
                <td class="text-end">
                  ${r.status === 'PENDING' ? `
                    <a href="/api/admin/assistance/approve/${r.id}" class="btn btn-sm btn-success">Approve</a>
                  ` : ''}
                </td>
              </tr>
            `).join('') || '<tr><td colspan="6" class="text-center py-4 text-muted">No assistance requests submitted.</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'assistance', html, settings));
});

app.get('/api/admin/assistance/approve/:id', authenticateToken, requireRole(['Super Admin', 'Barangay Admin']), async (req, res) => {
  await supabase.from('assistance_requests').update({ status: 'APPROVED' }).eq('id', req.params.id);
  const { data: asst } = await supabase.from('assistance_requests').select('resident_id, assistance_type').eq('id', req.params.id).maybeSingle();
  if (asst) notifyResidents([asst.resident_id], { title: 'Assistance request approved', body: `Your ${asst.assistance_type} request was approved.`, url: '/resident/dashboard' });
  res.redirect('/admin/assistance');
});

// ==========================================
// ROUTE 13: APPOINTMENTS
// ==========================================
app.get('/admin/appointments', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary', 'Barangay Staff']), async (req, res) => {
  const settings = await getSettings();
  const { data: appointments } = await supabase.from('appointments').select('*, residents(first_name, last_name)').order('created_at', { ascending: false });

  const html = `
    <div class="card card-custom p-4">
      <h4 class="fw-bold text-primary-blue mb-3"><i class="bi bi-calendar-check me-2"></i>Resident Appointment Schedule</h4>
      <div class="table-responsive">
        <table class="table table-hover align-middle">
          <thead class="table-light">
            <tr>
              <th>Appt No</th>
              <th>Resident</th>
              <th>Service</th>
              <th>Date & Time</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            ${(appointments || []).map(a => `
              <tr>
                <td class="fw-bold text-primary-blue">${a.appointment_number}</td>
                <td>${a.residents ? `${a.residents.first_name} ${a.residents.last_name}` : 'Unknown'}</td>
                <td>${a.service_requested}</td>
                <td>${a.appointment_date} at ${a.appointment_time}</td>
                <td><span class="badge bg-primary text-white">${a.status}</span></td>
              </tr>
            `).join('') || '<tr><td colspan="5" class="text-center py-4 text-muted">No appointments scheduled.</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'appointments', html, settings));
});

// ==========================================
// ROUTE 14: ANNOUNCEMENTS & EVENTS
// ==========================================
app.get('/admin/announcements', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary']), async (req, res) => {
  const settings = await getSettings();
  const { data: announcements } = await supabase.from('announcements').select('*').order('created_at', { ascending: false });

  const html = `
    <div class="card card-custom p-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold text-primary-blue m-0"><i class="bi bi-megaphone me-2"></i>Public Announcements</h4>
        <button class="btn btn-accent-custom fw-bold text-white" data-bs-toggle="modal" data-bs-target="#addAnnouncementModal"><i class="bi bi-plus-lg me-1"></i> Create Announcement</button>
      </div>

      <div class="row g-3">
        ${(announcements || []).map(a => `
          <div class="col-md-6">
            <div class="card card-custom p-3 border-start border-4 ${a.priority === 'Emergency' ? 'border-danger' : 'border-primary'}">
              <span class="badge ${a.priority === 'Emergency' ? 'bg-danger' : 'bg-primary'} w-auto ms-auto text-white">${a.priority}</span>
              <h5 class="fw-bold text-primary-blue mt-2">${a.title}</h5>
              <p class="text-muted small">${a.content}</p>
              <small class="text-secondary">${new Date(a.created_at).toLocaleDateString()}</small>
            </div>
          </div>
        `).join('') || '<div class="col-12 text-center text-muted">No announcements published.</div>'}
      </div>
    </div>

    <!-- Modal Add Announcement -->
    <div class="modal fade" id="addAnnouncementModal" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <form action="/api/admin/announcement/add" method="POST">
            <div class="modal-header bg-primary-blue text-white">
              <h5 class="modal-title fw-bold">New Announcement</h5>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <div class="mb-3"><label class="form-label">Title *</label><input type="text" name="title" class="form-control" required></div>
              <div class="mb-3"><label class="form-label">Priority *</label><select name="priority" class="form-select"><option value="Normal">Normal</option><option value="Emergency">Emergency</option></select></div>
              <div class="mb-3"><label class="form-label">Content *</label><textarea name="content" class="form-control" rows="4" required></textarea></div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary-custom text-white">Publish Announcement</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'announcements', html, settings));
});

app.post('/api/admin/announcement/add', authenticateToken, requireRole(['Super Admin', 'Barangay Admin']), async (req, res) => {
  const { title, priority, content } = req.body;
  await supabase.from('announcements').insert([{ title, priority, content, created_by: req.user.id }]);
  sendPush('all', { title: (priority === 'Emergency' ? 'EMERGENCY: ' : 'Announcement: ') + title, body: content, url: '/resident/announcements' });
  res.redirect('/admin/announcements');
});

app.get('/admin/events', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary']), async (req, res) => {
  const settings = await getSettings();
  const { data: events } = await supabase.from('events').select('*').order('event_date', { ascending: true });

  const html = `
    <div class="card card-custom p-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold text-primary-blue m-0"><i class="bi bi-calendar-event me-2"></i>Community Events</h4>
        <button class="btn btn-accent-custom fw-bold text-white" data-bs-toggle="modal" data-bs-target="#addEventModal"><i class="bi bi-plus-lg me-1"></i> Add Event</button>
      </div>

      <div class="row g-3">
        ${(events || []).map(e => `
          <div class="col-md-4">
            <div class="card card-custom p-3 border-top border-4 border-success">
              <h5 class="fw-bold text-primary-blue">${e.event_name}</h5>
              <p class="text-muted small mb-1"><i class="bi bi-calendar3 me-1"></i> ${e.event_date} at ${e.event_time}</p>
              <p class="text-muted small mb-2"><i class="bi bi-geo-alt me-1"></i> ${e.location}</p>
              <p class="small">${e.description}</p>
            </div>
          </div>
        `).join('') || '<div class="col-12 text-center text-muted">No scheduled events.</div>'}
      </div>
    </div>

    <!-- Modal Add Event -->
    <div class="modal fade" id="addEventModal" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <form action="/api/admin/event/add" method="POST">
            <div class="modal-header bg-primary-blue text-white">
              <h5 class="modal-title fw-bold">Add Community Event</h5>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <div class="mb-3"><label class="form-label">Event Name *</label><input type="text" name="event_name" class="form-control" required></div>
              <div class="mb-3"><label class="form-label">Date *</label><input type="date" name="event_date" class="form-control" required></div>
              <div class="mb-3"><label class="form-label">Time *</label><input type="text" name="event_time" class="form-control" required placeholder="e.g. 9:00 AM"></div>
              <div class="mb-3"><label class="form-label">Location *</label><input type="text" name="location" class="form-control" required></div>
              <div class="mb-3"><label class="form-label">Description *</label><textarea name="description" class="form-control" rows="3" required></textarea></div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary-custom text-white">Save Event</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'events', html, settings));
});

app.post('/api/admin/event/add', authenticateToken, requireRole(['Super Admin', 'Barangay Admin']), async (req, res) => {
  const { event_name, event_date, event_time, location, description } = req.body;
  await supabase.from('events').insert([{ event_name, event_date, event_time, location, description }]);
  res.redirect('/admin/events');
});

// ==========================================
// ROUTE 15: BARANGAY OFFICIALS MANAGEMENT
// ==========================================
app.get('/admin/officials', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary']), async (req, res) => {
  const settings = await getSettings();
  const { data: officials } = await supabase.from('barangay_officials').select('*');

  const html = `
    <div class="card card-custom p-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold text-primary-blue m-0"><i class="bi bi-person-lines-fill me-2"></i>Barangay Council & Officials</h4>
        <button class="btn btn-accent-custom fw-bold text-white" data-bs-toggle="modal" data-bs-target="#addOfficialModal"><i class="bi bi-person-plus me-1"></i> Add Official</button>
      </div>

      <div class="row g-3">
        ${(officials || []).map(o => `
          <div class="col-md-3">
            <div class="card card-custom p-3 text-center h-100">
              <img src="${o.photo_url || 'https://via.placeholder.com/100'}" class="rounded-circle mx-auto mb-2" style="width:80px; height:80px; object-fit:cover; border: none;">
              <h6 class="fw-bold text-primary-blue m-0">${o.name}</h6>
              <span class="badge bg-accent-green mb-2 text-white">${o.position}</span>${o.signature_url ? `<img src="${o.signature_url}" class="d-block mx-auto mt-1" style="height:25px; object-fit:contain;">` : ''}
              
              <form action="/api/admin/official/upload-photo/${o.id}" method="POST" enctype="multipart/form-data" class="mt-2">
                <input type="file" name="photo" class="form-control form-control-sm mb-1" accept="image/*" required>
                <button type="submit" class="btn btn-sm btn-outline-primary w-100">Upload Photo</button>
              </form>

              <a href="/api/admin/official/delete/${o.id}" class="btn btn-sm btn-outline-danger w-100 mt-2" onclick="return confirm('Are you sure you want to delete this official?')"><i class="bi bi-trash me-1"></i> Delete Official</a>
            </div>
          </div>
        `).join('') || '<div class="col-12 text-center text-muted">No officials configured.</div>'}
      </div>
    </div>

    <!-- Modal Add Official -->
    <div class="modal fade" id="addOfficialModal" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <form action="/api/admin/official/add" method="POST" enctype="multipart/form-data">
            <div class="modal-header bg-primary-blue text-white">
              <h5 class="modal-title fw-bold">Add Barangay Official</h5>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <div class="mb-3"><label class="form-label">Full Name *</label><input type="text" name="name" class="form-control" required></div>
              <div class="mb-3">
                <label class="form-label">Position *</label>
                <select name="position" class="form-select" required>
                  <option value="Barangay Captain">Barangay Captain</option>
                  <option value="Barangay Kagawad">Barangay Kagawad</option>
                  <option value="Barangay Secretary">Barangay Secretary</option>
                  <option value="Barangay Treasurer">Barangay Treasurer</option>
                  <option value="SK Chairman">SK Chairman</option>
                </select>
              </div>
              <div class="mb-3">
                <label class="form-label">Official Picture</label>
                <input type="file" name="photo" class="form-control" accept="image/*">
              </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary-custom text-white">Save Official</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'officials', html, settings));
});

app.post('/api/admin/official/add', authenticateToken, requireRole(['Super Admin', 'Barangay Admin']), upload.single('photo'), async (req, res) => {
  const { name, position } = req.body;
  let photo_url = null;
  if (req.file) {
    photo_url = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;
  }
  await supabase.from('barangay_officials').insert([{ name, position, photo_url }]);
  res.redirect('/admin/officials');
});

app.post('/api/admin/official/upload-photo/:id', authenticateToken, requireRole(['Super Admin', 'Barangay Admin']), upload.single('photo'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).send('No file uploaded.');
    const base64Data = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;
    await supabase.from('barangay_officials').update({ photo_url: base64Data }).eq('id', req.params.id);
    res.redirect('/admin/officials');
  } catch (err) {
    res.status(500).send('Error uploading official picture: ' + err.message);
  }
});

app.get('/api/admin/official/delete/:id', authenticateToken, requireRole(['Super Admin', 'Barangay Admin']), async (req, res) => {
  try {
    await supabase.from('barangay_officials').delete().eq('id', req.params.id);
    res.redirect('/admin/officials');
  } catch (err) {
    res.status(500).send('Error deleting official: ' + err.message);
  }
});

// ==========================================
// ROUTE 16: USER ACCOUNTS & PERMISSIONS (Updated Admin Account Name)
// ==========================================
app.get('/admin/users', authenticateToken, requireRole(['Super Admin', 'Barangay Admin']), async (req, res) => {
  const settings = await getSettings();
  const { data: users } = await supabase.from('users').select('*');

  const html = `
    <div class="card card-custom p-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold text-primary-blue m-0"><i class="bi bi-person-gear me-2"></i>System Staff & Administrative Accounts</h4>
        <button class="btn btn-accent-custom fw-bold text-white" data-bs-toggle="modal" data-bs-target="#addUserModal"><i class="bi bi-person-plus me-1"></i> Create Staff Account</button>
      </div>

      <div class="table-responsive">
        <table class="table table-hover align-middle">
          <thead class="table-light">
            <tr>
              <th>Full Name</th>
              <th>Username</th>
              <th>Email</th>
              <th>Role</th>
              <th>Status</th>
              <th class="text-end">Actions</th>
            </tr>
          </thead>
          <tbody>
            ${(users || []).map(u => `
              <tr>
                <td class="fw-semibold">${u.full_name}</td>
                <td>${u.username}</td>
                <td>${u.email}</td>
                <td><span class="badge bg-primary-blue text-white">${u.role}</span></td>
                <td><span class="badge ${u.status === 'Active' ? 'bg-success' : 'bg-secondary'}">${u.status}</span></td>
                <td class="text-end">
                  ${(u.role === 'Super Admin' && req.user.role !== 'Super Admin') ? '' : `<button type="button" class="btn btn-sm btn-outline-primary me-1" data-bs-toggle="modal" data-bs-target="#editUserModal" data-id="${u.id}" data-name="${escHtml(u.full_name)}" data-username="${escHtml(u.username)}" data-email="${escHtml(u.email)}" data-role="${escHtml(u.role)}"><i class="bi bi-pencil"></i> Edit</button>`}
                  ${u.status === 'Active' ? `
                    <a href="/api/admin/user/toggle/${u.id}?status=Disabled" class="btn btn-sm btn-outline-danger">Disable</a>
                  ` : `
                    <a href="/api/admin/user/toggle/${u.id}?status=Active" class="btn btn-sm btn-outline-success">Enable</a>
                  `}
                </td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>

    <!-- Modal Edit User -->
    <div class="modal fade" id="editUserModal" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <form id="editUserForm" method="POST">
            <div class="modal-header bg-primary-blue text-white">
              <h5 class="modal-title fw-bold">Edit Account</h5>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <div class="mb-3"><label class="form-label">Full Name *</label><input type="text" name="full_name" id="euName" class="form-control" required></div>
              <div class="mb-3"><label class="form-label">Username *</label><input type="text" name="username" id="euUsername" class="form-control" required></div>
              <div class="mb-3"><label class="form-label">Email *</label><input type="email" name="email" id="euEmail" class="form-control" required></div>
              <div class="mb-3" id="euRoleWrap">
                <label class="form-label">Role</label>
                <select name="role" id="euRole" class="form-select">
                  <option value="Barangay Admin">Barangay Admin</option>
                  <option value="Barangay Secretary">Barangay Secretary</option>
                  <option value="Barangay Staff">Barangay Staff</option>
                </select>
              </div>
              <div class="mb-1">
                <label class="form-label">New Password <small class="text-muted">(leave blank to keep the current one)</small></label>
                <input type="password" name="new_password" class="form-control" minlength="6" autocomplete="new-password">
              </div>
              <small class="text-muted" id="euNote"></small>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
              <button type="submit" class="btn btn-primary-custom text-white">Save Changes</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    <script>
      document.addEventListener('DOMContentLoaded', function () {
        var modal = document.getElementById('editUserModal');
        modal.addEventListener('show.bs.modal', function (e) {
          var d = e.relatedTarget.dataset;
          var fixed = (d.role === 'Resident');
          document.getElementById('editUserForm').action = '/api/admin/user/' + d.id + '/update';
          document.getElementById('euName').value = d.name;
          document.getElementById('euUsername').value = d.username;
          document.getElementById('euEmail').value = d.email;
          document.getElementById('euName').readOnly = fixed;
          document.getElementById('euUsername').readOnly = fixed;
          document.getElementById('euRole').value = d.role;
          document.getElementById('euRoleWrap').style.display = (fixed || d.role === 'Super Admin') ? 'none' : '';
          document.getElementById('euNote').textContent = fixed ? 'Resident name is edited from the Resident record. You can change the email and reset the password here.' : '';
        });
      });
    </script>

    <!-- Modal Add User -->
    <div class="modal fade" id="addUserModal" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <form action="/api/admin/user/add" method="POST">
            <div class="modal-header bg-primary-blue text-white">
              <h5 class="modal-title fw-bold">Create System Account</h5>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <div class="mb-3"><label class="form-label">Full Name *</label><input type="text" name="full_name" class="form-control" required></div>
              <div class="mb-3"><label class="form-label">Username *</label><input type="text" name="username" class="form-control" required></div>
              <div class="mb-3"><label class="form-label">Email *</label><input type="email" name="email" class="form-control" required></div>
              <div class="mb-3"><label class="form-label">Password *</label><input type="password" name="password" class="form-control" required minlength="6"></div>
              <div class="mb-3">
                <label class="form-label">Role *</label>
                <select name="role" class="form-select" required>
                  <option value="Barangay Admin">Barangay Admin</option>
                  <option value="Barangay Secretary">Barangay Secretary</option>
                  <option value="Barangay Staff">Barangay Staff</option>
                </select>
              </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary-custom text-white">Create Account</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'users', html, settings));
});

app.post('/api/admin/user/add', authenticateToken, requireRole(['Super Admin', 'Barangay Admin']), async (req, res) => {
  const { full_name, username, email, password, role } = req.body;
  const salt = await bcrypt.genSalt(10);
  const password_hash = await bcrypt.hash(password, salt);
  await supabase.from('users').insert([{ full_name, username, email, password_hash, role, status: 'Active' }]);
  res.redirect('/admin/users');
});

app.get('/api/admin/user/toggle/:id', authenticateToken, requireRole(['Super Admin', 'Barangay Admin']), async (req, res) => {
  const { status } = req.query;
  await supabase.from('users').update({ status }).eq('id', req.params.id);
  res.redirect('/admin/users');
});

// ==========================================
// ROUTE 17: REPORTS & DEMOGRAPHICS
// ==========================================
app.get('/admin/reports', authenticateToken, requireRole(['Super Admin', 'Barangay Admin', 'Barangay Secretary', 'Barangay Staff']), async (req, res) => {
  const settings = await getSettings();

  const [
    { count: totalRes },
    { count: maleCount },
    { count: femaleCount },
    { count: seniorCount }
  ] = await Promise.all([
    supabase.from('residents').select('*', { count: 'exact', head: true }).eq('resident_status', 'Active'),
    supabase.from('residents').select('*', { count: 'exact', head: true }).eq('resident_status', 'Active').eq('gender', 'Male'),
    supabase.from('residents').select('*', { count: 'exact', head: true }).eq('resident_status', 'Active').eq('gender', 'Female'),
    supabase.from('residents').select('*', { count: 'exact', head: true }).eq('resident_status', 'Active').eq('is_senior_citizen', true)
  ]);

  const html = `
    <div class="card card-custom p-4">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold text-primary-blue m-0"><i class="bi bi-bar-chart-line me-2"></i>Barangay Demographic & Statistical Reports</h4>
        <button class="btn btn-outline-primary no-print" onclick="window.print()"><i class="bi bi-printer me-1"></i> Print Demographic Summary</button>
      </div>

      <div class="row g-3">
        <div class="col-md-3">
          <div class="p-3 bg-light-blue rounded text-center border">
            <h6 class="text-muted fw-bold">TOTAL POPULATION</h6>
            <h2 class="text-primary-blue fw-bold">${totalRes || 0}</h2>
          </div>
        </div>
        <div class="col-md-3">
          <div class="p-3 bg-light-green rounded text-center border">
            <h6 class="text-muted fw-bold">MALE RESIDENTS</h6>
            <h2 class="text-accent-green fw-bold">${maleCount || 0}</h2>
          </div>
        </div>
        <div class="col-md-3">
          <div class="p-3 bg-light-blue rounded text-center border">
            <h6 class="text-muted fw-bold">FEMALE RESIDENTS</h6>
            <h2 class="text-primary-blue fw-bold">${femaleCount || 0}</h2>
          </div>
        </div>
        <div class="col-md-3">
          <div class="p-3 bg-light-green rounded text-center border">
            <h6 class="text-muted fw-bold">SENIOR CITIZENS</h6>
            <h2 class="text-accent-green fw-bold">${seniorCount || 0}</h2>
          </div>
        </div>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'reports', html, settings));
});

// ==========================================
// ROUTE 18: ACTIVITY LOGS
// ==========================================
app.get('/admin/activity-logs', authenticateToken, requireRole(['Super Admin', 'Barangay Admin']), async (req, res) => {
  const settings = await getSettings();
  const { data: logs } = await supabase.from('user_activity_logs').select('*, users(full_name)').order('created_at', { ascending: false }).limit(50);

  const html = `
    <div class="card card-custom p-4">
      <h4 class="fw-bold text-primary-blue mb-3"><i class="bi bi-clock-history me-2"></i>System User Activity & Audit Logs</h4>
      <div class="table-responsive">
        <table class="table table-hover align-middle">
          <thead class="table-light">
            <tr>
              <th>Timestamp</th>
              <th>User</th>
              <th>Action</th>
              <th>Details</th>
            </tr>
          </thead>
          <tbody>
            ${(logs || []).map(l => `
              <tr>
                <td class="small text-muted">${new Date(l.created_at).toLocaleString()}</td>
                <td class="fw-semibold">${l.users ? l.users.full_name : 'System'}</td>
                <td><span class="badge bg-primary-blue text-white">${l.action}</span></td>
                <td class="small">${l.details || '-'}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'activity-logs', html, settings));
});

// ==========================================
// ROUTE 19: SYSTEM SETTINGS (With Editable Emergency Number)
// ==========================================
app.get('/admin/settings', authenticateToken, requireRole(['Super Admin', 'Barangay Admin']), async (req, res) => {
  const settings = await getSettings();

  const html = `
    <div class="card card-custom p-4" style="max-width: 800px; margin: auto;">
      <h4 class="fw-bold text-primary-blue mb-3"><i class="bi bi-sliders me-2"></i>Barangay System Configuration</h4>

      <form action="/api/admin/settings/update" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
          <label class="form-label">Barangay Name</label>
          <input type="text" name="barangay_name" class="form-control" value="${settings.barangay_name || ''}" required>
        </div>
        <div class="row">
          <div class="col-md-6 mb-3">
            <label class="form-label">Municipality / City</label>
            <input type="text" name="municipality" class="form-control" value="${settings.municipality || ''}" required>
          </div>
          <div class="col-md-6 mb-3">
            <label class="form-label">Province</label>
            <input type="text" name="province" class="form-control" value="${settings.province || ''}" required>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6 mb-3">
            <label class="form-label">Barangay Captain Name</label>
            <input type="text" name="barangay_captain" class="form-control" value="${settings.barangay_captain || ''}">
          </div>
          <div class="col-md-6 mb-3">
            <label class="form-label">Emergency Hotline Number</label>
            <input type="text" name="contact_number" class="form-control" value="${settings.contact_number || ''}" placeholder="e.g. 09123456789 / 911">
          </div>
        </div>

        <h6 class="fw-bold text-accent-green mt-4 border-bottom pb-2">Branding Assets Upload</h6>
        <div class="mb-3">
          <label class="form-label">Barangay Logo</label>
          ${settings.barangay_logo ? `<img src="${settings.barangay_logo}" class="d-block mb-2 rounded-circle" style="width:70px; height:70px; object-fit:cover;">` : ''}
          <input type="file" name="logo" class="form-control" accept="image/*">
        </div>
        <div class="mb-3">
          <label class="form-label">Barangay Captain Digital Signature</label>
          ${settings.captain_signature ? `<img src="${settings.captain_signature}" class="d-block mb-2" style="height:35px; object-fit:contain;">` : ''}
          <input type="file" name="signature" class="form-control" accept="image/*">
        </div>

        <button type="submit" class="btn btn-primary-custom py-2 px-4 mt-3 fw-bold text-white">Save System Settings</button>
      </form>
    </div>
  `;

  res.send(renderAppLayout(req, 'settings', html, settings));
});

app.post('/api/admin/settings/update', authenticateToken, requireRole(['Super Admin', 'Barangay Admin']), upload.fields([{ name: 'logo' }, { name: 'signature' }]), async (req, res) => {
  const { barangay_name, municipality, province, barangay_captain, contact_number } = req.body;
  const settings = await getSettings();

  const updateData = { barangay_name, municipality, province, barangay_captain, contact_number, updated_at: new Date() };

  if (req.files && req.files['logo']) {
    const logoFile = req.files['logo'][0];
    updateData.barangay_logo = `data:${logoFile.mimetype};base64,${logoFile.buffer.toString('base64')}`;
  }

  if (req.files && req.files['signature']) {
    const sigFile = req.files['signature'][0];
    updateData.captain_signature = `data:${sigFile.mimetype};base64,${sigFile.buffer.toString('base64')}`;
  }

  await supabase.from('system_settings').update(updateData).eq('id', settings.id);
  res.redirect('/admin/settings');
});

// ==========================================
// ROUTE 20: RESIDENT PORTAL & PROFILE PICTURE SELF-UPDATE
// ==========================================
app.get('/resident/dashboard', authenticateToken, requireRole(['Resident']), async (req, res) => {
  const settings = await getSettings();
  const { data: resident } = await supabase.from('residents').select('*, puroks(name)').eq('id', req.user.resident_id).single();
  const { data: announcements } = await supabase.from('announcements').select('*').order('created_at', { ascending: false }).limit(3);
  const { data: myAid } = await supabase.from('aid_beneficiaries').select('id, aid_programs(status)').eq('resident_id', req.user.resident_id).eq('status', 'Pending');
  const aidReady = (myAid || []).filter(a => a.aid_programs && a.aid_programs.status === 'Open').length;

  const html = `
    ${req.user.must_change_password ? `<div class="alert alert-warning d-flex justify-content-between align-items-center"><span><i class="bi bi-shield-exclamation me-2"></i><strong>You are using a temporary password.</strong> Please change it to something only you know.</span><a href="/account" class="btn btn-sm btn-warning fw-bold">Change Password</a></div>` : ''}
    ${aidReady ? `<div class="alert alert-success d-flex justify-content-between align-items-center"><span><i class="bi bi-gift-fill me-2"></i><strong>You have ${aidReady} aid package${aidReady > 1 ? 's' : ''} ready to claim.</strong> Bring your Barangay ID for QR scanning.</span><a href="/resident/aid" class="btn btn-sm btn-accent-custom text-white fw-bold">View Details</a></div>` : ''}
    <div class="row g-3 mb-4">
      <div class="col-md-12">
        <div class="card card-custom p-4 bg-primary-blue text-white">
          <h3 class="fw-bold m-0">Welcome back, ${resident ? resident.first_name : 'Resident'}!</h3>
          <p class="mb-0 opacity-75">Resident ID: ${resident ? resident.resident_number : 'BRGY-000000'}</p>
        </div>
      </div>
    </div>

    <div class="row g-3">
      <div class="col-md-8">
        <div class="card card-custom p-4 mb-3">
          <h5 class="fw-bold text-primary-blue mb-3"><i class="bi bi-bell me-2"></i>Latest Barangay Announcements</h5>
          ${(announcements || []).map(a => `
            <div class="border-bottom pb-2 mb-2">
              <h6 class="fw-bold m-0 text-dark">${a.title}</h6>
              <p class="small text-muted mb-1">${a.content}</p>
            </div>
          `).join('') || '<p class="text-muted">No active announcements.</p>'}
        </div>
      </div>

      <div class="col-md-4">
        <div class="card card-custom p-4 text-center">
          <h5 class="fw-bold text-primary-blue mb-3">My Digital Resident ID</h5>
          <img src="${resident.photo_url || 'https://via.placeholder.com/100'}" class="rounded-circle mx-auto mb-2" style="width:80px; height:80px; object-fit:cover; border: none;">
          <h6 class="fw-bold m-0">${resident.first_name} ${resident.last_name}</h6>
          <span class="text-primary-blue small fw-bold">${resident.resident_number}</span>
          <div class="mt-3">
            <a href="/resident/digital-id" class="btn btn-sm btn-accent-custom w-100 fw-bold text-white"><i class="bi bi-qr-code me-1"></i> View Full Digital ID</a>
            <a href="/resident/profile" class="btn btn-sm btn-outline-primary w-100 fw-bold mt-2"><i class="bi bi-camera me-1"></i> Change Picture</a>
          </div>
        </div>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'res-dashboard', html, settings));
});

// Resident Profile & Picture Update
app.get('/resident/profile', authenticateToken, requireRole(['Resident']), async (req, res) => {
  const settings = await getSettings();
  const { data: resident } = await supabase.from('residents').select('*, puroks(name)').eq('id', req.user.resident_id).single();

  const html = `
    <div class="card card-custom p-4" style="max-width: 720px; margin: auto;">
      <div class="text-center mb-4">
        <div class="position-relative d-inline-block">
          <img src="${resident.photo_url || 'https://via.placeholder.com/150'}" class="rounded-circle mx-auto mb-2" style="width: 135px; height: 135px; object-fit: cover; border: none; box-shadow: 0 4px 10px rgba(0,0,0,0.15);">
          <button class="btn btn-sm btn-accent-custom rounded-circle position-absolute bottom-0 end-0 p-2 text-white" data-bs-toggle="modal" data-bs-target="#changePhotoModal" title="Change Photo">
            <i class="bi bi-camera-fill"></i>
          </button>
        </div>
        <h4 class="fw-bold text-primary-blue mt-2 m-0">${resident.first_name} ${resident.middle_name || ''} ${resident.last_name}</h4>
        <span class="badge bg-accent-green mt-1 text-white">${resident.resident_number}</span>
      </div>

      <div class="card p-3 mb-4 bg-light-green border">
        <div class="d-flex justify-content-between align-items-center">
          <div>
            <h6 class="fw-bold text-primary-blue m-0"><i class="bi bi-image me-1"></i> Update Your Profile Picture</h6>
            <small class="text-muted">Change or upload a new photograph for your digital resident ID and portal</small>
          </div>
          <button class="btn btn-sm btn-accent-custom fw-bold text-white" data-bs-toggle="modal" data-bs-target="#changePhotoModal"><i class="bi bi-upload me-1"></i> Upload Photo</button>
        </div>
      </div>

      <h5 class="fw-bold text-primary-blue mb-3"><i class="bi bi-person me-2"></i>My Resident Official Profile</h5>
      <div class="row g-3">
        <div class="col-6"><strong>Full Name:</strong> ${resident.first_name} ${resident.middle_name || ''} ${resident.last_name}</div>
        <div class="col-6"><strong>Resident ID:</strong> ${resident.resident_number}</div>
        <div class="col-6"><strong>Date of Birth:</strong> ${resident.date_of_birth}</div>
        <div class="col-6"><strong>Gender:</strong> ${resident.gender}</div>
        <div class="col-6"><strong>Civil Status:</strong> ${resident.civil_status}</div>
        <div class="col-6"><strong>Purok Zone:</strong> ${resident.puroks ? resident.puroks.name : '-'}</div>
        <div class="col-12"><strong>Address:</strong> ${resident.address}</div>
      </div>

      <hr class="my-4">
      <h6 class="fw-bold text-accent-green mb-2">Request Profile Correction</h6>
      <form action="/api/resident/request-profile-update" method="POST">
        <div class="mb-3">
          <label class="form-label">Describe Needed Changes / Corrections *</label>
          <textarea name="reason" class="form-control" rows="3" required placeholder="e.g. Correct address details or typo..."></textarea>
        </div>
        <button type="submit" class="btn btn-primary-custom text-white">Submit Correction Request</button>
      </form>
    </div>

    <!-- Modal: Upload Profile Photo -->
    <div class="modal fade" id="changePhotoModal" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <form action="/api/resident/upload-photo" method="POST" enctype="multipart/form-data">
            <div class="modal-header bg-primary-blue text-white">
              <h5 class="modal-title fw-bold"><i class="bi bi-camera me-2"></i>Change Profile Picture</h5>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <div class="mb-3">
                <label class="form-label fw-semibold">Select Photo File (PNG, JPG, JPEG) *</label>
                <input type="file" name="photo" class="form-control" accept="image/*" required>
                <small class="text-muted d-block mt-1">Please select a clear front-facing photograph of yourself.</small>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
              <button type="submit" class="btn btn-accent-custom fw-bold text-white"><i class="bi bi-upload me-1"></i> Upload New Picture</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'res-profile', html, settings));
});

// Resident Profile Photo Upload Handler
app.post('/api/resident/upload-photo', authenticateToken, requireRole(['Resident']), upload.single('photo'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).send('<script>alert("Please select an image file to upload."); window.history.back();</script>');
    const base64Data = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;

    await supabase.from('residents').update({ photo_url: base64Data }).eq('id', req.user.resident_id);
    await logActivity(req.user.id, 'Resident Photo Self-Update', `Resident updated their profile picture.`);
    res.redirect('/resident/profile');
  } catch (err) {
    console.error('Error uploading photo:', err);
    res.status(500).send('Error uploading photo: ' + err.message);
  }
});

app.post('/api/resident/request-profile-update', authenticateToken, requireRole(['Resident']), async (req, res) => {
  const { reason } = req.body;
  await supabase.from('profile_change_requests').insert([{ resident_id: req.user.resident_id, requested_changes: {}, reason }]);
  res.redirect('/resident/profile');
});

// Resident Digital ID Display (Barangay ID Format with Captain Name below Signature)
// Shows the logged-in resident's ID plus the IDs of everyone in the same household
// (family members registered by the head have no login, so the head shows their IDs from here).
app.get('/resident/digital-id', authenticateToken, requireRole(['Resident']), async (req, res) => {
  const settings = await getSettings();
  const { data: resident } = await supabase.from('residents').select('*, puroks(name)').eq('id', req.user.resident_id).single();

  let family = [];
  if (resident.household_id) {
    const { data: fam } = await supabase.from('residents').select('*, puroks(name)')
      .eq('household_id', resident.household_id).neq('id', resident.id).order('created_at', { ascending: true });
    family = fam || [];
  }

  const renderIdCard = async (r) => {
    const qrDataUrl = await QRCode.toDataURL(r.qr_token || r.id, { margin: 0, width: 300 });
    const isActive = r.resident_status === 'Active';
    return `
      <div class="id-card-frame shadow-lg text-start" style="width: 3.6in; height: 2.25in; border-width: 3px;">
        <div class="id-card-header">
          ${settings.barangay_logo ? `<img src="${settings.barangay_logo}" class="id-header-logo">` : '<i class="bi bi-building fs-5"></i>'}
          <div class="text-center flex-grow-1 px-1" style="line-height:1.1;">
            <strong style="font-size: 8pt; display: block;" class="text-uppercase">${escHtml(settings.barangay_name || 'BARANGAY CENTRAL')}</strong>
            <span style="font-size: 6pt; letter-spacing:0.5px;">BARANGAY ID</span>
          </div>
          <span class="badge bg-white text-dark px-1" style="font-size: 5.5pt; font-weight: 800;">${isActive ? 'VERIFIED' : 'PENDING'}</span>
        </div>

        <div class="id-card-body">
          <img src="${r.photo_url || 'https://via.placeholder.com/150'}" class="id-photo" style="width: 1.1in; height: 1.1in;">
          <div class="id-details">
            <div class="text-primary-blue fw-bold" style="font-size: 8.5pt;">${escHtml(r.resident_number)}</div>
            <div class="fw-bold text-uppercase text-dark mt-1" style="font-size: 9pt;">${escHtml(r.first_name)} ${escHtml(r.last_name)}</div>
            <div class="text-muted mt-1">DOB: <strong>${escHtml(r.date_of_birth)}</strong></div>
            <div class="text-muted">Sex: <strong>${escHtml(r.gender)}</strong> | Civil: <strong>${escHtml(r.civil_status || 'Single')}</strong></div>
            <div class="text-muted">Purok: <strong>${r.puroks ? escHtml(r.puroks.name) : '-'}</strong></div>
          </div>
          <img src="${qrDataUrl}" class="id-qr" style="width: 1.1in; height: 1.1in;">
        </div>

        <div class="id-card-footer">
          <div style="font-size: 4.8pt; max-width:2.0in;" class="text-muted lh-1">
            If found, please return to Barangay Hall. Property of Barangay Administration.
          </div>
          <div class="text-center" style="min-width: 1.0in;">
            ${settings.captain_signature ? `<img src="${settings.captain_signature}" style="height:18px; object-fit:contain; display:block; margin:auto;"><br>` : ''}
            <span style="font-size: 5.5pt; border-top: 1px solid #333; display: block; font-weight: 600; margin-top: -2px;">${escHtml(settings.barangay_captain || 'Barangay Captain')}</span>
          </div>
        </div>
      </div>`;
  };

  const myCard = await renderIdCard(resident);
  const familyCards = await Promise.all(family.map(async (m) => `
    <div class="d-inline-block mx-2 mb-4 align-top">
      ${await renderIdCard(m)}
      <div class="small text-muted mt-1">${escHtml(m.first_name)} ${escHtml(m.last_name)}${m.relationship ? ' (' + escHtml(m.relationship) + ')' : (m.is_household_head ? ' (Head)' : '')}${m.resident_status !== 'Active' ? ' - awaiting approval' : ''}</div>
    </div>`));

  const html = `
    <div class="text-center py-4">
      <h4 class="fw-bold text-primary-blue mb-3">Official Digital Barangay ID</h4>
      ${myCard}
    </div>
    ${family.length ? `
      <div class="text-center pb-4">
        <h5 class="fw-bold text-primary-blue mb-1"><i class="bi bi-people me-2"></i>My Household Members' IDs</h5>
        <p class="small text-muted mb-3">Each family member is a registered resident with their own ID and QR code. Show the member's QR code when they claim aid or documents.</p>
        ${familyCards.join('')}
      </div>` : ''}
  `;

  res.send(renderAppLayout(req, 'res-digital-id', html, settings));
});

// Resident Certificate Request
app.get('/resident/certificates', authenticateToken, requireRole(['Resident']), async (req, res) => {
  const settings = await getSettings();
  const { data: certs } = await supabase.from('certificate_requests').select('*').eq('resident_id', req.user.resident_id).order('created_at', { ascending: false });

  const html = `
    <div class="card card-custom p-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold text-primary-blue m-0"><i class="bi bi-file-earmark-plus me-2"></i>Request Official Barangay Certificates</h4>
        <button class="btn btn-accent-custom fw-bold text-white" data-bs-toggle="modal" data-bs-target="#reqCertModal"><i class="bi bi-plus-lg me-1"></i> New Request</button>
      </div>

      <div class="table-responsive">
        <table class="table table-hover align-middle">
          <thead class="table-light">
            <tr>
              <th>Request No</th>
              <th>Certificate Type</th>
              <th>Purpose</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            ${(certs || []).map(c => `
              <tr>
                <td class="fw-bold text-primary-blue">${c.request_number}</td>
                <td>${c.certificate_type}</td>
                <td>${c.purpose}</td>
                <td><span class="badge bg-warning text-dark">${c.status}</span></td>
              </tr>
            `).join('') || '<tr><td colspan="4" class="text-center py-4 text-muted">No document requests submitted.</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>

    <!-- Modal Request Certificate -->
    <div class="modal fade" id="reqCertModal" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <form action="/api/resident/certificate/request" method="POST">
            <div class="modal-header bg-primary-blue text-white">
              <h5 class="modal-title fw-bold">Apply for Barangay Document</h5>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <div class="mb-3">
                <label class="form-label">Certificate Type *</label>
                <select name="certificate_type" class="form-select" required>
                  <option value="Barangay Clearance">Barangay Clearance</option>
                  <option value="Certificate of Residency">Certificate of Residency</option>
                  <option value="Certificate of Indigency">Certificate of Indigency</option>
                  <option value="Certificate of Good Moral">Certificate of Good Moral</option>
                </select>
              </div>
              <div class="mb-3"><label class="form-label">Purpose *</label><input type="text" name="purpose" class="form-control" required placeholder="e.g. Employment, Scholarship, ID application"></div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary-custom text-white">Submit Application</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'res-certificates', html, settings));
});

app.post('/api/resident/certificate/request', authenticateToken, requireRole(['Resident']), async (req, res) => {
  const { certificate_type, purpose } = req.body;
  const request_number = `REQ-${Date.now().toString().slice(-6)}`;
  await supabase.from('certificate_requests').insert([{ request_number, resident_id: req.user.resident_id, certificate_type, purpose, status: 'SUBMITTED' }]);
  notifyStaff({ title: 'New certificate request', body: `${certificate_type} (${request_number}) was submitted.`, url: '/admin/certificates' });
  res.redirect('/resident/certificates');
});

// Resident Appointments
app.get('/resident/appointments', authenticateToken, requireRole(['Resident']), async (req, res) => {
  const settings = await getSettings();
  const { data: appts } = await supabase.from('appointments').select('*').eq('resident_id', req.user.resident_id);

  const html = `
    <div class="card card-custom p-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold text-primary-blue m-0"><i class="bi bi-calendar-plus me-2"></i>Book Barangay Office Appointment</h4>
        <button class="btn btn-accent-custom fw-bold text-white" data-bs-toggle="modal" data-bs-target="#bookApptModal"><i class="bi bi-plus-lg me-1"></i> Book Appointment</button>
      </div>

      <div class="table-responsive">
        <table class="table table-hover align-middle">
          <thead class="table-light">
            <tr>
              <th>Appt No</th>
              <th>Service</th>
              <th>Date & Time</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            ${(appts || []).map(a => `
              <tr>
                <td class="fw-bold text-primary-blue">${a.appointment_number}</td>
                <td>${a.service_requested}</td>
                <td>${a.appointment_date} at${a.appointment_time}</td>
                <td><span class="badge bg-primary text-white">${a.status}</span></td>
              </tr>
            `).join('') || '<tr><td colspan="4" class="text-center py-4 text-muted">No appointments booked.</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>

    <!-- Modal Book Appointment -->
    <div class="modal fade" id="bookApptModal" tabindex="-1">
      <div class="modal-dialog">
        <div class="modal-content">
          <form action="/api/resident/appointment/book" method="POST">
            <div class="modal-header bg-primary-blue text-white">
              <h5 class="modal-title fw-bold">Book Office Visit</h5>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <div class="mb-3"><label class="form-label">Service Requested *</label><input type="text" name="service_requested" class="form-control" required placeholder="e.g. Consult Captain, Document Filing"></div>
              <div class="mb-3"><label class="form-label">Preferred Date *</label><input type="date" name="appointment_date" class="form-control" required></div>
              <div class="mb-3"><label class="form-label">Preferred Time *</label><input type="text" name="appointment_time" class="form-control" required placeholder="e.g. 10:00 AM"></div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary-custom text-white">Submit Appointment</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'res-appointments', html, settings));
});

app.post('/api/resident/appointment/book', authenticateToken, requireRole(['Resident']), async (req, res) => {
  const { service_requested, appointment_date, appointment_time } = req.body;
  const appointment_number = `APT-${Date.now().toString().slice(-6)}`;
  await supabase.from('appointments').insert([{ appointment_number, resident_id: req.user.resident_id, service_requested, appointment_date, appointment_time, status: 'PENDING' }]);
  res.redirect('/resident/appointments');
});

// Resident Complaints
app.get('/resident/complaints', authenticateToken, requireRole(['Resident']), async (req, res) => {
  const settings = await getSettings();

  const html = `
    <div class="card card-custom p-4" style="max-width: 600px; margin: auto;">
      <h4 class="fw-bold text-primary-blue mb-3"><i class="bi bi-exclamation-triangle me-2"></i>File Community Incident or Complaint</h4>
      <form action="/api/resident/complaint/submit" method="POST">
        <div class="mb-3"><label class="form-label">Respondent Name / Entity *</label><input type="text" name="respondent_name" class="form-control" required></div>
        <div class="mb-3"><label class="form-label">Incident Date *</label><input type="date" name="incident_date" class="form-control" required></div>
        <div class="mb-3"><label class="form-label">Incident Location *</label><input type="text" name="location" class="form-control" required></div>
        <div class="mb-3"><label class="form-label">Detailed Description *</label><textarea name="description" class="form-control" rows="4" required></textarea></div>
        <button type="submit" class="btn btn-accent-custom py-2 w-100 fw-bold text-white">Submit Confidential Complaint</button>
      </form>
    </div>
  `;

  res.send(renderAppLayout(req, 'res-complaints', html, settings));
});

app.post('/api/resident/complaint/submit', authenticateToken, requireRole(['Resident']), async (req, res) => {
  const { respondent_name, incident_date, location, description } = req.body;
  const { data: resData } = await supabase.from('residents').select('first_name, last_name').eq('id', req.user.resident_id).single();
  const case_number = `BLOT-${Date.now().toString().slice(-6)}`;

  await supabase.from('complaints').insert([{
    case_number, complainant_id: req.user.resident_id, complainant_name: `${resData.first_name} ${resData.last_name}`,
    respondent_name, incident_date, location, description, status: 'SUBMITTED'
  }]);
  notifyStaff({ title: 'New complaint filed', body: `Case ${case_number} was submitted by ${resData.first_name} ${resData.last_name}.`, url: '/admin/blotters' });

  res.redirect('/resident/dashboard');
});

// Resident Assistance Requests
app.get('/resident/assistance', authenticateToken, requireRole(['Resident']), async (req, res) => {
  const settings = await getSettings();

  const html = `
    <div class="card card-custom p-4" style="max-width: 600px; margin: auto;">
      <h4 class="fw-bold text-primary-blue mb-3"><i class="bi bi-heart-pulse me-2"></i>Apply for Barangay Aid & Assistance</h4>
      <form action="/api/resident/assistance/request" method="POST">
        <div class="mb-3">
          <label class="form-label">Assistance Type *</label>
          <select name="assistance_type" class="form-select" required>
            <option value="Financial Assistance">Financial Assistance</option>
            <option value="Medical Assistance">Medical Assistance</option>
            <option value="Educational Assistance">Educational Assistance</option>
            <option value="Food Assistance">Food Assistance</option>
            <option value="Emergency Assistance">Emergency Assistance</option>
          </select>
        </div>
        <div class="mb-3"><label class="form-label">Details / Reason *</label><textarea name="details" class="form-control" rows="3" required></textarea></div>
        <button type="submit" class="btn btn-primary-custom py-2 w-100 fw-bold text-white">Submit Application</button>
      </form>
    </div>
  `;

  res.send(renderAppLayout(req, 'res-assistance', html, settings));
});

app.post('/api/resident/assistance/request', authenticateToken, requireRole(['Resident']), async (req, res) => {
  const { assistance_type, details } = req.body;
  const request_number = `AID-${Date.now().toString().slice(-6)}`;
  await supabase.from('assistance_requests').insert([{ request_number, resident_id: req.user.resident_id, assistance_type, details, status: 'PENDING' }]);
  notifyStaff({ title: 'New assistance request', body: `${assistance_type} (${request_number}) is waiting for review.`, url: '/admin/assistance' });
  res.redirect('/resident/dashboard');
});

// Resident Announcements Display
app.get('/resident/announcements', authenticateToken, requireRole(['Resident']), async (req, res) => {
  const settings = await getSettings();
  const { data: announcements } = await supabase.from('announcements').select('*').order('created_at', { ascending: false });

  const html = `
    <div class="card card-custom p-4">
      <h4 class="fw-bold text-primary-blue mb-3"><i class="bi bi-bell me-2"></i>Barangay News & Bulletin</h4>
      <div class="row g-3">
        ${(announcements || []).map(a => `
          <div class="col-md-6">
            <div class="card card-custom p-3 border-start border-4 ${a.priority === 'Emergency' ? 'border-danger' : 'border-primary'}">
              <h5 class="fw-bold text-primary-blue">${a.title}</h5>
              <p class="text-muted small">${a.content}</p>
              <small class="text-secondary">${new Date(a.created_at).toLocaleDateString()}</small>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'res-announcements', html, settings));
});

// Resident Emergency Contacts
app.get('/resident/emergency-contacts', authenticateToken, requireRole(['Resident']), async (req, res) => {
  const settings = await getSettings();

  const html = `
    <div class="card card-custom p-4">
      <h4 class="fw-bold text-primary-blue mb-3"><i class="bi bi-telephone me-2"></i>Emergency Hotline Directory</h4>
      <div class="row g-3">
        <div class="col-md-4">
          <div class="p-3 border rounded text-center bg-light-blue">
            <i class="bi bi-building fs-1 text-primary-blue"></i>
            <h5 class="fw-bold mt-2">Barangay Hall</h5>
            <p class="text-muted m-0">${settings.contact_number || '09123456789'}</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="p-3 border rounded text-center bg-light-green">
            <i class="bi bi-shield-fill fs-1 text-danger"></i>
            <h5 class="fw-bold mt-2">Police Station</h5>
            <p class="text-muted m-0">911 / (045) 123-4567</p>
          </div>
        </div>
        <div class="col-md-4">
          <div class="p-3 border rounded text-center bg-light-blue">
            <i class="bi bi-fire fs-1 text-warning"></i>
            <h5 class="fw-bold mt-2">Fire Department</h5>
            <p class="text-muted m-0">160 / (045) 765-4321</p>
          </div>
        </div>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'res-contacts', html, settings));
});

// Resident Feedback
app.get('/resident/feedback', authenticateToken, requireRole(['Resident']), async (req, res) => {
  const settings = await getSettings();

  const html = `
    <div class="card card-custom p-4" style="max-width: 500px; margin: auto;">
      <h4 class="fw-bold text-primary-blue mb-3"><i class="bi bi-chat-left-text me-2"></i>Barangay Service Feedback</h4>
      <form action="/api/resident/feedback/submit" method="POST">
        <div class="mb-3">
          <label class="form-label">Service Evaluated *</label>
          <input type="text" name="service_type" class="form-control" required placeholder="e.g. Document Request, Captain Consultation">
        </div>
        <div class="mb-3">
          <label class="form-label">Rating (1 to 5 Stars) *</label>
          <select name="rating" class="form-select" required>
            <option value="5">5 Stars - Excellent</option>
            <option value="4">4 Stars - Very Good</option>
            <option value="3">3 Stars - Satisfactory</option>
            <option value="2">2 Stars - Poor</option>
            <option value="1">1 Star - Very Poor</option>
          </select>
        </div>
        <div class="mb-3"><label class="form-label">Comments *</label><textarea name="comments" class="form-control" rows="3" required></textarea></div>
        <button type="submit" class="btn btn-primary-custom py-2 w-100 fw-bold text-white">Submit Feedback</button>
      </form>
    </div>
  `;

  res.send(renderAppLayout(req, 'res-feedback', html, settings));
});

app.post('/api/resident/feedback/submit', authenticateToken, requireRole(['Resident']), async (req, res) => {
  const { service_type, rating, comments } = req.body;
  await supabase.from('feedback').insert([{ resident_id: req.user.resident_id, service_type, rating: parseInt(rating), comments }]);
  res.redirect('/resident/dashboard');
});

// ==========================================
// ROUTE 21: AID / RELIEF DISTRIBUTION (Admin setup, Resident portal view, QR claiming)
// ==========================================
const STAFF_ROLES = ['Super Admin', 'Barangay Admin', 'Barangay Secretary', 'Barangay Staff'];
const AID_MANAGER_ROLES = ['Super Admin', 'Barangay Admin', 'Barangay Secretary'];

const escHtml = (v) => String(v === null || v === undefined ? '' : v)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

// ---------- ADMIN: list programs ----------
app.get('/admin/aid', authenticateToken, requireRole(STAFF_ROLES), async (req, res) => {
  const settings = await getSettings();
  const { data: programs } = await supabase.from('aid_programs').select('*').order('created_at', { ascending: false });
  const { data: bens } = await supabase.from('aid_beneficiaries').select('program_id, status');

  const stats = {};
  (bens || []).forEach(b => {
    stats[b.program_id] = stats[b.program_id] || { total: 0, claimed: 0 };
    stats[b.program_id].total++;
    if (b.status === 'Claimed') stats[b.program_id].claimed++;
  });

  const canManage = AID_MANAGER_ROLES.includes(req.user.role);

  const html = `
    <div class="card card-custom p-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold text-primary-blue m-0"><i class="bi bi-box2-heart me-2"></i>Aid & Relief Distribution</h4>
        ${canManage ? `<button class="btn btn-accent-custom fw-bold text-white" data-bs-toggle="modal" data-bs-target="#addAidModal"><i class="bi bi-plus-lg me-1"></i> New Aid Program</button>` : ''}
      </div>
      <p class="text-muted small">Create an aid program, choose the beneficiaries, and residents will see it in their portal. Claiming is verified by scanning the QR code on the resident's Barangay ID in the <a href="/scanner">QR Scanner</a>.</p>

      <div class="table-responsive">
        <table class="table table-hover align-middle">
          <thead class="table-light">
            <tr>
              <th>Aid Program</th>
              <th>Type</th>
              <th>Distribution</th>
              <th>Claimed / Beneficiaries</th>
              <th>Status</th>
              <th class="text-end">Actions</th>
            </tr>
          </thead>
          <tbody>
            ${(programs || []).map(p => {
              const s = stats[p.id] || { total: 0, claimed: 0 };
              return `
                <tr>
                  <td class="fw-bold text-primary-blue">${escHtml(p.title)}</td>
                  <td><span class="badge bg-info text-dark">${escHtml(p.aid_type)}</span></td>
                  <td class="small">${escHtml(p.distribution_date || '-')}<br><span class="text-muted">${escHtml(p.location || '')}</span></td>
                  <td><span class="badge bg-accent-green text-white">${s.claimed} / ${s.total}</span></td>
                  <td><span class="badge ${p.status === 'Open' ? 'bg-success' : 'bg-secondary'}">${escHtml(p.status)}</span></td>
                  <td class="text-end"><a href="/admin/aid/${p.id}" class="btn btn-sm btn-outline-primary"><i class="bi bi-eye"></i> Manage</a></td>
                </tr>`;
            }).join('') || '<tr><td colspan="6" class="text-center py-4 text-muted">No aid programs yet.</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>

    <!-- Modal: New Aid Program -->
    <div class="modal fade" id="addAidModal" tabindex="-1">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <form action="/api/admin/aid/add" method="POST">
            <div class="modal-header bg-primary-blue text-white">
              <h5 class="modal-title fw-bold">New Aid Program</h5>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <div class="row g-3">
                <div class="col-md-8"><label class="form-label">Aid Title *</label><input type="text" name="title" class="form-control" required placeholder="e.g. Rice & Grocery Relief Pack"></div>
                <div class="col-md-4">
                  <label class="form-label">Aid Type *</label>
                  <select name="aid_type" class="form-select" required>
                    <option>Food Pack</option><option>Cash Assistance</option><option>Medical</option><option>Educational</option><option>Livelihood</option><option>Other</option>
                  </select>
                </div>
                <div class="col-md-6"><label class="form-label">Distribution Date</label><input type="date" name="distribution_date" class="form-control"></div>
                <div class="col-md-6"><label class="form-label">Claiming Location</label><input type="text" name="location" class="form-control" placeholder="e.g. Barangay Hall"></div>
                <div class="col-12"><label class="form-label">Description / Claiming Instructions</label><textarea name="description" class="form-control" rows="3" placeholder="e.g. Bring your Barangay ID. The QR code will be scanned at the claiming booth."></textarea></div>
                <div class="col-12">
                  <label class="form-label fw-bold">Who will receive this aid?</label>
                  <div class="border rounded p-3 bg-light">
                    <div class="row g-2">
                      <div class="col-6"><div class="form-check"><input class="form-check-input" type="checkbox" name="group" value="college" id="grpCollege"><label class="form-check-label" for="grpCollege">College Students</label></div></div>
                      <div class="col-6"><div class="form-check"><input class="form-check-input" type="checkbox" name="group" value="head" id="grpHead"><label class="form-check-label" for="grpHead">Household Heads</label></div></div>
                      <div class="col-6"><div class="form-check"><input class="form-check-input" type="checkbox" name="group" value="seniors" id="grpSeniors"><label class="form-check-label" for="grpSeniors">Senior Citizens</label></div></div>
                      <div class="col-6"><div class="form-check"><input class="form-check-input" type="checkbox" name="group" value="pwd" id="grpPwd"><label class="form-check-label" for="grpPwd">PWD</label></div></div>
                      <div class="col-6"><div class="form-check"><input class="form-check-input" type="checkbox" name="group" value="solo" id="grpSolo"><label class="form-check-label" for="grpSolo">Solo Parents</label></div></div>
                      <div class="col-6"><div class="form-check"><input class="form-check-input" type="checkbox" name="group" value="all" id="grpAll"><label class="form-check-label" for="grpAll">All Active Residents</label></div></div>
                    </div>
                    <small class="text-muted d-block mt-2">Tick one or more groups to add them automatically. <strong>Leave all unticked to select residents manually</strong> after creating the program.</small>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-primary-custom text-white">Create Aid Program</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'aid', html, settings));
});

app.post('/api/admin/aid/add', authenticateToken, requireRole(AID_MANAGER_ROLES), async (req, res) => {
  try {
    const { title, aid_type, distribution_date, location, description } = req.body;
    const { data: program, error } = await supabase.from('aid_programs').insert([{
      title, aid_type, distribution_date: distribution_date || null, location, description, status: 'Open', created_by: req.user.id
    }]).select().single();
    if (error) throw error;

    // Checkboxes may arrive as a single value or an array. No selection = manual picking afterwards.
    let groups = req.body.group || [];
    if (!Array.isArray(groups)) groups = [groups];
    const columnFor = { college: 'is_college_student', head: 'is_household_head', seniors: 'is_senior_citizen', pwd: 'is_pwd', solo: 'is_solo_parent' };
    const conditions = groups.filter(g => columnFor[g]).map(g => `${columnFor[g]}.eq.true`);

    if (groups.includes('all') || conditions.length) {
      let q = supabase.from('residents').select('id').eq('resident_status', 'Active');
      if (!groups.includes('all')) q = q.or(conditions.join(','));
      const { data: residents } = await q;
      const rows = (residents || []).map(r => ({ program_id: program.id, resident_id: r.id, status: 'Pending' }));
      if (rows.length) {
        await supabase.from('aid_beneficiaries').insert(rows);
        notifyResidents(rows.map(r => r.resident_id), { title: 'Aid available: ' + title, body: `You are a beneficiary. ${distribution_date ? 'Distribution: ' + distribution_date + '. ' : ''}Bring your Barangay ID.`, url: '/resident/aid' });
      }
    }

    await logActivity(req.user.id, 'Create Aid Program', `Created aid program: ${title}`);
    res.redirect(`/admin/aid/${program.id}`);
  } catch (err) {
    console.error('Create aid error:', err);
    res.status(500).send('Error creating aid program: ' + err.message);
  }
});

// ---------- ADMIN: manage one program ----------
app.get('/admin/aid/:id', authenticateToken, requireRole(STAFF_ROLES), async (req, res) => {
  const settings = await getSettings();
  const { data: program } = await supabase.from('aid_programs').select('*').eq('id', req.params.id).single();
  if (!program) return res.status(404).send('Aid program not found');

  const { data: bens } = await supabase.from('aid_beneficiaries')
    .select('*, residents(first_name, last_name, resident_number, puroks(name), households(household_name, household_number))')
    .eq('program_id', program.id).order('created_at', { ascending: true });

  const existingIds = new Set((bens || []).map(b => b.resident_id));
  const { data: allResidents } = await supabase.from('residents').select('id, first_name, last_name, resident_number, is_college_student, is_household_head, is_senior_citizen, is_pwd, households(household_name)').eq('resident_status', 'Active').order('last_name', { ascending: true });
  const available = (allResidents || []).filter(r => !existingIds.has(r.id));

  const claimed = (bens || []).filter(b => b.status === 'Claimed').length;
  const canManage = AID_MANAGER_ROLES.includes(req.user.role);

  const html = `
    <div class="card card-custom p-4 mb-3">
      <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
        <div>
          <a href="/admin/aid" class="small text-decoration-none"><i class="bi bi-arrow-left"></i> Back to Aid Programs</a>
          <h4 class="fw-bold text-primary-blue mt-1 mb-1">${escHtml(program.title)}</h4>
          <span class="badge bg-info text-dark">${escHtml(program.aid_type)}</span>
          <span class="badge ${program.status === 'Open' ? 'bg-success' : 'bg-secondary'}">${escHtml(program.status)}</span>
          <p class="text-muted small mt-2 mb-0">${escHtml(program.description || '')}</p>
          <p class="small mt-1 mb-0"><i class="bi bi-calendar3 me-1"></i>${escHtml(program.distribution_date || 'Date to be announced')} &nbsp; <i class="bi bi-geo-alt me-1"></i>${escHtml(program.location || 'Barangay Hall')}</p>
        </div>
        <div class="text-end">
          <h3 class="fw-bold text-accent-green m-0">${claimed} / ${(bens || []).length}</h3>
          <small class="text-muted">claimed</small>
          <div class="mt-2 d-flex gap-2 justify-content-end">
            <a href="/scanner" class="btn btn-sm btn-primary-custom text-white"><i class="bi bi-qr-code-scan me-1"></i> Open Scanner</a>
            ${canManage ? `
              <form action="/api/admin/aid/${program.id}/status" method="POST" class="d-inline">
                <input type="hidden" name="status" value="${program.status === 'Open' ? 'Closed' : 'Open'}">
                <button class="btn btn-sm btn-outline-secondary" onclick="return confirm('${program.status === 'Open' ? 'Close' : 'Reopen'} this aid program?')">${program.status === 'Open' ? 'Close Program' : 'Reopen'}</button>
              </form>` : ''}
          </div>
        </div>
      </div>
    </div>

    ${canManage ? `
    <div class="card card-custom p-4 mb-3 no-print">
      <h6 class="fw-bold text-accent-green mb-2">Add Beneficiaries</h6>
      <form action="/api/admin/aid/${program.id}/beneficiaries" method="POST" class="row g-2">
        <div class="col-md-9">
          <select name="resident_ids" class="form-select" multiple size="5" required>
            ${available.map(r => `<option value="${r.id}">${escHtml(r.last_name)}, ${escHtml(r.first_name)} (${escHtml(r.resident_number)})${r.households && r.households.household_name ? ' - ' + escHtml(r.households.household_name) : ''}${categoryTags(r).length ? ' [' + categoryTags(r).join(', ') + ']' : ''}</option>`).join('')}
          </select>
          <small class="text-muted">Hold Ctrl / Cmd to select multiple residents.</small>
        </div>
        <div class="col-md-3 d-grid align-content-start">
          <button class="btn btn-accent-custom text-white fw-bold" ${available.length ? '' : 'disabled'}><i class="bi bi-person-plus me-1"></i> Add Selected</button>
        </div>
      </form>
    </div>` : ''}

    <div class="card card-custom p-4">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h6 class="fw-bold text-primary-blue m-0">Beneficiary List</h6>
        <button class="btn btn-sm btn-outline-primary no-print" onclick="window.print()"><i class="bi bi-printer me-1"></i> Print List</button>
      </div>
      <div class="table-responsive">
        <table class="table table-hover align-middle">
          <thead class="table-light">
            <tr><th>Resident ID</th><th>Name</th><th>Household</th><th>Purok</th><th>Status</th><th>Claimed At</th><th class="text-end no-print">Action</th></tr>
          </thead>
          <tbody>
            ${(bens || []).map(b => `
              <tr>
                <td class="fw-bold text-primary-blue">${b.residents ? escHtml(b.residents.resident_number) : '-'}</td>
                <td>${b.residents ? `${escHtml(b.residents.first_name)} ${escHtml(b.residents.last_name)}` : 'Unknown'}</td>
                <td class="small">${b.residents && b.residents.households ? escHtml(b.residents.households.household_name || b.residents.households.household_number) : '<span class="text-muted">-</span>'}</td>
                <td>${b.residents && b.residents.puroks ? escHtml(b.residents.puroks.name) : '-'}</td>
                <td><span class="badge ${b.status === 'Claimed' ? 'bg-success' : 'bg-warning text-dark'}">${escHtml(b.status)}</span></td>
                <td class="small text-muted">${b.claimed_at ? new Date(b.claimed_at).toLocaleString() : '-'}</td>
                <td class="text-end no-print">
                  ${canManage && b.status !== 'Claimed' ? `
                    <form action="/api/admin/aid/beneficiary/${b.id}/remove" method="POST" class="d-inline" onsubmit="return confirm('Remove this beneficiary?')">
                      <button class="btn btn-sm btn-outline-danger"><i class="bi bi-x-lg"></i></button>
                    </form>` : ''}
                </td>
              </tr>
            `).join('') || '<tr><td colspan="7" class="text-center py-4 text-muted">No beneficiaries yet.</td></tr>'}
          </tbody>
        </table>
      </div>
    </div>
  `;

  res.send(renderAppLayout(req, 'aid', html, settings));
});

app.post('/api/admin/aid/:id/beneficiaries', authenticateToken, requireRole(AID_MANAGER_ROLES), async (req, res) => {
  try {
    let ids = req.body.resident_ids || [];
    if (!Array.isArray(ids)) ids = [ids];
    const { data: existing } = await supabase.from('aid_beneficiaries').select('resident_id').eq('program_id', req.params.id);
    const have = new Set((existing || []).map(e => e.resident_id));
    const rows = ids.filter(id => !have.has(id)).map(id => ({ program_id: req.params.id, resident_id: id, status: 'Pending' }));
    if (rows.length) {
      await supabase.from('aid_beneficiaries').insert(rows);
      const { data: prog } = await supabase.from('aid_programs').select('title').eq('id', req.params.id).maybeSingle();
      notifyResidents(rows.map(r => r.resident_id), { title: 'Aid available: ' + (prog ? prog.title : 'Barangay Aid'), body: 'You were added as a beneficiary. Bring your Barangay ID.', url: '/resident/aid' });
    }
    await logActivity(req.user.id, 'Add Aid Beneficiaries', `Added ${rows.length} beneficiaries to aid program ${req.params.id}`);
    res.redirect(`/admin/aid/${req.params.id}`);
  } catch (err) {
    res.status(500).send('Error adding beneficiaries: ' + err.message);
  }
});

app.post('/api/admin/aid/beneficiary/:id/remove', authenticateToken, requireRole(AID_MANAGER_ROLES), async (req, res) => {
  const { data: ben } = await supabase.from('aid_beneficiaries').select('program_id').eq('id', req.params.id).single();
  await supabase.from('aid_beneficiaries').delete().eq('id', req.params.id).eq('status', 'Pending');
  await logActivity(req.user.id, 'Remove Aid Beneficiary', `Removed beneficiary record ${req.params.id}`);
  res.redirect(ben ? `/admin/aid/${ben.program_id}` : '/admin/aid');
});

app.post('/api/admin/aid/:id/status', authenticateToken, requireRole(AID_MANAGER_ROLES), async (req, res) => {
  const status = req.body.status === 'Closed' ? 'Closed' : 'Open';
  await supabase.from('aid_programs').update({ status }).eq('id', req.params.id);
  await logActivity(req.user.id, 'Update Aid Program', `Set aid program ${req.params.id} to ${status}`);
  res.redirect(`/admin/aid/${req.params.id}`);
});

// ---------- Household-based aid: one claim per household per program ----------
async function getHouseholdMemberIds(residentId) {
  const { data: r } = await supabase.from('residents').select('household_id').eq('id', residentId).maybeSingle();
  if (!r || !r.household_id) return [residentId]; // no household linked: treated as its own household
  const { data: members } = await supabase.from('residents').select('id').eq('household_id', r.household_id);
  const ids = (members || []).map(m => m.id);
  return ids.length ? ids : [residentId];
}

// Claims the aid for the scanned resident AND closes the same aid for every other member of the household.
async function claimAidForHousehold(ben, staffId) {
  const memberIds = await getHouseholdMemberIds(ben.resident_id);
  const { data: already } = await supabase.from('aid_beneficiaries').select('id')
    .eq('program_id', ben.program_id).in('resident_id', memberIds).eq('status', 'Claimed').limit(1);
  if (already && already.length) return { ok: false };

  const stamp = { status: 'Claimed', claimed_at: new Date(), claimed_by: staffId };
  const { data: updated } = await supabase.from('aid_beneficiaries').update(stamp).eq('id', ben.id).eq('status', 'Pending').select();
  if (!updated || !updated.length) return { ok: false };

  const others = memberIds.filter(id => id !== ben.resident_id);
  if (others.length) {
    await supabase.from('aid_beneficiaries').update(stamp)
      .eq('program_id', ben.program_id).in('resident_id', others).eq('status', 'Pending');
  }
  return { ok: true, members: memberIds.length };
}

// ---------- SCANNER: claim aid after QR verification ----------
app.post('/api/scanner/claim', authenticateToken, requireRole(STAFF_ROLES), async (req, res) => {
  const settings = await getSettings();
  const { beneficiary_id, qr_token } = req.body;

  // Re-verify the scanned QR token so a claim can only be made with a valid ID scan
  const { data: resident } = await supabase.from('residents').select('id, first_name, last_name, resident_status').eq('qr_token', qr_token).single();
  const { data: ben } = await supabase.from('aid_beneficiaries').select('*, aid_programs(title, status)').eq('id', beneficiary_id).single();

  let msg;
  if (!resident || !ben || ben.resident_id !== resident.id) {
    msg = `<div class="alert alert-danger text-center"><strong>Claim Failed!</strong><br>The scanned ID does not match this aid record.</div>`;
  } else if (!ben.aid_programs || ben.aid_programs.status !== 'Open') {
    msg = `<div class="alert alert-warning text-center"><strong>Program Closed.</strong><br>This aid program is no longer open for claiming.</div>`;
  } else {
    const claim = await claimAidForHousehold(ben, req.user.id);
    if (claim.ok) {
      await logActivity(req.user.id, 'Aid Claimed', `${resident.first_name} ${resident.last_name} claimed "${ben.aid_programs.title}" via QR verification`);
      msg = `<div class="alert alert-success text-center"><i class="bi bi-check-circle-fill fs-3 d-block mb-2"></i><strong>Aid Released!</strong><br>${escHtml(resident.first_name)} ${escHtml(resident.last_name)} claimed <strong>${escHtml(ben.aid_programs.title)}</strong>.<br><small>Recorded for the whole household.</small></div>`;
    } else {
      msg = `<div class="alert alert-warning text-center"><strong>Already Claimed.</strong><br>This aid was already released to this resident or another member of the same household.</div>`;
    }
  }

  res.send(renderAppLayout(req, 'qr-scanner', `${msg}<div class="text-center"><a href="/scanner" class="btn btn-primary-custom text-white">Scan Next Resident</a></div>`, settings));
});


// ==========================================
// SCANNER: shared UI (beep + voice), scan-only page, JSON API
// ==========================================
const renderScannerBody = () => `
<style>
  #scanStatus { border-radius: 14px; padding: 16px; text-align: center; font-weight: 700; font-size: 1.15rem; transition: background .2s, color .2s; }
  #scanStatus .st-icon { font-size: 2.2rem; display: block; margin-bottom: 4px; line-height: 1.1; }
  #scanStatus small { display: block; font-weight: 500; margin-top: 2px; }
  .st-idle { background: var(--light-blue); color: var(--primary-navy); }
  .st-checking { background: #fff3cd; color: #664d03; }
  .st-success { background: #d1e7dd; color: #0f5132; }
  .st-error { background: #f8d7da; color: #842029; }
  .st-warn { background: #fff3cd; color: #664d03; }
  #scanStatus .btn-loading-spinner { width: 2rem; height: 2rem; border-width: 4px; margin: 0 auto 6px; display: block; }
  #reader { width: 100%; max-width: 460px; margin: auto; display: none; }
  .scan-photo { width: 84px; height: 84px; object-fit: cover; border-radius: 50%; background: #e9ecef; }
  .scan-row { display: flex; justify-content: space-between; align-items: center; gap: 8px; padding: 8px 10px; border-radius: 8px; margin-bottom: 6px; background: #f1faf4; border: 1px solid #cfe8d7; }
  .scan-row.done { background: #e9ecef; border-color: #dee2e6; opacity: .8; }
</style>

<div id="scanApp">
  <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
    <h5 class="fw-bold text-primary-blue m-0"><i class="bi bi-qr-code-scan me-2"></i>QR Scanner</h5>
    <div class="btn-group btn-group-sm">
      <button type="button" id="soundBtn" class="btn btn-outline-primary"></button>
      <button type="button" id="voiceBtn" class="btn btn-outline-primary"></button>
    </div>
  </div>

  <div id="scanStatus" class="st-idle"></div>

  <div class="text-center my-3">
    <div id="reader" class="border rounded p-2 bg-black"></div>
    <button type="button" id="camBtn" class="btn btn-accent-custom text-white fw-bold mt-2"><i class="bi bi-camera-video me-1"></i> Start Camera</button>
  </div>

  <form id="manualForm" class="mb-3" data-no-loader autocomplete="off">
    <div class="input-group">
      <input type="text" id="qr_token" class="form-control" placeholder="Scan with scanner gun or type QR token..." required>
      <button type="submit" class="btn btn-primary-custom fw-bold text-white">Verify</button>
    </div>
  </form>

  <div id="scanResult"></div>
</div>

<script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
<script>
(function () {
  var $ = function (id) { return document.getElementById(id); };
  var soundOn = true, voiceOn = true, busy = false, cam = null, camRunning = false, resumeTimer = null;
  try {
    soundOn = localStorage.getItem('scanSound') !== 'off';
    voiceOn = localStorage.getItem('scanVoice') !== 'off';
  } catch (e) {}

  // ---------- Sound (beep) ----------
  var audioCtx = null;
  function getCtx() {
    if (!audioCtx) {
      var AC = window.AudioContext || window.webkitAudioContext;
      if (AC) audioCtx = new AC();
    }
    if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
    return audioCtx;
  }
  function tone(freq, start, dur, type, vol) {
    var ctx = getCtx();
    if (!ctx) return;
    var o = ctx.createOscillator(), g = ctx.createGain(), t0 = ctx.currentTime + start;
    o.type = type || 'sine';
    o.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol || 0.25, t0 + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g); g.connect(ctx.destination);
    o.start(t0); o.stop(t0 + dur + 0.03);
  }
  var sounds = {
    // Clear, loud two-note "ding-dong" chime (soft sine tones, no buzzing)
    scan: function () {
      tone(880, 0, 0.18, 'sine', 0.9);
      tone(1318, 0.12, 0.3, 'sine', 0.9);
    },
    success: function () { tone(880, 0, 0.12, 'sine', 0.3); tone(1320, 0.14, 0.22, 'sine', 0.3); },
    warn: function () { tone(600, 0, 0.15, 'triangle', 0.3); tone(600, 0.22, 0.15, 'triangle', 0.3); },
    error: function () { tone(220, 0, 0.35, 'sawtooth', 0.2); tone(170, 0.4, 0.4, 'sawtooth', 0.2); }
  };
  function beep(kind) {
    if (soundOn && sounds[kind]) sounds[kind]();
    if (navigator.vibrate) { try { navigator.vibrate(kind === 'error' ? [200, 100, 200] : 120); } catch (e) {} }
  }

  // ---------- Voice ----------
  function speak(text) {
    if (!voiceOn || !text || !('speechSynthesis' in window)) return;
    try {
      window.speechSynthesis.cancel();
      var u = new SpeechSynthesisUtterance(text);
      u.lang = 'en-US'; u.rate = 0.95; u.volume = 1;
      window.speechSynthesis.speak(u);
    } catch (e) {}
  }

  function refreshToggles() {
    $('soundBtn').innerHTML = '<i class="bi ' + (soundOn ? 'bi-volume-up-fill' : 'bi-volume-mute-fill') + ' me-1"></i>Beep: ' + (soundOn ? 'On' : 'Off');
    $('voiceBtn').innerHTML = '<i class="bi ' + (voiceOn ? 'bi-megaphone-fill' : 'bi-megaphone') + ' me-1"></i>Voice: ' + (voiceOn ? 'On' : 'Off');
  }
  $('soundBtn').onclick = function () {
    soundOn = !soundOn;
    try { localStorage.setItem('scanSound', soundOn ? 'on' : 'off'); } catch (e) {}
    refreshToggles();
    if (soundOn) sounds.scan();
  };
  $('voiceBtn').onclick = function () {
    voiceOn = !voiceOn;
    try { localStorage.setItem('scanVoice', voiceOn ? 'on' : 'off'); } catch (e) {}
    refreshToggles();
    if (voiceOn) speak('Voice is on');
    else if ('speechSynthesis' in window) window.speechSynthesis.cancel();
  };
  document.addEventListener('pointerdown', getCtx, { once: true }); // unlock audio on first touch

  // ---------- Helpers ----------
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined && text !== null) e.textContent = text;
    return e;
  }
  var ICONS = { idle: 'bi-qr-code-scan', success: 'bi-check-circle-fill', error: 'bi-x-octagon-fill', warn: 'bi-exclamation-triangle-fill' };
  function setStatus(kind, title, sub) {
    var box = $('scanStatus');
    box.className = 'st-' + kind;
    box.innerHTML = '';
    if (kind === 'checking') box.appendChild(el('span', 'btn-loading-spinner'));
    else box.appendChild(el('i', 'bi st-icon ' + ICONS[kind]));
    box.appendChild(el('div', '', title));
    if (sub) box.appendChild(el('small', '', sub));
  }
  function post(url, payload) {
    return fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      credentials: 'same-origin',
      body: JSON.stringify(payload)
    }).then(function (r) {
      if (r.status === 401 || r.status === 403) {
        setTimeout(function () { window.location.href = '/login'; }, 2500);
        return { success: false, level: 'error', message: 'Session expired. Please log in again.', spoken: 'Session expired. Please log in again.' };
      }
      return r.json();
    }).catch(function () {
      return { success: false, level: 'error', message: 'Network error. Check your connection.', spoken: 'Network error.' };
    });
  }
  function announce(d) {
    var kind = d.success ? 'success' : (d.level === 'warn' ? 'warn' : 'error');
    setStatus(kind, d.message || '', d.detail || '');
    beep(kind);
    speak(d.spoken || d.message);
    return kind;
  }

  // ---------- Camera ----------
  function pauseScan() { if (cam && camRunning) { try { cam.pause(true); } catch (e) {} } }
  function resumeScan() {
    clearTimeout(resumeTimer);
    if (cam && camRunning) { try { cam.resume(); } catch (e) {} }
    busy = false;
    $('scanResult').innerHTML = '';
    setStatus('idle', 'Ready to scan', camRunning ? 'Point the camera at a resident QR code' : 'Start the camera or use a scanner');
    $('qr_token').value = '';
    $('qr_token').focus();
  }
  function startCamera() {
    getCtx();
    if (typeof Html5Qrcode === 'undefined') { setStatus('error', 'Camera library failed to load', 'Check your internet connection'); return; }
    $('reader').style.display = 'block';
    $('camBtn').disabled = true;
    cam = cam || new Html5Qrcode('reader');
    cam.start({ facingMode: 'environment' }, { fps: 10, qrbox: { width: 250, height: 250 } }, function (text) {
      if (busy) return;
      pauseScan();
      handleToken(String(text).trim());
    }, function () {}).then(function () {
      camRunning = true;
      $('camBtn').disabled = false;
      $('camBtn').innerHTML = '<i class="bi bi-stop-circle me-1"></i> Stop Camera';
      resumeScan();
    }).catch(function (err) {
      $('reader').style.display = 'none';
      $('camBtn').disabled = false;
      setStatus('error', 'Unable to access camera', String(err));
      beep('error');
    });
  }
  function stopCamera() {
    if (!cam) return;
    cam.stop().then(function () {
      camRunning = false;
      $('reader').style.display = 'none';
      $('camBtn').innerHTML = '<i class="bi bi-camera-video me-1"></i> Start Camera';
      setStatus('idle', 'Camera stopped', 'Use a scanner or start the camera again');
    }).catch(function () {});
  }
  $('camBtn').onclick = function () { if (camRunning) stopCamera(); else startCamera(); };

  // ---------- Scan flow ----------
  function handleToken(token) {
    if (!token) return;
    busy = true;
    clearTimeout(resumeTimer);
    $('scanResult').innerHTML = '';
    beep('scan');
    setStatus('checking', 'Checking...', '');
    post('/api/scanner/lookup', { qr_token: token }).then(function (d) {
      announce(d);
      if (!d.success) { resumeTimer = setTimeout(resumeScan, 3000); return; }
      renderResident(d, token);
    });
  }

  function renderResident(d, token) {
    var box = $('scanResult');
    box.innerHTML = '';
    var card = el('div', 'card card-custom p-3 border-success');
    var top = el('div', 'd-flex align-items-center gap-3 mb-2');
    if (d.resident.photo) { var img = el('img', 'scan-photo'); img.src = d.resident.photo; img.alt = ''; top.appendChild(img); }
    else { top.appendChild(el('div', 'scan-photo d-flex align-items-center justify-content-center fs-2 text-secondary')).innerHTML = '<i class="bi bi-person-fill"></i>'; }
    var info = el('div');
    info.appendChild(el('h5', 'fw-bold m-0', d.resident.name));
    info.appendChild(el('small', 'text-primary-blue fw-bold d-block', d.resident.number));
    info.appendChild(el('small', 'd-block text-muted', 'Purok: ' + (d.resident.purok || '-')));
    info.appendChild(el('small', 'd-block text-muted', d.resident.address || ''));
    info.appendChild(el('span', 'badge bg-success mt-1', d.resident.status || 'Active'));
    top.appendChild(info);
    card.appendChild(top);

    var pending = 0;
    function itemDone() {
      pending--;
      if (pending <= 0) resumeTimer = setTimeout(resumeScan, 3500);
    }
    function addRow(parent, title, subtitle, btnLabel, btnIcon, run) {
      pending++;
      var row = el('div', 'scan-row');
      var txt = el('div');
      txt.appendChild(el('strong', '', title));
      if (subtitle) txt.appendChild(el('small', 'd-block text-muted', subtitle));
      row.appendChild(txt);
      var btn = el('button', 'btn btn-sm btn-accent-custom text-white fw-bold');
      btn.type = 'button';
      btn.innerHTML = '<i class="bi ' + btnIcon + ' me-1"></i>' + btnLabel;
      btn.onclick = function () {
        if (!window.confirm(btnLabel + ' - are you sure?')) return;
        clearTimeout(resumeTimer);
        btn.disabled = true;
        btn.innerHTML = '<span class="btn-loading-spinner"></span>Working...';
        setStatus('checking', 'Processing...', '');
        run().then(function (r) {
          var kind = announce(r);
          if (r.success || r.final) {
            row.className = 'scan-row done';
            var tag = el('span', 'badge ' + (r.success ? 'bg-success' : 'bg-secondary'), r.badge || (r.success ? 'Done' : 'Closed'));
            btn.replaceWith(tag);
            itemDone();
          } else {
            btn.disabled = false;
            btn.innerHTML = '<i class="bi ' + btnIcon + ' me-1"></i>' + btnLabel;
          }
        });
      };
      row.appendChild(btn);
      parent.appendChild(row);
    }

    if (d.certificates.length) {
      var cwrap = el('div', 'mt-2');
      cwrap.appendChild(el('h6', 'fw-bold text-primary-blue', 'Certificates Ready for Release'));
      d.certificates.forEach(function (c) {
        addRow(cwrap, c.type, c.number, 'Mark Released', 'bi-file-earmark-check', function () {
          return post('/api/scanner/release-certificate', { certificate_id: c.id, qr_token: token });
        });
      });
      card.appendChild(cwrap);
    }
    var awrap = el('div', 'mt-2');
    awrap.appendChild(el('h6', 'fw-bold text-accent-green', 'Aid Available to Claim'));
    if (d.aid.length) {
      d.aid.forEach(function (a) {
        addRow(awrap, a.title, a.type, 'Release Aid', 'bi-check2-circle', function () {
          return post('/api/scanner/claim-json', { beneficiary_id: a.id, qr_token: token });
        });
      });
    } else {
      awrap.appendChild(el('p', 'text-muted small m-0', 'No unclaimed aid for this resident.'));
    }
    card.appendChild(awrap);

    var next = el('button', 'btn btn-primary-custom text-white fw-bold w-100 mt-3');
    next.type = 'button';
    next.innerHTML = '<i class="bi bi-arrow-repeat me-1"></i> Scan Next';
    next.onclick = resumeScan;
    card.appendChild(next);
    box.appendChild(card);
  }

  $('manualForm').addEventListener('submit', function (e) {
    e.preventDefault();
    getCtx();
    if (busy) return;
    handleToken($('qr_token').value.trim());
  });

  refreshToggles();
  setStatus('idle', 'Ready to scan', 'Start the camera or use a scanner');
  $('qr_token').focus();
})();
</script>
`;

// Embedded version (inside the admin layout)
app.get('/scanner', authenticateToken, requireRole(STAFF_ROLES), async (req, res) => {
  const settings = await getSettings();
  const html = `
    <div class="card card-custom p-4 mb-3" style="max-width: 650px; margin: auto;">
      ${renderScannerBody()}
    </div>
    <div class="card card-custom p-3" style="max-width: 650px; margin: auto;">
      <h6 class="fw-bold text-primary-blue"><i class="bi bi-link-45deg me-1"></i> Scan-Only Link</h6>
      <p class="small text-muted mb-2">A clean full-screen page with only the scanner. Staff must still be logged in. Bookmark it or add it to the phone home screen.</p>
      <div class="input-group input-group-sm">
        <input type="text" id="scanLinkField" class="form-control" readonly>
        <button type="button" class="btn btn-outline-primary" id="copyScanLink"><i class="bi bi-clipboard me-1"></i>Copy</button>
        <a href="/scan" target="_blank" class="btn btn-primary-custom text-white"><i class="bi bi-box-arrow-up-right me-1"></i>Open</a>
      </div>
    </div>
    <script>
      (function () {
        var f = document.getElementById('scanLinkField');
        f.value = window.location.origin + '/scan';
        document.getElementById('copyScanLink').onclick = function () {
          f.select();
          if (navigator.clipboard) navigator.clipboard.writeText(f.value);
          else document.execCommand('copy');
          this.innerHTML = '<i class="bi bi-check2 me-1"></i>Copied';
        };
      })();
    </script>
  `;
  res.send(renderAppLayout(req, 'qr-scanner', html, settings));
});

// Scan-only page (no sidebar, phone/kiosk friendly)
app.get('/scan', authenticateToken, requireRole(STAFF_ROLES), async (req, res) => {
  const settings = await getSettings();
  res.send(`
    ${renderSystemHead('Scanner')}
    <div class="container py-3" style="max-width: 640px;">
      <div class="d-flex align-items-center justify-content-between mb-3">
        <div class="d-flex align-items-center">
          ${settings.barangay_logo ? `<img src="${settings.barangay_logo}" class="me-2 rounded-circle" style="width:44px;height:44px;object-fit:cover;">` : '<i class="bi bi-building fs-2 me-2 text-primary-blue"></i>'}
          <div>
            <div class="fw-bold text-primary-blue lh-1">${escHtml(settings.barangay_name || 'Barangay Portal')}</div>
            <small class="text-muted">Scan-Only Mode</small>
          </div>
        </div>
        <div class="d-flex gap-2">
          <a href="/admin/dashboard" class="btn btn-sm btn-outline-secondary"><i class="bi bi-house"></i></a>
          <a href="/logout" class="btn btn-sm btn-outline-danger"><i class="bi bi-box-arrow-right"></i></a>
        </div>
      </div>
      <div class="card card-custom p-3">
        ${renderScannerBody()}
      </div>
    </div>
    ${renderSystemFooter()}
  `);
});

// JSON: look up a resident from a scanned QR token
app.post('/api/scanner/lookup', authenticateToken, requireRole(STAFF_ROLES), async (req, res) => {
  const token = String(req.body.qr_token || '').trim();
  if (!token) {
    return res.json({ success: false, level: 'error', message: 'No QR code detected.', spoken: 'No code detected.' });
  }
  try {
    const { data: resident } = await supabase.from('residents').select('*, puroks(name)').eq('qr_token', token).maybeSingle();
    if (!resident) {
      return res.json({
        success: false, level: 'error',
        message: 'Verification failed', detail: 'No resident matches this QR code.',
        spoken: 'Verification failed. Resident not found.'
      });
    }

    const { data: certRows } = await supabase.from('certificate_requests')
      .select('id, certificate_type, request_number').eq('resident_id', resident.id).eq('status', 'READY_FOR_RELEASE');
    const { data: aidRows } = await supabase.from('aid_beneficiaries')
      .select('id, aid_programs(title, aid_type, status)').eq('resident_id', resident.id).eq('status', 'Pending');

    const certificates = (certRows || []).map(c => ({ id: c.id, type: c.certificate_type, number: c.request_number }));
    const aid = (aidRows || []).filter(a => a.aid_programs && a.aid_programs.status === 'Open')
      .map(a => ({ id: a.id, title: a.aid_programs.title, type: a.aid_programs.aid_type }));

    const name = `${resident.first_name} ${resident.last_name}`;
    let spoken = `${name} verified.`;
    if (aid.length) spoken += ` ${aid.length} aid ${aid.length === 1 ? 'item' : 'items'} available to claim.`;
    if (certificates.length) spoken += ` ${certificates.length} ${certificates.length === 1 ? 'certificate' : 'certificates'} ready for release.`;

    res.json({
      success: true, level: 'ok',
      message: 'Resident verified', detail: name,
      spoken,
      resident: {
        name, number: resident.resident_number, address: resident.address,
        purok: resident.puroks ? resident.puroks.name : '', status: resident.resident_status,
        photo: resident.photo_url || ''
      },
      certificates, aid
    });
  } catch (err) {
    console.error('Scanner lookup error:', err);
    res.json({ success: false, level: 'error', message: 'Server error', detail: 'Please try again.', spoken: 'Server error. Please try again.' });
  }
});

// JSON: release aid after a verified scan
app.post('/api/scanner/claim-json', authenticateToken, requireRole(STAFF_ROLES), async (req, res) => {
  try {
    const { beneficiary_id, qr_token } = req.body;
    const { data: resident } = await supabase.from('residents').select('id, first_name, last_name').eq('qr_token', String(qr_token || '')).maybeSingle();
    const { data: ben } = await supabase.from('aid_beneficiaries').select('*, aid_programs(title, status)').eq('id', beneficiary_id).maybeSingle();

    if (!resident || !ben || ben.resident_id !== resident.id) {
      return res.json({ success: false, level: 'error', message: 'Claim failed', detail: 'The scanned ID does not match this aid record.', spoken: 'Claim failed. ID does not match.' });
    }
    if (!ben.aid_programs || ben.aid_programs.status !== 'Open') {
      return res.json({ success: false, level: 'warn', final: true, badge: 'Closed', message: 'Program closed', detail: 'This aid program is no longer open.', spoken: 'Program closed.' });
    }
    const name = `${resident.first_name} ${resident.last_name}`;
    const claim = await claimAidForHousehold(ben, req.user.id);
    if (claim.ok) {
      await logActivity(req.user.id, 'Aid Claimed', `${name} claimed "${ben.aid_programs.title}" via QR verification`);
      return res.json({ success: true, level: 'ok', badge: 'Released', message: 'Aid released', detail: `${name} - ${ben.aid_programs.title} (one claim for the whole household)`, spoken: `Aid released to ${name}. ${ben.aid_programs.title}. One claim for the whole household.` });
    }
    res.json({ success: false, level: 'warn', final: true, badge: 'Already claimed', message: 'Already claimed', detail: `${name}'s household already received this aid.`, spoken: `Already claimed. ${name}'s household already received this aid.` });
  } catch (err) {
    console.error('Scanner claim error:', err);
    res.json({ success: false, level: 'error', message: 'Server error', detail: 'Please try again.', spoken: 'Server error. Please try again.' });
  }
});

// JSON: mark a certificate as released after a verified scan
app.post('/api/scanner/release-certificate', authenticateToken, requireRole(STAFF_ROLES), async (req, res) => {
  try {
    const { certificate_id, qr_token } = req.body;
    const { data: resident } = await supabase.from('residents').select('id, first_name, last_name').eq('qr_token', String(qr_token || '')).maybeSingle();
    if (!resident) {
      return res.json({ success: false, level: 'error', message: 'Release failed', detail: 'Resident not found.', spoken: 'Release failed. Resident not found.' });
    }
    const { data: cert } = await supabase.from('certificate_requests')
      .select('id, certificate_type, request_number, status').eq('id', certificate_id).eq('resident_id', resident.id).maybeSingle();
    if (!cert) {
      return res.json({ success: false, level: 'error', message: 'Release failed', detail: 'Certificate does not belong to this resident.', spoken: 'Release failed. Certificate does not match.' });
    }
    const name = `${resident.first_name} ${resident.last_name}`;
    if (cert.status !== 'READY_FOR_RELEASE') {
      return res.json({ success: false, level: 'warn', final: true, badge: 'Already released', message: 'Already released', detail: `${cert.certificate_type} is not waiting for release.`, spoken: 'Already released.' });
    }
    await supabase.from('certificate_requests').update({ status: 'RELEASED', updated_at: new Date() }).eq('id', cert.id).eq('status', 'READY_FOR_RELEASE');
    await logActivity(req.user.id, 'Certificate Released', `${cert.certificate_type} (${cert.request_number}) released to ${name} via QR verification`);
    res.json({ success: true, level: 'ok', badge: 'Released', message: 'Certificate released', detail: `${name} - ${cert.certificate_type}`, spoken: `${cert.certificate_type} released to ${name}.` });
  } catch (err) {
    console.error('Scanner certificate error:', err);
    res.json({ success: false, level: 'error', message: 'Server error', detail: 'Please try again.', spoken: 'Server error. Please try again.' });
  }
});

// ---------- RESIDENT PORTAL: my aid + beneficiary lists ----------
app.get('/resident/aid', authenticateToken, requireRole(['Resident']), async (req, res) => {
  const settings = await getSettings();

  const { data: mine } = await supabase.from('aid_beneficiaries')
    .select('*, aid_programs(*)').eq('resident_id', req.user.resident_id).order('created_at', { ascending: false });

  const { data: openPrograms } = await supabase.from('aid_programs').select('*').eq('status', 'Open').order('created_at', { ascending: false });
  // Privacy: residents only ever see their own beneficiary records (never other residents' names)
  const myProgramIds = new Set((mine || []).map(m => m.program_id));

  const pendingMine = (mine || []).filter(m => m.status === 'Pending' && m.aid_programs && m.aid_programs.status === 'Open');

  const html = `
    ${pendingMine.length ? `
      <div class="alert alert-success d-flex align-items-center">
        <i class="bi bi-gift-fill fs-3 me-3"></i>
        <div><strong>You have ${pendingMine.length} aid package${pendingMine.length > 1 ? 's' : ''} ready to claim!</strong><br>
        <small>Bring your Barangay ID. Show the QR code on your ID (or your <a href="/resident/digital-id">Digital ID</a>) to the staff for scanning.</small></div>
      </div>` : ''}

    <div class="card card-custom p-4 mb-4">
      <h4 class="fw-bold text-primary-blue mb-3"><i class="bi bi-box2-heart me-2"></i>My Aid & Relief</h4>
      <div class="row g-3">
        ${(mine || []).map(m => {
          const p = m.aid_programs || {};
          const claimed = m.status === 'Claimed';
          return `
            <div class="col-md-6">
              <div class="card card-custom p-3 border-start border-4 ${claimed ? 'border-success' : 'border-warning'}">
                <div class="d-flex justify-content-between">
                  <h5 class="fw-bold text-primary-blue">${escHtml(p.title)}</h5>
                  <span class="badge ${claimed ? 'bg-success' : 'bg-warning text-dark'} h-100">${claimed ? 'CLAIMED' : 'READY TO CLAIM'}</span>
                </div>
                <span class="badge bg-info text-dark align-self-start mb-2">${escHtml(p.aid_type)}</span>
                <p class="small text-muted mb-1">${escHtml(p.description || '')}</p>
                <p class="small mb-0"><i class="bi bi-calendar3 me-1"></i>${escHtml(p.distribution_date || 'Date to be announced')} &nbsp; <i class="bi bi-geo-alt me-1"></i>${escHtml(p.location || 'Barangay Hall')}</p>
                ${claimed && m.claimed_at ? `<p class="small text-success mb-0 mt-1"><i class="bi bi-check-circle me-1"></i>Claimed on ${new Date(m.claimed_at).toLocaleString()}</p>` : ''}
                ${!claimed && p.status !== 'Open' ? '<p class="small text-danger mb-0 mt-1">This program is closed.</p>' : ''}
              </div>
            </div>`;
        }).join('') || '<div class="col-12 text-center text-muted py-3">You are not currently listed as a beneficiary of any aid program.</div>'}
      </div>
    </div>

    <div class="card card-custom p-4">
      <h5 class="fw-bold text-primary-blue mb-3"><i class="bi bi-megaphone me-2"></i>Current Aid Programs</h5>
      ${(openPrograms || []).map(p => `
        <div class="mb-3 pb-3 border-bottom">
          <div class="d-flex justify-content-between align-items-start">
            <h6 class="fw-bold text-accent-green mb-1">${escHtml(p.title)}</h6>
            ${myProgramIds.has(p.id) ? '<span class="badge bg-success">You are a beneficiary</span>' : ''}
          </div>
          <span class="badge bg-info text-dark mb-1">${escHtml(p.aid_type)}</span>
          <p class="small text-muted mb-1">${escHtml(p.description || '')}</p>
          <p class="small mb-0"><i class="bi bi-calendar3 me-1"></i>${escHtml(p.distribution_date || 'Date to be announced')} &nbsp; <i class="bi bi-geo-alt me-1"></i>${escHtml(p.location || 'Barangay Hall')}</p>
        </div>`).join('') || '<p class="text-muted">No open aid programs right now.</p>'}
    </div>
  `;

  res.send(renderAppLayout(req, 'res-aid', html, settings));
});

// ==========================================
// TERMS & CONDITIONS, ACCOUNT SETTINGS, EDITING RECORDS
// ==========================================
const RESIDENT_EDIT_ROLES = ['Super Admin', 'Barangay Admin', 'Barangay Secretary'];
const STAFF_ACCOUNT_ROLES = ['Barangay Admin', 'Barangay Secretary', 'Barangay Staff'];
const EMAIL_RE = /^\S+@\S+\.\S+$/;
const tidy = (v) => String(v || '').trim();

// True if another account already uses this value as a username OR an email
const identTaken = async (value, exceptId) => {
  for (const field of ['username', 'email']) {
    let q = supabase.from('users').select('id').eq(field, value).limit(1);
    if (exceptId) q = q.neq('id', exceptId);
    const { data } = await q;
    if (data && data.length) return true;
  }
  return false;
};

const alertBack = (res, msg, code = 400) =>
  res.status(code).send(`<script>alert(${JSON.stringify(msg)}); window.history.back();</script>`);

// ---------- TERMS AND CONDITIONS (public) ----------
app.get('/terms', async (req, res) => {
  const s = await getSettings();
  const brgy = escHtml(s.barangay_name || 'the Barangay');
  const place = escHtml([s.municipality, s.province].filter(Boolean).join(', '));
  const sections = [
    ['Acceptance of Terms', `By registering for, or logging in to, the ${brgy} Resident Management System (the "System"), you agree to these Terms and Conditions. If you do not agree, please do not register or use the System.`],
    ['Eligibility and Accurate Information', `The System is for bona fide residents of ${brgy}${place ? ', ' + place : ''}. You agree to provide true, complete and current information, and to keep it up to date. Giving false information or using another person's identity may result in rejection or removal of your account and may have legal consequences.`],
    ['Registration and Approval', 'New registrations stay <strong>Pending</strong> until verified and approved by Barangay officials. The Barangay may ask for supporting documents, and may reject or archive a registration that cannot be verified.'],
    ['Account Security', `<ul><li>You are responsible for keeping your password confidential and for all activity under your account.</li><li>Do not share your login with anyone. You can change your password at any time from <em>Account &amp; Password</em>.</li><li>Tell the Barangay office immediately if you suspect unauthorized access.</li></ul>`],
    ['Use of Services', `<ul><li>Certificate requests, appointments, complaints, assistance requests and feedback must be truthful and made in good faith.</li><li>Certificates are released only after approval and presentation of a valid Barangay ID or QR code.</li><li>Aid and relief are released only to verified beneficiaries, with one claim per household per program, subject to the program's rules and availability.</li><li>Approval of any request is at the Barangay's discretion and is not guaranteed.</li></ul>`],
    ['Data Privacy', `The Barangay collects and processes your personal information (such as name, birth date, address, contact details, photo, and category such as senior citizen, PWD, solo parent or student) in line with the Data Privacy Act of 2012 (Republic Act No. 10173). This information is used only to maintain barangay records, issue certificates and IDs, verify identity, and administer programs and aid. Access is limited to authorized Barangay personnel, your information is not sold, and it is kept only as long as needed for these purposes or required by law. You may ask to access or correct your information by contacting the Barangay office.`],
    ['Digital ID and QR Code', 'Your Barangay ID and QR code are personal to you. Do not lend, copy, or alter them. Report a lost or misused ID to the Barangay office right away so it can be replaced.'],
    ['Prohibited Conduct', 'You agree not to: attempt to access other residents\' records or any area you are not authorized for; upload unlawful, offensive or misleading content; interfere with the System\'s operation; or use the System for any purpose other than legitimate barangay transactions.'],
    ['Suspension and Termination', 'The Barangay may suspend, disable or archive an account that violates these Terms or that is found to contain false information.'],
    ['Changes to These Terms', 'These Terms may be updated from time to time. Continued use of the System after an update means you accept the revised Terms.'],
    ['Contact', `For questions about these Terms or your information, please visit the ${brgy} Barangay Hall.`]
  ];
  res.send(`
    ${renderSystemHead('Terms and Conditions')}
    <div class="container py-5">
      <div class="row justify-content-center"><div class="col-lg-9">
        <div class="card card-custom p-4 p-md-5 shadow">
          <div class="text-center mb-4">
            <i class="bi bi-file-earmark-text text-primary-blue fs-1"></i>
            <h3 class="fw-bold text-primary-blue mt-2">Terms and Conditions</h3>
            <p class="text-muted mb-0">${brgy} Resident Management System</p>
          </div>
          ${sections.map((sec, i) => `
            <h6 class="fw-bold text-accent-green mt-4">${i + 1}. ${sec[0]}</h6>
            <div class="text-muted">${sec[1]}</div>`).join('')}
          <div class="text-center mt-5">
            <a href="/register" class="btn btn-accent-custom fw-bold text-white px-4">Register as Resident</a>
            <a href="/login" class="btn btn-outline-secondary px-4 ms-2">Back to Login</a>
          </div>
        </div>
      </div></div>
    </div>
    ${renderSystemFooter()}
  `);
});

// ---------- ACCOUNT & PASSWORD (all logged-in users) ----------
const ACCOUNT_MESSAGES = {
  pw_ok: ['success', 'Your password was changed successfully.'],
  pw_wrong: ['danger', 'Your current password is incorrect.'],
  pw_mismatch: ['danger', 'The new password and its confirmation do not match.'],
  pw_short: ['danger', 'The new password must be at least 6 characters.'],
  pw_same: ['danger', 'The new password must be different from your current password.'],
  prof_ok: ['success', 'Your account details were updated.'],
  prof_wrong: ['danger', 'Your current password is incorrect, so nothing was changed.'],
  prof_taken: ['danger', 'That username or email is already used by another account.'],
  prof_invalid: ['danger', 'Please enter a name, a username and a valid email address.'],
  must_change: ['warning', 'You signed in with a temporary password. Please change it now to something only you know.'],
  error: ['danger', 'Something went wrong. Please try again.']
};

app.get('/account', authenticateToken, async (req, res) => {
  const settings = await getSettings();
  const u = req.user;
  const isStaff = STAFF_ROLES.includes(u.role);
  const m = ACCOUNT_MESSAGES[req.query.msg];

  const html = `
    <div style="max-width: 760px; margin: auto;">
      ${m ? `<div class="alert alert-${m[0]}"><i class="bi ${m[0] === 'success' ? 'bi-check-circle' : 'bi-exclamation-triangle'} me-2"></i>${m[1]}</div>` : ''}

      ${isStaff ? `
      <div class="card card-custom p-4 mb-4">
        <h5 class="fw-bold text-primary-blue mb-3"><i class="bi bi-person-gear me-2"></i>Account Details</h5>
        <form action="/api/account/update-profile" method="POST">
          <div class="row g-3">
            <div class="col-md-6"><label class="form-label">Full Name *</label><input type="text" name="full_name" class="form-control" required value="${escHtml(u.full_name)}"></div>
            <div class="col-md-6"><label class="form-label">Username *</label><input type="text" name="username" class="form-control" required value="${escHtml(u.username)}"></div>
            <div class="col-12"><label class="form-label">Email Address *</label><input type="email" name="email" class="form-control" required value="${escHtml(u.email)}"></div>
            <div class="col-12"><label class="form-label">Current Password * <small class="text-muted">(to confirm it's you)</small></label><input type="password" name="current_password" class="form-control" required autocomplete="current-password"></div>
          </div>
          <button type="submit" class="btn btn-primary-custom text-white mt-3"><i class="bi bi-check2 me-1"></i> Save Account Details</button>
        </form>
      </div>` : `
      <div class="card card-custom p-4 mb-4">
        <h5 class="fw-bold text-primary-blue mb-2"><i class="bi bi-person-circle me-2"></i>My Login</h5>
        <p class="mb-1"><strong>Login email:</strong> ${escHtml(u.email)}</p>
        <small class="text-muted">To correct your name, address or other details, ask the Barangay office or send a correction request from My Profile.</small>
      </div>`}

      <div class="card card-custom p-4">
        <h5 class="fw-bold text-primary-blue mb-3"><i class="bi bi-key me-2"></i>Change Password</h5>
        <form action="/api/account/change-password" method="POST">
          <div class="mb-3"><label class="form-label">Current Password *</label><input type="password" name="current_password" class="form-control" required autocomplete="current-password"></div>
          <div class="row g-3">
            <div class="col-md-6"><label class="form-label">New Password * <small class="text-muted">(min. 6 characters)</small></label><input type="password" name="new_password" class="form-control" required minlength="6" autocomplete="new-password"></div>
            <div class="col-md-6"><label class="form-label">Confirm New Password *</label><input type="password" name="confirm_password" class="form-control" required minlength="6" autocomplete="new-password"></div>
          </div>
          <button type="submit" class="btn btn-accent-custom fw-bold text-white mt-3"><i class="bi bi-shield-lock me-1"></i> Update Password</button>
        </form>
      </div>
    </div>`;

  res.send(renderAppLayout(req, isStaff ? 'account' : 'res-account', html, settings));
});

app.post('/api/account/change-password', authenticateToken, async (req, res) => {
  const back = (k) => res.redirect('/account?msg=' + k);
  try {
    const { current_password, new_password, confirm_password } = req.body;
    if (!(await bcrypt.compare(String(current_password || ''), req.user.password_hash))) return back('pw_wrong');
    if (!new_password || String(new_password).length < 6) return back('pw_short');
    if (new_password !== confirm_password) return back('pw_mismatch');
    if (new_password === current_password) return back('pw_same');
    const password_hash = await bcrypt.hash(String(new_password), 10);
    const { error } = await supabase.from('users').update({ password_hash, must_change_password: false }).eq('id', req.user.id);
    if (error) throw error;
    await logActivity(req.user.id, 'Change Password', 'User changed their own password.', req.ip);
    back('pw_ok');
  } catch (err) {
    console.error('Change password error:', err);
    back('error');
  }
});

app.post('/api/account/update-profile', authenticateToken, requireRole(STAFF_ROLES), async (req, res) => {
  const back = (k) => res.redirect('/account?msg=' + k);
  try {
    const full_name = tidy(req.body.full_name);
    const username = tidy(req.body.username);
    const email = tidy(req.body.email).toLowerCase();
    if (!full_name || !username || !EMAIL_RE.test(email)) return back('prof_invalid');
    if (!(await bcrypt.compare(String(req.body.current_password || ''), req.user.password_hash))) return back('prof_wrong');
    if ((await identTaken(username, req.user.id)) || (await identTaken(email, req.user.id))) return back('prof_taken');
    const { error } = await supabase.from('users').update({ full_name, username, email }).eq('id', req.user.id);
    if (error) throw error;
    await logActivity(req.user.id, 'Update Account', 'User updated their own name, username or email.', req.ip);
    back('prof_ok');
  } catch (err) {
    console.error('Update account error:', err);
    back('error');
  }
});

// ---------- ADMIN: EDIT RESIDENT RECORD ----------
app.get('/admin/resident/edit/:id', authenticateToken, requireRole(RESIDENT_EDIT_ROLES), async (req, res) => {
  const settings = await getSettings();
  const { data: r } = await supabase.from('residents').select('*').eq('id', req.params.id).maybeSingle();
  if (!r) return res.status(404).send('Resident not found');
  const { data: puroks } = await supabase.from('puroks').select('*');
  const { data: households } = await supabase.from('households').select('id, household_name, household_number').order('household_name');

  const opts = (list, cur) => [...new Set([...list, cur].filter(Boolean))]
    .map(o => `<option value="${escHtml(o)}" ${o === cur ? 'selected' : ''}>${escHtml(o)}</option>`).join('');
  const txt = (name, label, val, extra = '') => `<div class="col-md-4"><label class="form-label">${label}</label><input type="text" name="${name}" class="form-control" value="${escHtml(val)}" ${extra}></div>`;

  const html = `
    <div class="card card-custom p-4" style="max-width: 900px; margin: auto;">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="fw-bold text-primary-blue m-0"><i class="bi bi-pencil-square me-2"></i>Edit Resident Record</h4>
        <span class="badge bg-accent-green text-white">${escHtml(r.resident_number)}</span>
      </div>
      <form action="/api/admin/resident/${r.id}/update" method="POST">
        <h6 class="fw-bold text-accent-green border-bottom pb-2 mb-3">Personal Information</h6>
        <div class="row g-3 mb-3">
          ${txt('first_name', 'First Name *', r.first_name, 'required')}
          ${txt('middle_name', 'Middle Name', r.middle_name)}
          ${txt('last_name', 'Last Name *', r.last_name, 'required')}
          ${txt('suffix', 'Suffix', r.suffix)}
          <div class="col-md-4"><label class="form-label">Date of Birth *</label><input type="date" name="date_of_birth" class="form-control" required value="${escHtml(String(r.date_of_birth || '').slice(0, 10))}"></div>
          <div class="col-md-2"><label class="form-label">Gender *</label><select name="gender" class="form-select">${opts(['Male', 'Female'], r.gender)}</select></div>
          <div class="col-md-2"><label class="form-label">Civil Status *</label><select name="civil_status" class="form-select">${opts(['Single', 'Married', 'Widowed', 'Separated'], r.civil_status)}</select></div>
        </div>

        <h6 class="fw-bold text-accent-green border-bottom pb-2 mb-3">Address, Contact & Household</h6>
        <div class="row g-3 mb-3">
          <div class="col-md-6"><label class="form-label">Purok</label>
            <select name="purok_id" class="form-select"><option value="">- None -</option>${(puroks || []).map(p => `<option value="${p.id}" ${String(p.id) === String(r.purok_id) ? 'selected' : ''}>${escHtml(p.name)}</option>`).join('')}</select></div>
          <div class="col-md-6"><label class="form-label">Household</label>
            <select name="household_id" class="form-select"><option value="">- Not linked -</option>${(households || []).map(h => `<option value="${h.id}" ${String(h.id) === String(r.household_id) ? 'selected' : ''}>${escHtml(h.household_name || h.household_number)}</option>`).join('')}</select></div>
          <div class="col-12"><label class="form-label">Complete Address *</label><input type="text" name="address" class="form-control" required value="${escHtml(r.address)}"></div>
          <div class="col-md-4"><label class="form-label">Contact Number</label><input type="text" name="contact_number" class="form-control" value="${escHtml(r.contact_number)}"></div>
          <div class="col-md-4"><label class="form-label">Occupation</label><input type="text" name="occupation" class="form-control" value="${escHtml(r.occupation)}"></div>
          <div class="col-md-4"><label class="form-label">Email <small class="text-muted">(also the resident's login)</small></label><input type="email" name="email" class="form-control" value="${escHtml(r.email)}"></div>
        </div>

        <h6 class="fw-bold text-accent-green border-bottom pb-2 mb-3">Categories</h6>
        <div class="mb-2">${renderCategoryCheckboxes(r, 'editCat')}</div>
        <div class="form-check mb-4"><input class="form-check-input" type="checkbox" name="is_solo_parent" id="editSolo" ${r.is_solo_parent ? 'checked' : ''}><label class="form-check-label" for="editSolo">Solo Parent</label></div>

        <div class="d-flex gap-2">
          <button type="submit" class="btn btn-primary-custom text-white fw-bold"><i class="bi bi-check2 me-1"></i> Save Changes</button>
          <a href="/admin/resident/view/${r.id}" class="btn btn-outline-secondary">Cancel</a>
        </div>
      </form>
    </div>`;
  res.send(renderAppLayout(req, 'residents', html, settings));
});

app.post('/api/admin/resident/:id/update', authenticateToken, requireRole(RESIDENT_EDIT_ROLES), async (req, res) => {
  try {
    const b = req.body;
    const first_name = tidy(b.first_name), last_name = tidy(b.last_name);
    const date_of_birth = tidy(b.date_of_birth), address = tidy(b.address);
    const email = tidy(b.email).toLowerCase();
    if (!first_name || !last_name || !date_of_birth || !address) return alertBack(res, 'Please fill in all required fields.');
    if (email && !EMAIL_RE.test(email)) return alertBack(res, 'Please enter a valid email address.');

    const { data: existing } = await supabase.from('residents').select('id').eq('id', req.params.id).maybeSingle();
    if (!existing) return res.status(404).send('Resident not found');
    const { data: linked } = await supabase.from('users').select('id, username, email').eq('resident_id', req.params.id).maybeSingle();
    if (email && (!linked || email !== linked.email) && await identTaken(email, linked ? linked.id : null)) {
      return alertBack(res, 'That email is already used by another account.');
    }

    const age = new Date().getFullYear() - new Date(date_of_birth).getFullYear();
    const { error } = await supabase.from('residents').update({
      first_name, middle_name: tidy(b.middle_name), last_name, suffix: tidy(b.suffix),
      date_of_birth, gender: b.gender || 'Male', civil_status: b.civil_status || 'Single',
      purok_id: b.purok_id || null, household_id: b.household_id || null,
      address, contact_number: tidy(b.contact_number), occupation: tidy(b.occupation), email,
      is_solo_parent: !!b.is_solo_parent,
      ...categoryFlags(b),
      is_senior_citizen: age >= 60 || !!b.cat_senior
    }).eq('id', req.params.id);
    if (error) throw error;

    // Keep the resident's login account in step with the record
    if (linked) {
      const upd = { full_name: `${first_name} ${last_name}` };
      if (email && email !== linked.email) {
        upd.email = email;
        if (linked.username === linked.email) upd.username = email;
      }
      await supabase.from('users').update(upd).eq('id', linked.id);
    }

    await logActivity(req.user.id, 'Edit Resident', `Edited resident record: ${first_name} ${last_name} (ID ${req.params.id})`, req.ip);
    res.redirect(`/admin/resident/view/${req.params.id}`);
  } catch (err) {
    console.error('Edit resident error:', err);
    alertBack(res, 'Error saving changes: ' + err.message, 500);
  }
});

// ---------- ADMIN: EDIT ANY SYSTEM ACCOUNT (name, username, email, role, password reset) ----------
app.post('/api/admin/user/:id/update', authenticateToken, requireRole(['Super Admin', 'Barangay Admin']), async (req, res) => {
  try {
    const { data: target } = await supabase.from('users').select('*').eq('id', req.params.id).maybeSingle();
    if (!target) return res.status(404).send('Account not found');
    if (target.role === 'Super Admin' && req.user.role !== 'Super Admin') {
      return alertBack(res, 'Only a Super Admin can edit a Super Admin account.', 403);
    }
    const isResident = target.role === 'Resident';
    const email = tidy(req.body.email).toLowerCase();
    const full_name = isResident ? target.full_name : tidy(req.body.full_name);
    const username = isResident ? target.username : tidy(req.body.username);
    if (!full_name || !username || !EMAIL_RE.test(email)) return alertBack(res, 'Please enter a name, a username and a valid email address.');
    if (email !== target.email && await identTaken(email, target.id)) return alertBack(res, 'That email is already used by another account.');
    if (username !== target.username && await identTaken(username, target.id)) return alertBack(res, 'That username is already used by another account.');

    const upd = { full_name, username, email };
    if (isResident && email !== target.email && target.username === target.email) upd.username = email;
    if (!isResident && target.role !== 'Super Admin' && STAFF_ACCOUNT_ROLES.includes(req.body.role)) upd.role = req.body.role;
    const newPw = String(req.body.new_password || '');
    if (newPw) {
      if (newPw.length < 6) return alertBack(res, 'The new password must be at least 6 characters.');
      upd.password_hash = await bcrypt.hash(newPw, 10);
    }
    const { error } = await supabase.from('users').update(upd).eq('id', target.id);
    if (error) throw error;
    if (isResident && target.resident_id && email !== target.email) {
      await supabase.from('residents').update({ email }).eq('id', target.resident_id);
    }
    await logActivity(req.user.id, 'Edit Account', `Edited account ${target.username}${newPw ? ' (password reset)' : ''}`, req.ip);
    res.redirect('/admin/users');
  } catch (err) {
    console.error('Edit account error:', err);
    alertBack(res, 'Error saving account: ' + err.message, 500);
  }
});

// ==========================================
// FAMILY ACCOUNTS
// The head of the household can add a photo for each member and create a login account for them.
// The login email and temporary password are generated; the head sees them so they can hand them over.
// Passwords are stored hashed only, so a temporary password is shown when it is created or reset.
// ==========================================
const TEMP_PW_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789'; // no look-alike characters

function generateTempPassword(length = 10) {
  let out = '';
  for (let i = 0; i < length; i++) out += TEMP_PW_ALPHABET[crypto.randomInt(TEMP_PW_ALPHABET.length)];
  return out;
}

const asciiSlug = (s) => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]/g, '');

async function generateFamilyEmail(first, last) {
  const base = [asciiSlug(first), asciiSlug(last)].filter(Boolean).join('.') || 'member';
  for (let i = 0; i < 10; i++) {
    const email = `${base}${crypto.randomInt(1000, 10000)}@${FAMILY_EMAIL_DOMAIN}`;
    if (!(await identTaken(email))) return email;
  }
  return `${base}${Date.now()}@${FAMILY_EMAIL_DOMAIN}`;
}

// Creates the login for one household member under the head's account and returns { email, password }.
async function createFamilyAccount({ resident, headUserId, status }) {
  const password = generateTempPassword();
  const password_hash = await bcrypt.hash(password, 10);
  for (let attempt = 0; attempt < 5; attempt++) {
    const email = await generateFamilyEmail(resident.first_name, resident.last_name);
    const { error } = await supabase.from('users').insert([{
      username: email,
      email,
      password_hash,
      full_name: `${resident.first_name} ${resident.last_name}`,
      role: 'Resident',
      status,
      resident_id: resident.id,
      family_head_user_id: headUserId,
      must_change_password: true
    }]);
    if (!error) {
      await supabase.from('residents').update({ email }).eq('id', resident.id);
      return { email, password };
    }
    if (!/duplicate|unique/i.test(error.message || '')) throw error;
  }
  throw new Error('Could not generate a unique login email.');
}

const familyHeadOf = async (req) => {
  const { data: head } = await supabase.from('residents').select('*').eq('id', req.user.resident_id).maybeSingle();
  return head && head.is_household_head && head.household_id ? head : null;
};

const familyMemberOf = async (head, id) => {
  if (!id || id === head.id) return null;
  const { data: m } = await supabase.from('residents').select('*').eq('id', id).eq('household_id', head.household_id).maybeSingle();
  return m || null;
};

const FAMILY_MESSAGES = {
  photo_ok: ['success', 'The photo was updated.']
};

const familyStatusBadge = (s) =>
  `<span class="badge ${s === 'Active' ? 'bg-success' : (s === 'Pending' ? 'bg-warning text-dark' : 'bg-secondary')}">${escHtml(s)}</span>`;

const familyCredsNotice = (name, creds, verb, pending) => ({
  type: 'success',
  secret: true,
  html: `
    <h6 class="fw-bold mb-2"><i class="bi bi-key-fill me-2"></i>${escHtml(verb)} for ${escHtml(name)}</h6>
    <div class="table-responsive">
      <table class="table table-sm table-bordered bg-white mb-2"><tbody>
        <tr><th style="width:40%">Login email</th><td class="font-monospace user-select-all">${escHtml(creds.email)}</td></tr>
        <tr><th>Temporary password</th><td class="font-monospace fw-bold user-select-all">${escHtml(creds.password)}</td></tr>
      </tbody></table>
    </div>
    <div class="small">Give these to ${escHtml(name)}. They will be asked to change the password when they first sign in.${pending ? ' The account works once the Barangay approves this household.' : ''} This password is shown only now; if it gets lost, use <em>New Temporary Password</em> below (available until they set their own).</div>
    <button type="button" class="btn btn-sm btn-outline-secondary mt-2 no-print" onclick="window.print()"><i class="bi bi-printer me-1"></i> Print</button>`
});

const renderFamilyPage = async (req, res, head, notice) => {
  const settings = await getSettings();
  const { data: members } = await supabase.from('residents')
    .select('id, resident_number, first_name, middle_name, last_name, suffix, relationship, photo_url, resident_status')
    .eq('household_id', head.household_id).neq('id', head.id).order('created_at', { ascending: true });
  const list = members || [];
  let accounts = [];
  if (list.length) {
    const { data } = await supabase.from('users')
      .select('id, resident_id, email, status, must_change_password, family_head_user_id')
      .in('resident_id', list.map(m => m.id));
    accounts = data || [];
  }

  const cards = list.map(m => {
    const acct = accounts.find(a => a.resident_id === m.id);
    const mine = !!acct && acct.family_head_user_id === req.user.id;
    const fullName = [m.first_name, m.middle_name, m.last_name, m.suffix].filter(Boolean).join(' ');
    const accountLine = !acct
      ? '<span class="text-muted"><i class="bi bi-person-x me-1"></i>No login account yet</span>'
      : `<i class="bi bi-person-check me-1"></i>Login: <strong class="font-monospace">${escHtml(acct.email)}</strong> ${familyStatusBadge(acct.status)}${mine ? (acct.must_change_password ? ' <span class="text-muted">- still on the temporary password</span>' : ' <span class="text-muted">- member set their own password</span>') : ''}`;

    let actions = '';
    if (!acct && m.resident_status !== 'Archived') {
      actions = `<form action="/api/resident/family/${m.id}/create-account" method="POST"><button type="submit" class="btn btn-sm btn-accent-custom text-white fw-bold"><i class="bi bi-person-plus me-1"></i> Create Account</button></form>`;
    } else if (mine && acct.must_change_password) {
      actions = `<form action="/api/resident/family/${m.id}/reset-password" method="POST" onsubmit="return confirm('Generate a new temporary password? The old one will stop working.')"><button type="submit" class="btn btn-sm btn-outline-primary"><i class="bi bi-arrow-repeat me-1"></i> New Temporary Password</button></form>`;
    }

    return `
      <div class="card card-custom p-3 mb-3">
        <div class="d-flex flex-wrap align-items-center gap-3">
          <img src="${m.photo_url || 'https://via.placeholder.com/80'}" class="rounded-circle" style="width:72px; height:72px; object-fit:cover;" alt="">
          <div class="flex-grow-1">
            <h6 class="fw-bold text-primary-blue m-0">${escHtml(fullName)}</h6>
            <div class="small text-muted">${escHtml(m.relationship || 'Family member')} &middot; ${escHtml(m.resident_number)} &middot; ${familyStatusBadge(m.resident_status)}</div>
            <div class="small mt-1">${accountLine}</div>
          </div>
          <div>${actions}</div>
        </div>
        <form action="/api/resident/family/${m.id}/photo" method="POST" enctype="multipart/form-data" class="d-flex flex-wrap gap-2 mt-3">
          <input type="file" name="photo" accept="image/*" class="form-control form-control-sm" style="max-width: 280px;" required>
          <button type="submit" class="btn btn-sm btn-outline-primary"><i class="bi bi-camera me-1"></i> ${m.photo_url ? 'Change' : 'Add'} Photo</button>
        </form>
      </div>`;
  });

  const html = `
    <div style="max-width: 860px; margin: auto;">
      <h4 class="fw-bold text-primary-blue mb-1"><i class="bi bi-people me-2"></i>My Family</h4>
      <p class="text-muted small">As head of the household you can add a photo for each member and create a login account for them. The login email and temporary password are generated for you.</p>
      ${notice ? `<div class="alert alert-${notice.type}">${notice.html}</div>` : ''}
      ${cards.join('') || '<div class="alert alert-info">No family members are registered under your household yet.</div>'}
    </div>`;

  if (notice && notice.secret) res.set('Cache-Control', 'no-store');
  res.send(renderAppLayout(req, 'res-family', html, settings));
};

app.get('/resident/family', authenticateToken, requireRole(['Resident']), async (req, res) => {
  try {
    const head = await familyHeadOf(req);
    if (!head) {
      const settings = await getSettings();
      return res.send(renderAppLayout(req, 'res-family', '<div class="alert alert-info" style="max-width:760px; margin:auto;">Only the head of the household can manage family accounts and photos.</div>', settings));
    }
    const m = FAMILY_MESSAGES[req.query.msg];
    await renderFamilyPage(req, res, head, m ? { type: m[0], html: escHtml(m[1]) } : null);
  } catch (err) {
    console.error('Family page error:', err);
    res.status(500).send('Error loading your family page: ' + err.message);
  }
});

app.post('/api/resident/family/:id/create-account', authenticateToken, requireRole(['Resident']), async (req, res) => {
  try {
    const head = await familyHeadOf(req);
    if (!head) return alertBack(res, 'Only the head of the household can create family accounts.', 403);
    const member = await familyMemberOf(head, req.params.id);
    if (!member) return alertBack(res, 'That person is not a member of your household.', 404);
    if (member.resident_status === 'Archived') return alertBack(res, "This member's record is archived, so an account cannot be created.");

    const { data: existing } = await supabase.from('users').select('id').eq('resident_id', member.id).limit(1);
    if (existing && existing.length) return renderFamilyPage(req, res, head, { type: 'warning', html: 'This member already has a login account.' });

    const pending = member.resident_status !== 'Active';
    const creds = await createFamilyAccount({ resident: member, headUserId: req.user.id, status: pending ? 'Pending' : 'Active' });
    await logActivity(req.user.id, 'Create Family Account', `Created a login for family member ${member.first_name} ${member.last_name} (resident ID ${member.id})`, req.ip);
    return renderFamilyPage(req, res, head, familyCredsNotice(`${member.first_name} ${member.last_name}`, creds, 'Account created', pending));
  } catch (err) {
    console.error('Create family account error:', err);
    alertBack(res, 'Error creating the account: ' + err.message, 500);
  }
});

app.post('/api/resident/family/:id/reset-password', authenticateToken, requireRole(['Resident']), async (req, res) => {
  try {
    const head = await familyHeadOf(req);
    if (!head) return alertBack(res, 'Only the head of the household can reset family passwords.', 403);
    const member = await familyMemberOf(head, req.params.id);
    if (!member) return alertBack(res, 'That person is not a member of your household.', 404);

    const { data: acct } = await supabase.from('users')
      .select('id, email, status, must_change_password')
      .eq('resident_id', member.id).eq('family_head_user_id', req.user.id).maybeSingle();
    if (!acct) return renderFamilyPage(req, res, head, { type: 'danger', html: 'No account created by you was found for this member.' });
    if (!acct.must_change_password) {
      return renderFamilyPage(req, res, head, { type: 'warning', html: 'This member already set their own password, so it cannot be reset from here. Please ask the Barangay office to reset it.' });
    }

    const password = generateTempPassword();
    const password_hash = await bcrypt.hash(password, 10);
    const { error } = await supabase.from('users').update({ password_hash, must_change_password: true }).eq('id', acct.id);
    if (error) throw error;
    await logActivity(req.user.id, 'Reset Family Password', `Issued a new temporary password for family member ${member.first_name} ${member.last_name} (resident ID ${member.id})`, req.ip);
    return renderFamilyPage(req, res, head, familyCredsNotice(`${member.first_name} ${member.last_name}`, { email: acct.email, password }, 'New temporary password', acct.status === 'Pending'));
  } catch (err) {
    console.error('Reset family password error:', err);
    alertBack(res, 'Error resetting the password: ' + err.message, 500);
  }
});

app.post('/api/resident/family/:id/photo', authenticateToken, requireRole(['Resident']), safeUpload(photoUpload.single('photo')), async (req, res) => {
  try {
    const head = await familyHeadOf(req);
    if (!head) return alertBack(res, 'Only the head of the household can change family photos.', 403);
    const member = await familyMemberOf(head, req.params.id);
    if (!member) return alertBack(res, 'That person is not a member of your household.', 404);
    if (!req.file) return alertBack(res, 'Please choose a photo first.');
    const photo_url = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;
    const { error } = await supabase.from('residents').update({ photo_url }).eq('id', member.id);
    if (error) throw error;
    await logActivity(req.user.id, 'Family Member Photo', `Updated the photo of family member ${member.first_name} ${member.last_name} (resident ID ${member.id})`, req.ip);
    res.redirect('/resident/family?msg=photo_ok');
  } catch (err) {
    console.error('Family photo error:', err);
    alertBack(res, 'Error saving the photo: ' + err.message, 500);
  }
});

// ==========================================
// DEFAULT INDEX ROOT ROUTE
// ==========================================
app.get('/', (req, res) => {
  res.redirect('/login');
});

// Start Express Server
app.listen(PORT, () => {
  console.log(`[BARANGAY SYSTEM RUNNING] Listening on port ${PORT}`);
});
